#!/usr/bin/env python3
"""Revision-safe entrypoint for the Core v2 semantic publication renderer.

Initial publication remains fail-closed.  A pending, unapproved Publication
Preview revision may replace only artifacts owned by this renderer before the
immutable base entrypoint recreates and revalidates them.
"""
from __future__ import annotations

import argparse
from pathlib import Path

from scripts import survey_production_v2 as core
from scripts import run_semantic_publication_v2_interactive_base as _base


def _raw_safe_owned(path: Path, root: Path) -> Path:
    """Raw-first lexical ancestor lstat walk (no resolve-then-check laundering)."""
    root_res = root.resolve()
    lex = path if path.is_absolute() else (root_res / path)
    try:
        rel = lex.relative_to(root_res)
    except ValueError as exc:
        raise SystemExit(f"owned path escapes repository: {path}") from exc
    if ".." in rel.parts or "\\" in str(rel):
        raise SystemExit(f"owned path unsafe: {path}")
    cur = root_res
    for part in rel.parent.parts:
        if part in ("..", ".", ""):
            raise SystemExit(f"owned path unsafe component: {part}")
        cur = cur / part
        try:
            if cur.is_symlink():
                raise SystemExit(f"owned path has symlinked ancestor: {cur.relative_to(root_res)}")
        except OSError as exc:
            raise SystemExit(f"owned ancestor check failed: {exc}") from exc
    if lex.is_symlink():
        raise SystemExit(f"refusing symlinked owned path: {rel.as_posix()}")
    return lex


def _require_canonical_mode(root, cfg, state) -> None:
    """Revised-mode refusal at entry before any delete/report/guard (contract §8).

    Uses frozen L `assert_canonical_publication_mode` (fail-closed, no swallow).
    Only genuine no-pointer initial proceeds; invalid pointer never falls back.
    All new modules now required (no NEEDS_L fallback).
    """
    from scripts import survey_publication_set_v2 as _setmod  # type: ignore
    # Propagate L errors (no swallowed pointer errors).
    _setmod.assert_canonical_publication_mode(root, cfg, state)


def _prepare_revision() -> None:
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--state", required=True)
    parser.add_argument("--input", required=True)
    args, _ = parser.parse_known_args()
    root = Path(args.repo_root).resolve()
    # Entry refusal before any delete/report/guard creation.
    _pre_state_path = (root / args.state) if not Path(args.state).is_absolute() else Path(args.state)
    _pre_state = core.load_json(_pre_state_path if _pre_state_path.is_file() else root / args.state)
    _pre_cfg = core.load_json(root / core.DEFAULT_CONFIG)
    _require_canonical_mode(root, _pre_cfg, _pre_state)
    state_path = _raw_safe_owned(root / args.state, root)
    state = core.load_json(state_path)
    revision = (
        state.get("lifecycle_state") == "RELEASE_CANDIDATE"
        and state.get("next_action") == "PUBLICATION_PREVIEW"
        and state.get("human_gates", {}).get("publication_preview") == "pending"
        and state.get("human_gate_provenance", {}).get("publication_preview") is None
    )
    if not revision:
        return
    profile_path = _raw_safe_owned(root / state["profile"]["path"], root)
    profile = core.load_json(profile_path)
    source_root = _raw_safe_owned(root / profile["paths"]["source_root"], root)
    survey_root = _raw_safe_owned(root / profile["paths"]["survey_root"], root)
    publication_root = source_root / "publication/v2"
    quality_root = publication_root / "quality"
    owned = (
        survey_root / "main.tex",
        survey_root / "references.bib",
        survey_root / "jgaisurvey.sty",
        publication_root / "validated-source-manifest.json",
        publication_root / "interactive-semantic-publication-input.json",
        quality_root / "longform-special-preflight.json",
        quality_root / "subject-entity-property-binding.json",
        quality_root / "empty-wrapper-suppression.json",
    )
    for path in owned:
        checked = _raw_safe_owned(path, root)
        if checked.exists():
            if not checked.is_file():
                raise SystemExit(f"renderer-owned publication path is not a file: {checked.relative_to(root)}")
            checked.unlink()


if __name__ == "__main__":
    _prepare_revision()
    raise SystemExit(_base.main())
