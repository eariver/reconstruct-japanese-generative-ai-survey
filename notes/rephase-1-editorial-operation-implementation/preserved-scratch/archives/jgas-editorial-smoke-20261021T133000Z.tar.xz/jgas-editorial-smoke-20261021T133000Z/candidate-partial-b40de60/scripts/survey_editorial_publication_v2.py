#!/usr/bin/env python3
"""Survey editorial publication operation (high-level, H-owned).

Prepare -> external review inputs -> finalize -> activate -> normal consumer.

Low-level identity/selection lives in survey_publication_set_v2 (L-owned);
this module never reimplements it and never accepts caller-verified dicts.
Source proof uses P2R/P3S historical replay only (no P2V future seal,
no current activation). Public receipt verifies strict State + unchanged
accepted research + exact source replay after activation (no before-State
hash equality). Early scope independently reloads existing P1 scope via
P3S verifier, never postrender semantic as pre-TeX scope.

Only H-owned paths are edited here; L/C files are called, never modified.
"""
from __future__ import annotations

import argparse
import json
import os
import stat
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from scripts import survey_production_v2 as core
from scripts import survey_schema_v2 as schema_gate

EDITORIAL_RECEIPT_SCHEMA = Path("schemas/editorial-publication-source-manifest-v2.schema.json")
BUILD_RECORD_SCHEMA = Path("schemas/editorial-publication-build-record-v2.schema.json")
MANUSCRIPT_SPEC_SCHEMA = Path("schemas/editorial-manuscript-spec-v2.schema.json")
TOOLCHAIN_SPEC_SCHEMA = Path("schemas/editorial-toolchain-spec-v2.schema.json")
MANUSCRIPT_SCHEMA = Path("schemas/reader-manuscript-v2.schema.json")
GATE_SCHEMA = Path("schemas/reader-surface-gate-v2.schema.json")
CANDIDATE_SCHEMA = Path("schemas/publication-candidate-v2.schema.json")
QUALITY_SCHEMA = Path("schemas/quality-regression-bundle-v2.schema.json")
RECIPE_REF = Path(".latexmkrc")

SEAL_ROLES = (
    "reader-input",
    "authoring-input",
    "source-receipt",
    "reader-manuscript",
    "validated-source",
    "bibliography",
    "style",
    "publication-pdf",
    "build-log",
    "pdf-digest",
    "quality-regression-bundle",
    "semantic-review",
    "visual-review",
    "reader-surface-gate",
    "publication-candidate",
)

FIXED_RECIPE_STEPS = (
    "lualatex -synctex=1 -interaction=nonstopmode -file-line-error -halt-on-error main.tex",
    "biber main",
    "lualatex -synctex=1 -interaction=nonstopmode -file-line-error -halt-on-error main.tex",
    "lualatex -synctex=1 -interaction=nonstopmode -file-line-error -halt-on-error main.tex",
)
# Exact expected argv tuples per recipe (flat command strings, schema-compliant).
# Spec.argv must EXACTLY equal the expected tuple for its recipe (not permissive token membership),
# and executed/recorded argv must equal the same tuple. Bare tool names (no absolute paths in argv);
# absolute exe/companion are recorded separately in toolchain.executable/versions.
EXPECTED_ARGV_LUALATEX_BIBER = tuple(FIXED_RECIPE_STEPS)
EXPECTED_ARGV_LATEXMK = ("latexmk -pdf -lualatex -interaction=nonstopmode main.tex",)
# Fixed recipe .latexmkrc consistency markers (actual latexmk consistent file).
# The repo .latexmkrc must contain these markers; hash is pinned in build record.
REQUIRED_RECIPE_MARKERS = (
    "$pdf_mode = 4;",
    "$lualatex",
    "$biber",
    "$max_repeat",
)
# Required blocking TeX/log patterns: even with exit 0, these refuse the build.
# Checked against combined stdout/stderr + main.log bytes (decoded, errors ignored).
REQUIRED_BLOCKING_LOG_PATTERNS = (
    "! Undefined control sequence",
    "! Emergency stop",
    "! Fatal error",
    "! LaTeX Error",
    "No pages of output",
    "Latexmk: Errors",
    "Biber error",
    "Undefined control sequence",
    "Emergency stop",
    "Fatal error occurred",
)
ALLOWED_ARGV_TOKENS = frozenset({
    "-synctex=1",
    "-interaction=nonstopmode",
    "-file-line-error",
    "-halt-on-error",
    "%O",
    "%S",
    "main.tex",
    "main",
    "-pdf",
    "-lualatex",
})
ALLOWED_ENV_KEYS = frozenset({
    "TEXMFHOME",
    "TEXMFVAR",
    "TEXMFCONFIG",
    "SOURCE_DATE_EPOCH",
    "TZ",
    "LANG",
    "LC_ALL",
    "HOME",
})
# Controlled PATH for build subprocesses: toolbin + known OS helpers only,
# not arbitrary ambient PATH. Perl/helper (latexmk) needs /usr/bin:/bin.
CONTROLLED_SYSTEM_PATH_SUFFIX = "/usr/bin:/bin"


def _resolve_toolchain_executable(exe: Path, label: str) -> tuple[Path, Path, str]:
    # Explicit external toolchain executor is NOT a repo authority file: repo
    # alias refusal does not apply. Resolve the known declared symlink chain
    # once (link -> real), pin link+real + hash/version, and recheck stable at
    # execution. Uses argv0 via link path (lualatex formatting) with stable
    # real recheck; blanket symlink rejection would falsely claim TL2026 unusable.
    # Returns (link_path, real_path, real_sha256).
    import stat as _st

    try:
        est = os.lstat(exe)
    except OSError as exc:
        raise _fail("TOOLCHAIN_MISSING", "PIN", "REFUSED_PRE_WRITE", f"toolchain executable missing: {exe}: {exc}") from exc
    if _st.S_ISFIFO(est.st_mode) or _st.S_ISSOCK(est.st_mode) or _st.S_ISDIR(est.st_mode):
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", f"toolchain executable unsafe type: {exe}")
    # Resolve chain once via realpath (bounded, no network). Link may be symlink;
    # real must be a regular file (not symlink/FIFO/socket/dir) after full resolve.
    try:
        real_str = os.path.realpath(str(exe))
    except OSError as exc:
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", f"toolchain realpath failed {exe}: {exc}") from exc
    real = Path(real_str)
    try:
        rest = os.lstat(real)
    except OSError as exc:
        raise _fail("TOOLCHAIN_MISSING", "PIN", "REFUSED_PRE_WRITE", f"toolchain real target missing {exe} -> {real}: {exc}") from exc
    if _st.S_ISLNK(rest.st_mode):
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", f"toolchain real target still symlink (unresolved chain): {exe} -> {real}")
    if not _st.S_ISREG(rest.st_mode):
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", f"toolchain real target not regular file: {exe} -> {real}")
    # Hash real bytes (bounded read in chunks to support large TL binaries).
    try:
        h = __import__("hashlib").sha256()
        with open(real, "rb") as fh:
            while True:
                chunk = fh.read(1024 * 1024)
                if not chunk:
                    break
                h.update(chunk)
        real_sha = h.hexdigest()
    except OSError as exc:
        raise _fail("TOOLCHAIN_MISSING", "PIN", "REFUSED_PRE_WRITE", f"toolchain real readable failed {real}: {exc}") from exc
    return (exe, real, real_sha)


def _check_blocking_log_patterns(combined_text: str, label: str) -> None:
    for pat in REQUIRED_BLOCKING_LOG_PATTERNS:
        if pat in combined_text:
            raise _fail("BUILD_LOG_BLOCKED", "BUILD", "PRESERVED_INCOMPLETE", f"build log blocked by pattern {pat!r} in {label}")
_UNSAFE_GIT_VARS = (
    "GIT_DIR",
    "GIT_WORK_TREE",
    "GIT_INDEX_FILE",
    "GIT_OBJECT_DIRECTORY",
    "GIT_ALTERNATE_OBJECT_DIRECTORIES",
    "GIT_COMMON_DIR",
    "GIT_PREFIX",
)


class EditorialError(ValueError):
    def __init__(self, code: str, phase: str, disposition: str, detail: str) -> None:
        super().__init__(f"{code}: [{phase}/{disposition}] {detail}")
        self.code = code
        self.phase = phase
        self.disposition = disposition
        self.detail = detail


def _fail(code: str, phase: str, disp: str, detail: str) -> EditorialError:
    return EditorialError(code, phase, disp, detail)


def _lexical_rel(repo_root: Path, raw: str | Path, label: str) -> str:
    # Raw-first lexical containment BEFORE any resolve (no symlink laundering).
    # Rejects absolute, drive-absolute, backslash, empty, dot/dotdot components.
    # Returns repo-relative posix string without resolving.
    text = raw.as_posix() if isinstance(raw, Path) else str(raw)
    if not isinstance(text, str) or not text or "\\" in text:
        raise _fail("UNSAFE_PART", "PIN", "REFUSED_PRE_WRITE", f"{label} unsafe path: {raw!r}")
    candidate = Path(text)
    if candidate.is_absolute():
        raise _fail("ESCAPE", "PIN", "REFUSED_PRE_WRITE", f"{label} absolute path refused: {raw!r}")
    if ".." in candidate.parts or "." in candidate.parts or "" in candidate.parts:
        raise _fail("UNSAFE_PART", "PIN", "REFUSED_PRE_WRITE", f"{label} unsafe component: {raw!r}")
    if not text or text.startswith("/") or text.startswith("../") or "/../" in text:
        raise _fail("ESCAPE", "PIN", "REFUSED_PRE_WRITE", f"{label} escapes repository: {raw!r}")
    return candidate.as_posix()


def _rel(repo_root: Path, path: Path) -> str:
    # Final display helper only: caller must have passed _safe_repo_path first.
    # Uses lexical relative without resolving to avoid laundering; validates containment.
    root = repo_root.resolve()
    lexical = path if path.is_absolute() else (root / path)
    try:
        rel = lexical.relative_to(root)
    except ValueError as exc:
        raise _fail("ESCAPE", "PIN", "REFUSED_PRE_WRITE", f"display escapes repository: {path}") from exc
    for part in rel.parts:
        if part in ("..", ".", ""):
            raise _fail("UNSAFE_PART", "PIN", "REFUSED_PRE_WRITE", f"display unsafe component: {path}")
    return rel.as_posix()


def _safe(repo_root: Path, raw: str | Path, label: str) -> Path:
    # Raw-first safe path: lexical containment, then core.repo_local_path,
    # then held-ancestor + leaf checks via lstat (no follow), FIFO/socket refusal.
    # Actual initial-component discipline: lexical before resolve, then
    # core helper, then ancestor/leaf identity. Bounded regular-file check
    # is done by callers via _read_bytes_bounded / _check_file.
    rel = _lexical_rel(repo_root, raw, label)
    try:
        resolved = core.repo_local_path(repo_root, rel, label)
    except (TypeError, ValueError) as exc:
        raise _fail("ESCAPE", "PIN", "REFUSED_PRE_WRITE", f"{label} escapes repository: {raw!r}: {exc}") from exc
    root = repo_root.resolve()
    # Held-ancestor checks: every parent component from root must exist as
    # a real directory, never a symlink/FIFO/socket. Uses lstat (is_symlink
    # does not follow), so an aliased directory is refused before resolve.
    try:
        rel_parent = Path(rel).parent
        current = root
        # Walk lexical parents only (never resolved target) to preserve alias info.
        if str(rel_parent) not in (".", ""):
            for part in rel_parent.parts:
                current = current / part
                try:
                    st = os.lstat(current)
                except FileNotFoundError as exc:
                    raise _fail("MISSING_ANCESTOR", "PIN", "REFUSED_PRE_WRITE", f"{label} missing ancestor: {current}") from exc
                except OSError as exc:
                    raise _fail("ANCESTOR_CHECK", "PIN", "REFUSED_PRE_WRITE", f"{label} ancestor check failed: {exc}") from exc
                if stat.S_ISLNK(st.st_mode):
                    raise _fail("SYMLINK_ANCESTOR", "PIN", "REFUSED_PRE_WRITE", f"{label} symlinked ancestor: {current}")
                if stat.S_ISFIFO(st.st_mode) or stat.S_ISSOCK(st.st_mode):
                    raise _fail("FIFO_ANCESTOR", "PIN", "REFUSED_PRE_WRITE", f"{label} FIFO/socket ancestor: {current}")
                if not stat.S_ISDIR(st.st_mode):
                    raise _fail("ANCESTOR_NOT_DIR", "PIN", "REFUSED_PRE_WRITE", f"{label} ancestor not directory: {current}")
    except EditorialError:
        raise
    except Exception as exc:
        raise _fail("ANCESTOR_CHECK", "PIN", "REFUSED_PRE_WRITE", f"{label} ancestor check failed: {exc}") from exc
    # Leaf checks via lstat (no follow): refuse symlink/FIFO/socket, require regular file OR
    # absent leaf for writers (writers check existence separately via O_EXCL).
    try:
        lst = os.lstat(resolved)
    except FileNotFoundError:
        # Absent leaf is allowed here (writers claim exclusively via O_EXCL);
        # readers must check is_file separately via _check_file.
        return resolved
    except OSError as exc:
        raise _fail("LEAF_CHECK", "PIN", "REFUSED_PRE_WRITE", f"{label} leaf check failed: {exc}") from exc
    if stat.S_ISLNK(lst.st_mode):
        raise _fail("SYMLINK_LEAF", "PIN", "REFUSED_PRE_WRITE", f"{label} is symlink: {raw!r}")
    if stat.S_ISFIFO(lst.st_mode) or stat.S_ISSOCK(lst.st_mode):
        raise _fail("FIFO_LEAF", "PIN", "REFUSED_PRE_WRITE", f"{label} FIFO/socket refused (would block): {raw!r}")
    return resolved


def _check_file(repo_root: Path, rel: str, label: str) -> Path:
    # Strict regular-file check at final boundary: safe path + lstat regular +
    # bounded size + SHA available. Source/ancestor identity already checked
    # in _safe; this re-checks expected bytes at final boundary (not only before op).
    resolved = _safe(repo_root, rel, label)
    try:
        lst = os.lstat(resolved)
    except OSError as exc:
        raise _fail("MISSING", "PIN", "REFUSED_PRE_WRITE", f"{label} missing: {rel}: {exc}") from exc
    if not stat.S_ISREG(lst.st_mode):
        raise _fail("NOT_REGULAR", "PIN", "REFUSED_PRE_WRITE", f"{label} not regular file: {rel}")
    if lst.st_size < 1 or lst.st_size > 20 * 1024 * 1024:
        raise _fail("SIZE_BOUND", "PIN", "REFUSED_PRE_WRITE", f"{label} size out of bounds: {rel}")
    if resolved.is_symlink() or not resolved.is_file():
        raise _fail("MISSING", "PIN", "REFUSED_PRE_WRITE", f"{label} missing or unsafe: {rel}")
    return resolved


def _read_bytes_bounded(repo_root: Path, rel: str, label: str, max_bytes: int = 20 * 1024 * 1024) -> bytes:
    # Bounded regular-file read with O_NOFOLLOW (no symlink laundering, no FIFO blocking).
    resolved = _check_file(repo_root, rel, label)
    if resolved.stat().st_size > max_bytes:
        raise _fail("SIZE_BOUND", "PIN", "REFUSED_PRE_WRITE", f"{label} exceeds bound: {rel}")
    fd = None
    try:
        fd = os.open(resolved, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
    except OSError as exc:
        raise _fail("READ_FAILED", "PIN", "REFUSED_PRE_WRITE", f"{label} open failed (symlink/FIFO?): {exc}") from exc
    try:
        chunks: list[bytes] = []
        total = 0
        while True:
            data = os.read(fd, 65536)
            if not data:
                break
            total += len(data)
            if total > max_bytes:
                raise _fail("SIZE_BOUND", "PIN", "REFUSED_PRE_WRITE", f"{label} exceeds bound during read: {rel}")
            chunks.append(data)
        return b"".join(chunks)
    except OSError as exc:
        raise _fail("READ_FAILED", "PIN", "REFUSED_PRE_WRITE", f"{label} read failed: {exc}") from exc
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass


def _exclusive_write_bytes(path: Path, data: bytes, label: str) -> tuple[int, int]:
    # True exclusive writer: O_CREAT|O_EXCL|O_NOFOLLOW, no prior exists-check
    # trusted, no tmp+rename (which can overwrite a race winner), no unlink
    # of unknown tmp on errors. Short-write loop, fsync, fd-captured identity
    # (dev,ino via fstat), seek+readback through same fd, expected-byte
    # comparison. Preserves owned partial/unknown; reports primary error.
    # Held-ancestor checks: parent must be safe (no symlink/FIFO).
    if not isinstance(data, (bytes, bytearray)) or len(data) < 1:
        raise _fail("EMPTY_PAYLOAD", "WRITE", "REFUSED_PRE_WRITE", f"{label} empty payload refused")
    parent = path.parent
    try:
        parent.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise _fail("MKDIR_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} parent mkdir failed: {exc}") from exc
    # Held-ancestor check on parent (lexical, lstat, no follow).
    try:
        if path.is_absolute():
            # Path is already absolute under repo (from _safe); walk parents.
            # Use resolved root comparison via parent chain lstat.
            cur = parent
            # Walk up to 32 levels to avoid infinite loop; refuse symlink/FIFO.
            for _ in range(32):
                try:
                    st = os.lstat(cur)
                except FileNotFoundError:
                    break
                except OSError as exc:
                    raise _fail("ANCESTOR_CHECK", "WRITE", "REFUSED_PRE_WRITE", f"{label} ancestor check failed: {exc}") from exc
                if stat.S_ISLNK(st.st_mode):
                    raise _fail("SYMLINK_ANCESTOR", "WRITE", "REFUSED_PRE_WRITE", f"{label} symlinked ancestor: {cur}")
                if stat.S_ISFIFO(st.st_mode) or stat.S_ISSOCK(st.st_mode):
                    raise _fail("FIFO_ANCESTOR", "WRITE", "REFUSED_PRE_WRITE", f"{label} FIFO ancestor: {cur}")
                # Stop at filesystem root or when parent equals itself.
                nxt = cur.parent
                if nxt == cur:
                    break
                cur = nxt
                # Heuristic stop: if we reached a directory containing .git-like? No, walk fully.
                if len(str(cur)) < 2:
                    break
    except EditorialError:
        raise
    except Exception as exc:
        raise _fail("ANCESTOR_CHECK", "WRITE", "REFUSED_PRE_WRITE", f"{label} ancestor check failed: {exc}") from exc
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    nofollow = getattr(os, "O_NOFOLLOW", 0)
    if nofollow:
        flags |= nofollow
    fd = None
    try:
        fd = os.open(path, flags, 0o644)
    except FileExistsError as exc:
        raise _fail("TARGET_EXISTS", "WRITE", "REFUSED_PRE_WRITE", f"{label} already exists (no same-byte takeover): {path}") from exc
    except OSError as exc:
        raise _fail("WRITE_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} exclusive open failed: {exc}") from exc
    try:
        # Short-write loop.
        view = memoryview(bytes(data))
        offset = 0
        while offset < len(view):
            try:
                written = os.write(fd, view[offset:])
            except OSError as exc:
                raise _fail("WRITE_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} short write failed: {exc}") from exc
            if written <= 0:
                raise _fail("WRITE_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} short write returned 0")
            offset += written
        try:
            os.fsync(fd)
        except OSError:
            pass
        try:
            fst = os.fstat(fd)
            owned_id = (fst.st_dev, fst.st_ino)
        except OSError as exc:
            raise _fail("WRITE_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} identity capture failed: {exc}") from exc
        # Readback through same fd (lseek + read), never stat-after-close claim.
        try:
            os.lseek(fd, 0, os.SEEK_SET)
        except OSError as exc:
            raise _fail("WRITE_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} lseek failed: {exc}") from exc
        chunks: list[bytes] = []
        while True:
            try:
                part = os.read(fd, 65536)
            except OSError as exc:
                raise _fail("WRITE_FAILED", "WRITE", "PRESERVED_INCOMPLETE", f"{label} readback failed: {exc}") from exc
            if not part:
                break
            chunks.append(part)
        actual = b"".join(chunks)
        if actual != bytes(data):
            raise _fail("WRITE_MISMATCH", "WRITE", "PRESERVED_INCOMPLETE", f"{label} readback mismatch; live bytes preserved for manual recovery: {path}")
        return owned_id
    except EditorialError:
        # Preserve owned partial/unknown: never unlink on failure. Caller reports
        # primary + secondary; unknown bytes are never deleted as foreign.
        raise
    finally:
        if fd is not None:
            try:
                os.close(fd)
            except OSError:
                pass


def _exclusive_write_json(path: Path, payload: dict[str, Any], label: str) -> tuple[int, int]:
    # Exclusive JSON writer: canonical bytes, O_EXCL|NOFOLLOW, fd identity,
    # full-write/fsync/close/readback, final pin (re-read via safe path and
    # compare SHA). Preserves owned partial/unknown, primary+secondary errors.
    if not isinstance(payload, dict):
        raise _fail("PAYLOAD_SHAPE", "WRITE", "REFUSED_PRE_WRITE", f"{label} payload must be object")
    data = core.json_bytes(payload)
    owned = _exclusive_write_bytes(path, data, label)
    # Final pin: re-read via safe containment and compare SHA (not only fd).
    try:
        # Derive repo-relative for final pin if path is under a known repo?
        # Caller ensures path came from _safe; here verify bytes directly.
        if path.is_symlink() or not path.is_file():
            raise _fail("FINAL_PIN", "WRITE", "PRESERVED_INCOMPLETE", f"{label} final pin missing: {path}")
        if path.read_bytes() != data:
            raise _fail("FINAL_PIN", "WRITE", "PRESERVED_INCOMPLETE", f"{label} final pin mismatch; preserved: {path}")
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("FINAL_PIN", "WRITE", "PRESERVED_INCOMPLETE", f"{label} final pin failed: {exc}") from exc
    return owned


def _file_ref(repo_root: Path, path: Path) -> dict[str, Any]:
    # Final-boundary file_ref: safe path + regular-file + expected bytes at
    # final boundary (not only before operation). Uses bounded read for SHA.
    rel = _rel(repo_root, path)
    resolved = _check_file(repo_root, rel, "file ref")
    data = _read_bytes_bounded(repo_root, rel, "file ref")
    return {"path": rel, "sha256": core.sha256_bytes(data), "byte_count": len(data)}


def _artifact_ref(repo_root: Path, path: Path) -> dict[str, str]:
    rel = _rel(repo_root, path)
    resolved = _check_file(repo_root, rel, "artifact ref")
    data = _read_bytes_bounded(repo_root, rel, "artifact ref")
    return {"path": rel, "sha256": core.sha256_bytes(data)}


def _now_utc(recorded_at: datetime | None = None) -> datetime:
    if recorded_at is not None:
        if recorded_at.tzinfo is None:
            return recorded_at.replace(tzinfo=timezone.utc)
        return recorded_at.astimezone(timezone.utc)
    return datetime.now(timezone.utc)


def _require_scope_bound(root: Path, state_path: Path, proposal_path: Path, staged_manifest_path: Path) -> dict[str, Any]:
    # Genuine current-before P2V fresh at prewrite boundaries (not cached).
    # Calls actual low-level P2V observe_current_authority with exact retained
    # + scope refs; no fictional L helper, no hasattr fallback, no silent
    # fallback. If P2V helper is missing, reports exact need to root.
    for name in _UNSAFE_GIT_VARS:
        if os.environ.get(name):
            raise _fail("GIT_ENV", "PIN", "REFUSED_PRE_WRITE", f"inherited {name} refuses operation")
    try:
        from scripts import survey_editorial_current_authority_v2 as p2v
    except ImportError as exc:
        raise _fail("P2V_MISSING", "BEFORE", "REFUSED_PRE_WRITE", f"P2V current-authority module missing; need concrete P2V observe_current_authority to root: {exc}") from exc
    if not hasattr(p2v, "observe_current_authority"):
        raise _fail("P2V_MISSING", "BEFORE", "REFUSED_PRE_WRITE", "P2V observe_current_authority missing; need concrete helper to root, no silent fallback")
    # Raw-first safe pins for all inputs (lexical before resolve).
    state_rel = _lexical_rel(root, str(state_path), "Production State")
    proposal_rel = _lexical_rel(root, str(proposal_path), "proposal")
    staged_rel = _lexical_rel(root, str(staged_manifest_path), "staged manifest")
    _safe(root, state_rel, "Production State")
    _safe(root, proposal_rel, "proposal")
    staged_file = _safe(root, staged_rel, "staged manifest")
    try:
        staged = core.load_json(staged_file)
    except (OSError, ValueError) as exc:
        raise _fail("STAGED_UNREADABLE", "BEFORE", "REFUSED_PRE_WRITE", f"staged manifest unreadable: {exc}") from exc
    retention_ref = staged.get("retention_manifest_ref")
    if not isinstance(retention_ref, dict) or not isinstance(retention_ref.get("path"), str):
        raise _fail("RETENTION_REF", "BEFORE", "REFUSED_PRE_WRITE", "staged retention_manifest_ref must be exact {path,sha256}")
    retention_rel = _lexical_rel(root, retention_ref["path"], "retention manifest")
    _safe(root, retention_rel, "retention manifest")
    scope_ref = staged.get("scope_review_ref")
    scope_arg: str | Path | None = None
    if isinstance(scope_ref, dict) and isinstance(scope_ref.get("path"), str):
        scope_rel = _lexical_rel(root, scope_ref["path"], "scope review")
        _safe(root, scope_rel, "scope review")
        scope_arg = scope_rel
    # P2V fresh invocation (function-local, no import-time cycle). receipt_kind
    # None allows prepare/activate before-eligibility only; ordinary WEEKLY/
    # LONGFORM receipts are refused after activation inside P2V (C-owned guard).
    try:
        obs = p2v.observe_current_authority(root, state_rel, proposal_rel, retention_rel, scope_arg)
    except Exception as exc:
        raise _fail("NOT_SCOPE_BOUND", "BEFORE", "REFUSED_PRE_WRITE", f"P2V before-eligibility refused: {exc}") from exc
    if not isinstance(obs, dict) or obs.get("result") != "CURRENT_BASIS_OBSERVED_SCOPE_BOUND":
        raise _fail("NOT_SCOPE_BOUND", "BEFORE", "REFUSED_PRE_WRITE", f"P2V before-eligibility not SCOPE_BOUND: {obs.get('result') if isinstance(obs, dict) else obs!r}")
    return obs


def _verify_staged(root: Path, proposal_path: Path, staged_manifest_path: Path) -> dict[str, Any]:
    # Actual P3S historical proof (retained COPY, scope, replay, closed set).
    # No P2V future seal, no current activation. Returns typed verifier dict
    # with observed_refs/measured (actual source shape, not guessed).
    try:
        from scripts import survey_editorial_staged_source_v2 as staged
    except ImportError as exc:
        raise _fail("STAGED_MISSING", "PIN", "REFUSED_PRE_WRITE", f"P3S staged module missing; need concrete verify_staged_source to root: {exc}") from exc
    if not hasattr(staged, "verify_staged_source"):
        raise _fail("STAGED_MISSING", "PIN", "REFUSED_PRE_WRITE", "P3S verify_staged_source missing; need concrete helper to root")
    proposal_rel = _lexical_rel(root, str(proposal_path), "proposal")
    staged_rel = _lexical_rel(root, str(staged_manifest_path), "staged manifest")
    _safe(root, proposal_rel, "proposal")
    _safe(root, staged_rel, "staged manifest")
    try:
        return staged.verify_staged_source(root, proposal_rel, staged_rel)
    except Exception as exc:
        raise _fail("STAGED_REFUSED", "PIN", "REFUSED_PRE_WRITE", f"P3S staged proof refused: {exc}") from exc


def _proposal_dir(root: Path, proposal_path: Path) -> Path:
    p = _safe(root, proposal_path, "proposal")
    if p.name != "proposal.json":
        raise _fail("PROPOSAL_FILENAME", "PIN", "REFUSED_PRE_WRITE", "proposal file must be proposal.json")
    return p.parent


def _publication_dir(root: Path, proposal_path: Path) -> Path:
    return _proposal_dir(root, proposal_path) / "publication"


def validate_editorial_receipt(root: str | Path, receipt_path: str | Path, state_path: str | Path) -> dict[str, Any]:
    """Public editorial receipt: strict State + route authoring + tool closure + P3S proof + scope + replay.

    Inert-before-seal needs no active record. After activation the same
    validators select the new set and remain healthy; never requires current
    State to remain equal to the old before-State hash (no beforeState equality).
    Implements the full public contract independently (no delegation to callers).
    """
    repo = Path(root).resolve()
    receipt_rel = _lexical_rel(repo, str(receipt_path), "editorial receipt")
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    rpath = _safe(repo, receipt_rel, "editorial receipt")
    sfile = _safe(repo, state_rel, "Production State")
    receipt = schema_gate.load_and_validate_json(rpath, repo / EDITORIAL_RECEIPT_SCHEMA, label="editorial receipt")
    base = dict(receipt)
    recorded = base.pop("receipt_sha256", None)
    if core.sha256_object(base) != recorded:
        raise _fail("DIGEST_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "editorial receipt digest mismatch")
    # Strict State: exact file bytes + schema + agent basis (checkpoint/report/human/selection).
    try:
        state = core.load_json(sfile)
    except (OSError, ValueError) as exc:
        raise _fail("STATE_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"Production State unreadable: {exc}") from exc
    if not isinstance(state, dict):
        raise _fail("STATE_SHAPE", "VALIDATE", "REFUSED_PRE_WRITE", "Production State must be object")
    if receipt["issue_id"] != state.get("issue_id"):
        raise _fail("ISSUE_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "editorial receipt issue mismatch")
    if receipt["research_profile"] != state.get("research_profile") or receipt["publication_profile"] != state.get("publication_profile"):
        raise _fail("PROFILE_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "editorial receipt Profile mismatch vs strict State")
    try:
        cfg = core.load_json(_safe(repo, core.DEFAULT_CONFIG.as_posix(), "implementation config"))
    except (OSError, ValueError) as exc:
        raise _fail("CONFIG_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"implementation config unreadable: {exc}") from exc
    # Strict State via existing agent validator (local import, terminates via identity, no Gate/receipt recursion).
    try:
        from scripts import survey_agent_control_v2 as agent
    except ImportError as exc:
        raise _fail("AGENT_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"agent validator missing; need concrete validate_agent_state to root: {exc}") from exc
    if not hasattr(agent, "validate_agent_state"):
        raise _fail("AGENT_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", "agent validate_agent_state missing; need concrete helper to root")
    try:
        state_errors = agent.validate_agent_state(repo, cfg, state)
    except Exception as exc:
        raise _fail("STATE_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", f"strict State validation failed: {exc}") from exc
    if state_errors:
        raise _fail("STATE_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", "strict Production State invalid: " + "; ".join(state_errors))
    # Load proposal / staged / retention via exact receipt refs (no caller-verified dict).
    for key in ("proposal_ref", "retention_manifest_ref", "staged_manifest_ref", "scope_review_ref", "reviewed_reader_input"):
        ref = receipt.get(key)
        if not isinstance(ref, dict) or set(ref) != {"path", "sha256"}:
            raise _fail("RECEIPT_REF", "VALIDATE", "REFUSED_PRE_WRITE", f"editorial receipt {key} must be exact {{path,sha256}}")
        rel = _lexical_rel(repo, ref["path"], f"receipt {key}")
        resolved = _safe(repo, rel, f"receipt {key}")
        try:
            data = _read_bytes_bounded(repo, rel, f"receipt {key}")
        except EditorialError:
            raise
        except Exception as exc:
            raise _fail("INPUT_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", f"editorial input unreadable: {key}: {exc}") from exc
        if core.sha256_bytes(data) != ref["sha256"]:
            raise _fail("INPUT_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", f"editorial input drift: {key}")
    proposal_rel = receipt["proposal_ref"]["path"]
    staged_rel = receipt["staged_manifest_ref"]["path"]
    # Proposal must be exact P1 shape and bind same issue/Profile/route.
    try:
        proposal = core.load_json(_safe(repo, proposal_rel, "proposal"))
    except (OSError, ValueError) as exc:
        raise _fail("PROPOSAL_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"proposal unreadable: {exc}") from exc
    try:
        schema_gate.load_and_validate_json(_safe(repo, proposal_rel, "proposal"), repo / Path("schemas/editorial-correction-proposal-v2.schema.json"), label="editorial correction proposal")
    except (OSError, ValueError) as exc:
        raise _fail("PROPOSAL_SCHEMA", "VALIDATE", "REFUSED_PRE_WRITE", f"proposal schema invalid: {exc}") from exc
    for k in ("issue_id", "research_profile", "publication_profile"):
        if proposal.get(k) != receipt[k]:
            raise _fail("PROPOSAL_LABEL", "VALIDATE", "REFUSED_PRE_WRITE", f"proposal {k} differs from receipt")
    # Staged manifest must be exact P3S shape; refs must equal receipt refs.
    try:
        staged_manifest = core.load_json(_safe(repo, staged_rel, "staged manifest"))
    except (OSError, ValueError) as exc:
        raise _fail("STAGED_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"staged manifest unreadable: {exc}") from exc
    try:
        schema_gate.load_and_validate_json(_safe(repo, staged_rel, "staged manifest"), repo / Path("schemas/editorial-staged-source-manifest-v2.schema.json"), label="editorial staged source manifest")
    except (OSError, ValueError) as exc:
        raise _fail("STAGED_SCHEMA", "VALIDATE", "REFUSED_PRE_WRITE", f"staged manifest schema invalid: {exc}") from exc
    if staged_manifest.get("proposal_ref", {}).get("path") != receipt["proposal_ref"]["path"] or staged_manifest.get("proposal_ref", {}).get("sha256") != receipt["proposal_ref"]["sha256"]:
        raise _fail("PROPOSAL_REF_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "staged proposal_ref != receipt proposal_ref")
    if staged_manifest.get("retention_manifest_ref") != receipt["retention_manifest_ref"]:
        raise _fail("RETENTION_REF_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "staged retention_manifest_ref != receipt")
    if staged_manifest.get("scope_review_ref") != receipt["scope_review_ref"]:
        raise _fail("SCOPE_REF_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "staged scope_review_ref != receipt")
    if staged_manifest.get("issue_id") != receipt["issue_id"]:
        raise _fail("STAGED_LABEL", "VALIDATE", "REFUSED_PRE_WRITE", "staged issue != receipt")
    # Route derive NEW authoring + unchanged accepted Draft (actual P1 fields, no invention).
    # NEW proposed authoring must equal proposal proposed.authoring_input_ref.
    authored = {r["name"]: r for r in receipt["authored_refs"]}
    if set(authored) != {"proposed-publication-authoring", "accepted-draft-archive"}:
        raise _fail("AUTHORED_ROLES", "VALIDATE", "REFUSED_PRE_WRITE", "editorial authored refs must be proposed-publication-authoring + accepted-draft-archive")
    proposed_authoring_ref = (proposal.get("proposed") or {}).get("authoring_input_ref")
    if not isinstance(proposed_authoring_ref, dict) or authored["proposed-publication-authoring"] != proposed_authoring_ref:
        raise _fail("AUTHORED_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt proposed-publication-authoring must equal proposal proposed.authoring_input_ref")
    # Unchanged accepted Draft: accepted-draft-archive must equal the before
    # receipt's drafting archive (exact file from proposal basis
    # generated_receipt_ref, not a guessed path). Before receipt may be initial
    # (publication-semantic-input + drafting-authored-archive) or a prior
    # EDITORIAL (proposed-publication-authoring + accepted-draft-archive);
    # generic kind must not demand the initial-old authored role on repeat.
    basis = proposal.get("basis") or {}
    gen_receipt_ref = basis.get("generated_receipt_ref")
    if not isinstance(gen_receipt_ref, dict) or "path" not in gen_receipt_ref or "sha256" not in gen_receipt_ref:
        raise _fail("BASIS_RECEIPT", "VALIDATE", "REFUSED_PRE_WRITE", "proposal basis generated_receipt_ref invalid")
    gen_rel = _lexical_rel(repo, gen_receipt_ref["path"], "before generated receipt")
    _safe(repo, gen_rel, "before generated receipt")
    try:
        gen_data = _read_bytes_bounded(repo, gen_rel, "before generated receipt")
    except EditorialError:
        raise
    if core.sha256_bytes(gen_data) != gen_receipt_ref["sha256"]:
        raise _fail("BASIS_RECEIPT_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", "before generated receipt drift")
    try:
        gen_receipt = json.loads(gen_data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("BASIS_RECEIPT_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"before receipt not JSON: {exc}") from exc
    gen_authored = {r.get("name"): r for r in gen_receipt.get("authored_refs", []) if isinstance(r, dict)}
    gen_kind = gen_receipt.get("kind") if isinstance(gen_receipt, dict) else None
    # Generic before-receipt authored-role handling (no initial-old demand on repeat).
    if set(gen_authored) == {"publication-semantic-input", "drafting-authored-archive"}:
        draft_archive_ref = gen_authored.get("drafting-authored-archive")
        before_is_editorial = False
    elif set(gen_authored) == {"proposed-publication-authoring", "accepted-draft-archive"}:
        draft_archive_ref = gen_authored.get("accepted-draft-archive")
        before_is_editorial = True
        # Prior editorial kind must be exact when before is editorial.
        if gen_kind != "EDITORIAL_PUBLICATION_SOURCE_V1":
            raise _fail("BEFORE_KIND", "VALIDATE", "REFUSED_PRE_WRITE", "before editorial authored roles require EDITORIAL_PUBLICATION_SOURCE_V1 kind")
    else:
        raise _fail("BEFORE_AUTHORED", "VALIDATE", "REFUSED_PRE_WRITE", f"before receipt authored roles unknown (neither initial nor editorial): {sorted(gen_authored)}")
    if not isinstance(draft_archive_ref, dict) or "path" not in draft_archive_ref or "sha256" not in draft_archive_ref:
        raise _fail("ACCEPTED_DRAFT", "VALIDATE", "REFUSED_PRE_WRITE", "before receipt lacks drafting archive for accepted Draft")
    if authored["accepted-draft-archive"] != {"name": "accepted-draft-archive", "path": draft_archive_ref["path"], "sha256": draft_archive_ref["sha256"]} and authored["accepted-draft-archive"] != draft_archive_ref and authored["accepted-draft-archive"].get("path") != draft_archive_ref.get("path"):
        # Strict: path+sha must equal initial drafting archive (name differs by namespace, path+sha must match).
        if authored["accepted-draft-archive"].get("path") != draft_archive_ref.get("path") or authored["accepted-draft-archive"].get("sha256") != draft_archive_ref.get("sha256"):
            raise _fail("ACCEPTED_DRAFT_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt accepted-draft-archive must equal initial drafting-authored-archive path+sha")
    # Accepted refs: validation-checkpoint must equal strict State validation ref (current research).
    accepted = {r["name"]: r for r in receipt["accepted_refs"]}
    if "validation-checkpoint" not in accepted:
        raise _fail("ACCEPTED_ROLES", "VALIDATE", "REFUSED_PRE_WRITE", "receipt accepted refs must include validation-checkpoint")
    validation_ref = (state.get("checkpoint_provenance") or {}).get("validation")
    if not isinstance(validation_ref, dict) or accepted["validation-checkpoint"].get("path") != validation_ref.get("path") or accepted["validation-checkpoint"].get("sha256") != validation_ref.get("sha256"):
        raise _fail("ACCEPTED_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt validation-checkpoint must equal strict State validation ref")
    # Reviewed reader input must equal proposal proposed_reader_ref (exact NEW reader, canonical bytes).
    proposed_reader_ref = (proposal.get("proposed") or {}).get("proposed_reader_ref")
    if not isinstance(proposed_reader_ref, dict) or receipt["reviewed_reader_input"] != proposed_reader_ref:
        raise _fail("REVIEWED_INPUT_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt reviewed_reader_input must equal proposal proposed_reader_ref")
    proposed_canonical = (proposal.get("proposed") or {}).get("proposed_reader_canonical_sha256")
    if proposed_reader_ref.get("sha256") != proposed_canonical:
        raise _fail("PROPOSED_DIGEST", "VALIDATE", "REFUSED_PRE_WRITE", "proposal proposed reader sha != canonical sha")
    # Early scope binding: scope file must be exact P1 scope review targeting reviewed_reader_input.
    scope_rel = receipt["scope_review_ref"]["path"]
    try:
        scope_data = _read_bytes_bounded(repo, scope_rel, "scope review")
        scope_obj = json.loads(scope_data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("SCOPE_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"scope review not JSON: {exc}") from exc
    if not isinstance(scope_obj, dict):
        raise _fail("SCOPE_SHAPE", "VALIDATE", "REFUSED_PRE_WRITE", "scope review must be object")
    reviewed_surface = scope_obj.get("reviewed_surface") or {}
    if reviewed_surface.get("path") != receipt["reviewed_reader_input"]["path"] or reviewed_surface.get("sha256") != receipt["reviewed_reader_input"]["sha256"]:
        raise _fail("SCOPE_BINDING", "VALIDATE", "REFUSED_PRE_WRITE", "scope reviewed_surface must equal receipt reviewed_reader_input (exact early review, not postrender)")
    # Scope must not be a postrender semantic PASS for PDF (must carry editorial_correction_scope block).
    scope_block = scope_obj.get("editorial_correction_scope")
    if not isinstance(scope_block, dict) or scope_block.get("version") != "EDITORIAL_CORRECTION_SCOPE_V1":
        raise _fail("SCOPE_BLOCK", "VALIDATE", "REFUSED_PRE_WRITE", "scope missing editorial_correction_scope V1 (not postrender semantic)")
    if scope_block.get("decision") != "WITHIN_APPROVED_AUTHORITY":
        raise _fail("SCOPE_DECISION", "VALIDATE", "REFUSED_PRE_WRITE", "scope decision must be WITHIN_APPROVED_AUTHORITY")
    if scope_block.get("before_reader_input") != basis.get("active_reader_input_ref"):
        raise _fail("SCOPE_BEFORE", "VALIDATE", "REFUSED_PRE_WRITE", "scope before_reader must equal proposal basis active_reader_input_ref")
    # P2R/P3S historical replay via actual source proof (no P2V future seal, no current activation).
    # Verifier dict shape is actual source: STAGED_SOURCE_REPLAY_VERIFIED with
    # {proposal_ref, staged_manifest_ref, observed_refs, measured, code_deps}.
    proof = _verify_staged(repo, proposal_rel, staged_rel)
    if not isinstance(proof, dict) or proof.get("result") != "STAGED_SOURCE_REPLAY_VERIFIED":
        raise _fail("PROOF_RESULT", "VALIDATE", "REFUSED_PRE_WRITE", f"staged proof not VERIFIED: {proof.get('result') if isinstance(proof, dict) else proof!r}")
    if proof.get("proposal_ref") != receipt["proposal_ref"] or proof.get("staged_manifest_ref") != receipt["staged_manifest_ref"]:
        raise _fail("PROOF_REF", "VALIDATE", "REFUSED_PRE_WRITE", "staged proof refs != receipt refs")
    observed = proof.get("observed_refs") or {}
    if observed.get("retention_manifest_ref") != receipt["retention_manifest_ref"] or observed.get("scope_review_ref") != receipt["scope_review_ref"]:
        raise _fail("PROOF_OBSERVED", "VALIDATE", "REFUSED_PRE_WRITE", "staged observed retention/scope != receipt")
    # Exact source replay: receipt outputs (primary/bibliography/style) must equal
    # staged outputs (main/bibliography/style) with main→primary mapping (NOT primary alias, no staged_refs).
    staged_outputs = staged_manifest.get("outputs")
    if not isinstance(staged_outputs, dict) or set(staged_outputs) != {"main", "bibliography", "style"}:
        raise _fail("STAGED_OUTPUTS", "VALIDATE", "REFUSED_PRE_WRITE", "staged outputs must be exact {main,bibliography,style} (NOT primary, no staged_refs alias)")
    mapping = (("primary", "main"), ("bibliography", "bibliography"), ("style", "style"))
    for receipt_name, staged_name in mapping:
        out = receipt["outputs"].get(receipt_name)
        ref = staged_outputs.get(staged_name)
        if not isinstance(out, dict) or set(out) != {"path", "sha256"}:
            raise _fail("RECEIPT_OUTPUT", "VALIDATE", "REFUSED_PRE_WRITE", f"receipt output {receipt_name} must be exact {{path,sha256}}")
        if not isinstance(ref, dict) or set(ref) != {"path", "sha256", "byte_count"}:
            raise _fail("STAGED_OUTPUT", "VALIDATE", "REFUSED_PRE_WRITE", f"staged output {staged_name} must be exact {{path,sha256,byte_count}}")
        if out.get("path") != ref.get("path") or out.get("sha256") != ref.get("sha256"):
            raise _fail("TRIO_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", f"receipt {receipt_name} differs from staged {staged_name} (main→primary mapping)")
        # Exact canonical FILE bytes + rendered output bytes (staged proof already
        # proved deterministic replay; here re-check file bytes at final boundary).
        try:
            file_bytes = _read_bytes_bounded(repo, out["path"], f"editorial output {receipt_name}")
        except EditorialError:
            raise
        if core.sha256_bytes(file_bytes) != out["sha256"]:
            raise _fail("OUTPUT_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", f"editorial output drift: {receipt_name}")
        if len(file_bytes) != ref.get("byte_count"):
            raise _fail("OUTPUT_SIZE", "VALIDATE", "REFUSED_PRE_WRITE", f"editorial output byte_count mismatch: {receipt_name}")
    # Independent route-loader rederivation on NEW proposed authoring projection
    # (not OLD initial publication-semantic-input). Calls actual
    # weekly.load_derivation / longform.load_derivation_for_readback on exact
    # proposal.proposed.authoring_input_ref; compares ctx.surface canonical
    # bytes to actual proposed reader AND receipt.accepted_refs context to
    # ctx.accepted_refs AND accepted Draft archive to ctx.archive. Generic
    # before receipt kind must not demand initial-old authored role on repeat.
    # P3S historical proof already verified above; no P2V in ordinary receipt
    # after activation (we never call P2V here).
    # NEW proposed authoring file must exist with pinned SHA.
    try:
        new_authoring_rel = _lexical_rel(repo, proposed_authoring_ref["path"], "NEW proposed authoring")
        _safe(repo, new_authoring_rel, "NEW proposed authoring")
        new_authoring_bytes = _read_bytes_bounded(repo, new_authoring_rel, "NEW proposed authoring")
    except EditorialError:
        raise
    except Exception as exc:
        raise _fail("NEW_AUTHORED", "VALIDATE", "REFUSED_PRE_WRITE", f"NEW proposed authoring unreadable: {exc}") from exc
    if core.sha256_bytes(new_authoring_bytes) != proposed_authoring_ref.get("sha256"):
        raise _fail("NEW_AUTHORED_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", "NEW proposed authoring drift vs proposal ref")
    # Route-loader rederivation via actual Weekly/Longform loaders (function-local, no P2V).
    if receipt.get("generator_route") == "WEEKLY_GENERATED_V2":
        try:
            from scripts import survey_weekly_derivation_v2 as _weekly_r
        except ImportError as exc:
            raise _fail("WEEKLY_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"weekly loader missing: {exc}") from exc
        try:
            ctx = _weekly_r.load_derivation(repo, _safe(repo, state_rel, "Production State"), _safe(repo, new_authoring_rel, "NEW proposed authoring"))
        except Exception as exc:
            raise _fail("ROUTE_REDERIVE", "VALIDATE", "REFUSED_PRE_WRITE", f"weekly load_derivation on NEW authoring failed: {exc}") from exc
        # Accepted research: before-initial full list must equal ctx; before-editorial
        # carries only validation-checkpoint (already bound to State), so skip full
        # equality and rely on retained archive + surface checks below.
        try:
            ctx_accepted = ctx.get("accepted_refs", [])
            if not before_is_editorial:
                gen_accepted = gen_receipt.get("accepted_refs", [])
                def _norm(rows):
                    if not isinstance(rows, list):
                        return None
                    normed = []
                    for r in rows:
                        if not isinstance(r, dict) or set(r) != {"name", "path", "sha256"}:
                            return None
                        normed.append((r["name"], r["path"], r["sha256"]))
                    if len(normed) != len(set(n[0] for n in normed)):
                        return None
                    return sorted(normed)
                if _norm(gen_accepted) != _norm(ctx_accepted):
                    raise _fail("ACCEPTED_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "before-initial accepted refs != NEW authoring context (research changed)")
            # Accepted Draft archive to ctx.archive: ctx archive_path file must
            # equal receipt accepted-draft-archive path+sha and before draft ref.
            arch_path = ctx.get("archive_path")
            if arch_path is None:
                raise _fail("CTX_ARCHIVE", "VALIDATE", "REFUSED_PRE_WRITE", "weekly context lacks archive_path")
            arch_rel = str(arch_path.relative_to(repo.resolve())) if isinstance(arch_path, Path) and arch_path.is_absolute() else str(arch_path)
            # Normalize to repo-relative posix for comparison.
            try:
                ctx_arch_bytes = _read_bytes_bounded(repo, _lexical_rel(repo, arch_rel, "ctx archive"), "ctx archive")
            except EditorialError:
                raise
            if core.sha256_bytes(ctx_arch_bytes) != authored["accepted-draft-archive"].get("sha256"):
                raise _fail("ARCHIVE_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt accepted-draft-archive sha != ctx.archive bytes")
            if _lexical_rel(repo, authored["accepted-draft-archive"]["path"], "receipt archive") != _lexical_rel(repo, arch_rel, "ctx archive"):
                raise _fail("ARCHIVE_PATH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt accepted-draft-archive path != ctx.archive path")
            if authored["accepted-draft-archive"].get("path") != draft_archive_ref.get("path") or authored["accepted-draft-archive"].get("sha256") != draft_archive_ref.get("sha256"):
                raise _fail("ARCHIVE_BEFORE", "VALIDATE", "REFUSED_PRE_WRITE", "receipt archive != before receipt draft archive")
        except EditorialError:
            raise
        except Exception as exc:
            raise _fail("ACCEPTED_COMPARE", "VALIDATE", "REFUSED_PRE_WRITE", f"accepted/archive compare failed: {exc}") from exc
        # ctx.surface canonical bytes to actual proposed reader: dict equality
        # with independently validated reviewed reader (NEW), plus staged replay.
        try:
            reviewed_bytes = _read_bytes_bounded(repo, receipt["reviewed_reader_input"]["path"], "reviewed reader")
            reviewed_obj = _weekly_r.validate_reader_input(repo, _safe(repo, receipt["reviewed_reader_input"]["path"], "reviewed reader"))
            if ctx.get("surface") != reviewed_obj:
                raise _fail("SURFACE_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "ctx.surface from NEW authoring != actual proposed reader bytes")
            main_text = _weekly_r.render_main(reviewed_obj)
            bib_text = _weekly_r.render_bibliography(reviewed_obj)
            _weekly_r.validate_generated_closure(main_text, _read_bytes_bounded(repo, staged_outputs["style"]["path"], "staged style").decode("utf-8", errors="strict"))
            if core.sha256_bytes(main_text.encode("utf-8")) != staged_outputs["main"]["sha256"] or core.sha256_bytes(bib_text.encode("utf-8")) != staged_outputs["bibliography"]["sha256"]:
                raise _fail("REPLAY_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "weekly render replay != staged main/bib")
            if len(reviewed_bytes) < 1:
                raise _fail("REVIEWED_EMPTY", "VALIDATE", "REFUSED_PRE_WRITE", "reviewed reader empty")
        except EditorialError:
            raise
        except Exception as exc:
            raise _fail("REPLAY_FAILED", "VALIDATE", "REFUSED_PRE_WRITE", f"weekly NEW-authoring rederivation/replay failed: {exc}") from exc
    elif receipt.get("generator_route") == "LONGFORM_GENERATED_V1":
        try:
            from scripts import survey_longform_derivation_v2 as _longform_r
            from scripts import survey_longform_generated_v2 as _longform_g
        except ImportError as exc:
            raise _fail("LONGFORM_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"longform loader missing: {exc}") from exc
        try:
            ctx = _longform_r.load_derivation_for_readback(repo, _safe(repo, state_rel, "Production State"), _safe(repo, new_authoring_rel, "NEW proposed authoring"))
        except Exception as exc:
            raise _fail("ROUTE_REDERIVE", "VALIDATE", "REFUSED_PRE_WRITE", f"longform load_derivation_for_readback on NEW authoring failed: {exc}") from exc
        try:
            ctx_accepted = ctx.get("accepted_refs", [])
            if not before_is_editorial:
                gen_accepted = gen_receipt.get("accepted_refs", [])
                def _norm2(rows):
                    if not isinstance(rows, list):
                        return None
                    normed = []
                    for r in rows:
                        if not isinstance(r, dict) or set(r) != {"name", "path", "sha256"}:
                            return None
                        normed.append((r["name"], r["path"], r["sha256"]))
                    if len(normed) != len(set(n[0] for n in normed)):
                        return None
                    return sorted(normed)
                if _norm2(gen_accepted) != _norm2(ctx_accepted):
                    raise _fail("ACCEPTED_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "before-initial accepted refs != NEW authoring context")
            arch_path_lf = ctx.get("archive_path")
            if arch_path_lf is None:
                raise _fail("CTX_ARCHIVE", "VALIDATE", "REFUSED_PRE_WRITE", "longform context lacks archive_path")
            arch_rel_lf = str(arch_path_lf.relative_to(repo.resolve())) if isinstance(arch_path_lf, Path) and arch_path_lf.is_absolute() else str(arch_path_lf)
            try:
                ctx_arch_bytes_lf = _read_bytes_bounded(repo, _lexical_rel(repo, arch_rel_lf, "ctx archive"), "ctx archive")
            except EditorialError:
                raise
            if core.sha256_bytes(ctx_arch_bytes_lf) != authored["accepted-draft-archive"].get("sha256"):
                raise _fail("ARCHIVE_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt accepted-draft-archive sha != ctx.archive bytes")
            if _lexical_rel(repo, authored["accepted-draft-archive"]["path"], "receipt archive") != _lexical_rel(repo, arch_rel_lf, "ctx archive"):
                raise _fail("ARCHIVE_PATH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt accepted-draft-archive path != ctx.archive path")
            if authored["accepted-draft-archive"].get("path") != draft_archive_ref.get("path") or authored["accepted-draft-archive"].get("sha256") != draft_archive_ref.get("sha256"):
                raise _fail("ARCHIVE_BEFORE", "VALIDATE", "REFUSED_PRE_WRITE", "receipt archive != before receipt draft archive")
        except EditorialError:
            raise
        except Exception as exc:
            raise _fail("ACCEPTED_COMPARE", "VALIDATE", "REFUSED_PRE_WRITE", f"accepted/archive compare failed: {exc}") from exc
        try:
            reviewed_path_safe = _safe(repo, receipt["reviewed_reader_input"]["path"], "reviewed reader")
            reviewed_bytes_lf = _read_bytes_bounded(repo, receipt["reviewed_reader_input"]["path"], "reviewed reader")
            reviewed_obj_lf = _longform_r.validate_longform_reader_input(repo, reviewed_path_safe)
            if reviewed_bytes_lf != _longform_r.canonical_reader_bytes(reviewed_obj_lf):
                raise _fail("CANONICAL_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "longform reviewed FILE != canonical bytes")
            if ctx.get("surface") != reviewed_obj_lf:
                raise _fail("SURFACE_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "ctx.surface from NEW authoring != actual proposed reader")
            main_text_lf = _longform_g.render_main(reviewed_obj_lf)
            bib_text_lf = _longform_g.render_bibliography(reviewed_obj_lf)
            _longform_g.validate_heading_syntax(reviewed_obj_lf)
            style_text_lf = _read_bytes_bounded(repo, staged_outputs["style"]["path"], "staged style").decode("utf-8", errors="strict")
            _longform_g.validate_generated_closure(main_text_lf, style_text_lf)
            if core.sha256_bytes(main_text_lf.encode("utf-8")) != staged_outputs["main"]["sha256"] or core.sha256_bytes(bib_text_lf.encode("utf-8")) != staged_outputs["bibliography"]["sha256"]:
                raise _fail("REPLAY_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "longform render replay != staged")
        except EditorialError:
            raise
        except Exception as exc:
            raise _fail("REPLAY_FAILED", "VALIDATE", "REFUSED_PRE_WRITE", f"longform NEW-authoring rederivation/replay failed: {exc}") from exc
    else:
        raise _fail("ROUTE_UNKNOWN", "VALIDATE", "REFUSED_PRE_WRITE", f"unknown generator_route: {receipt.get('generator_route')!r}")
    # Current tools exact union/committed bytes/contract (epoch consistency, not recency).
    # Editorial closure is the fixed exact union 50 (P3S route 50), not 22/27 only.
    tools = receipt["current_tools"]
    if not isinstance(tools, dict) or set(tools) != {"repository_commit_sha", "contract", "closure"}:
        raise _fail("TOOLS_SHAPE", "VALIDATE", "REFUSED_PRE_WRITE", "receipt current_tools must be exact {repository_commit_sha,contract,closure}")
    generator_route = receipt["generator_route"]
    expected_closure = _editorial_closure_rows(repo, generator_route)
    got_closure = tools.get("closure")
    if not isinstance(got_closure, list):
        raise _fail("CLOSURE_SHAPE", "VALIDATE", "REFUSED_PRE_WRITE", "receipt closure must be list")
    # Exact union set: sorted-unique names, paths equal names, SHA equal current bytes.
    expected_by_name = {r["name"]: r for r in expected_closure}
    got_by_name = {}
    for row in got_closure:
        if not isinstance(row, dict) or set(row) != {"name", "path", "sha256"}:
            raise _fail("CLOSURE_ROW", "VALIDATE", "REFUSED_PRE_WRITE", "receipt closure row must be exact {name,path,sha256}")
        if row["name"] in got_by_name:
            raise _fail("CLOSURE_DUP", "VALIDATE", "REFUSED_PRE_WRITE", f"receipt closure duplicate: {row['name']}")
        got_by_name[row["name"]] = row
    if set(got_by_name) != set(expected_by_name):
        raise _fail("CLOSURE_SET", "VALIDATE", "REFUSED_PRE_WRITE", f"receipt closure set must equal expected union 50 ({generator_route}): missing={sorted(set(expected_by_name)-set(got_by_name))} extra={sorted(set(got_by_name)-set(expected_by_name))}")
    for name, exp in expected_by_name.items():
        got = got_by_name[name]
        if got["path"] != exp["path"] or got["path"] != name:
            raise _fail("CLOSURE_PATH", "VALIDATE", "REFUSED_PRE_WRITE", f"receipt closure path must equal name: {name}")
        try:
            cur_bytes = _read_bytes_bounded(repo, got["path"], f"closure {name}")
        except EditorialError:
            raise
        if core.sha256_bytes(cur_bytes) != got["sha256"] or core.sha256_bytes(cur_bytes) != exp["sha256"]:
            raise _fail("CLOSURE_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", f"editorial closure drift: {name}")
    # Current contract must equal current repository contract (tool closure).
    try:
        current_contract = core.contract_identity(repo, cfg, state.get("research_profile"), state.get("publication_profile"))
    except (ValueError, KeyError) as exc:
        raise _fail("CONTRACT_IDENTITY", "VALIDATE", "REFUSED_PRE_WRITE", f"current contract identity failed: {exc}") from exc
    if tools["contract"] != current_contract:
        raise _fail("CONTRACT_MISMATCH", "VALIDATE", "REFUSED_PRE_WRITE", "receipt current contract differs from current repository (epoch consistency)")
    # Repository commit must be ancestor of HEAD and control paths unchanged.
    # Existing route verify_tool_basis controls whole control roots runs on same
    # commit/contract + filtered canonical closure subset (Weekly 22 / Longform 27),
    # then independently verify extra editorial closure. Do not handwave
    # control-root immutability by checking only closure hash. Real old initial
    # receipts 22/27 remain valid via existing route helpers; no old-epoch migration.
    # P3S 50 runtime binding allows legitimate imported new modules (verified via
    # _route_code_deps edge audit in staged module; extra import requires expansion).
    try:
        import subprocess as _sp
        head = core.repository_commit_sha(repo)
        commit = tools["repository_commit_sha"]
        if len(commit) != 40 or any(c not in "0123456789abcdef" for c in commit):
            raise _fail("COMMIT_SHAPE", "VALIDATE", "REFUSED_PRE_WRITE", "receipt commit must be lowercase 40-hex")
        valid = _sp.run(["git", "cat-file", "-e", f"{commit}^{{commit}}"], cwd=repo, capture_output=True)
        if valid.returncode != 0:
            raise _fail("COMMIT_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", "receipt commit missing")
        anc = _sp.run(["git", "merge-base", "--is-ancestor", commit, head], cwd=repo, capture_output=True)
        if anc.returncode != 0:
            raise _fail("COMMIT_ANCESTOR", "VALIDATE", "REFUSED_PRE_WRITE", "receipt commit not ancestor of HEAD")
        # Filtered canonical subset via existing route helper (control roots + contract).
        canonical_names = set(_canonical_closure_names(generator_route))
        filtered_closure = [r for r in got_closure if r["name"] in canonical_names]
        if len(filtered_closure) != len(canonical_names):
            raise _fail("CLOSURE_FILTER", "VALIDATE", "REFUSED_PRE_WRITE", f"filtered canonical closure size mismatch: {len(filtered_closure)} != {len(canonical_names)}")
        # Control-root immutability + contract check via actual route helper on same commit.
        if generator_route == "WEEKLY_GENERATED_V2":
            from scripts import survey_weekly_derivation_v2 as _weekly_v
            # _verify_head_bytes checks control roots, contract, dirty/untracked, and closure bytes vs both commit and HEAD.
            _weekly_v._verify_head_bytes(repo, commit, filtered_closure)
        else:
            from scripts import survey_longform_generated_v2 as _longform_v
            # verify_tool_basis checks control roots, contract, dirty/untracked, and closure bytes vs both bases.
            _longform_v.verify_tool_basis(repo, {"repository_commit_sha": commit, "contract": tools["contract"], "closure": filtered_closure})
        # Independently verify extra editorial closure (50 minus canonical) vs commit + current bytes.
        # Extra rows are already checked vs current bytes above; here check vs recorded commit blobs.
        for row in got_closure:
            if row["name"] in canonical_names:
                continue
            res = _sp.run(["git", "show", f"{commit}:{row['name']}"], cwd=repo, capture_output=True)
            if res.returncode != 0:
                raise _fail("CLOSURE_EXTRA_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"extra editorial closure missing at commit: {row['name']}")
            import hashlib as _hl
            if _hl.sha256(res.stdout).hexdigest() != row["sha256"]:
                raise _fail("CLOSURE_EXTRA_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", f"extra editorial closure differs from commit: {row['name']}")
    except EditorialError:
        raise
    except ValueError as exc:
        raise _fail("CLOSURE_VERIFY", "VALIDATE", "REFUSED_PRE_WRITE", f"closure verify failed: {exc}") from exc
    except Exception as exc:
        raise _fail("COMMIT_CHECK", "VALIDATE", "REFUSED_PRE_WRITE", f"receipt commit check failed: {exc}") from exc
    # No beforeState hash equality after activation: this validator never compares
    # current State SHA to old before-State hash. Inert set needs no active pointer,
    # but all current proofs above still apply (strict State, closure, replay).
    return receipt


def _validate_toolchain_spec(repo: Path, spec_path: Path) -> dict[str, Any]:
    # Strict toolchain: absolute exe, fixed recipe allowlist, exact argv allowlist,
    # allowlisted env only (no ambient root override), recipe hash/input-copy checks.
    spec_rel = _lexical_rel(repo, str(spec_path), "toolchain spec")
    spec_file = _safe(repo, spec_rel, "toolchain spec")
    spec = schema_gate.load_and_validate_json(spec_file, repo / TOOLCHAIN_SPEC_SCHEMA, label="toolchain spec")
    exe_raw = spec.get("absolute_executable")
    if not isinstance(exe_raw, str) or not exe_raw or "\\" in exe_raw:
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", "toolchain executable must be non-empty repo-external absolute string")
    exe = Path(exe_raw)
    if not exe.is_absolute():
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", "toolchain executable must be absolute")
    if ".." in exe.parts or "." in exe.parts:
        raise _fail("TOOLCHAIN_EXE", "PIN", "REFUSED_PRE_WRITE", "toolchain executable unsafe component")
    # Real executable + companion resolution (no PATH lookup, no shell).
    # Explicit external executor: resolve declared symlink chain once, pin
    # link+real + hash/version, use link argv0 (lualatex formatting) with stable
    # recheck at build. Repo alias refusal does not apply to external executor.
    _link, _real, _real_sha = _resolve_toolchain_executable(exe, "toolchain executable")
    # Fixed recipe allowlist; no caller shell string, no latexmk -e, no output-root override.
    # EXACT argv: spec.argv must equal the expected allowlist tuple for its recipe (not permissive token membership),
    # matching the executed argv recorded in the build record. Bare tool names (no absolute paths in argv);
    # absolute exe/companion are recorded separately.
    if spec.get("recipe") not in ("lualatex-biber-lualatex", "latexmk-lualatex"):
        raise _fail("TOOLCHAIN_RECIPE", "PIN", "REFUSED_PRE_WRITE", f"unsupported recipe: {spec.get('recipe')!r}")
    argv = spec.get("argv", [])
    if not isinstance(argv, list) or not all(isinstance(t, str) for t in argv):
        raise _fail("TOOLCHAIN_ARGV", "PIN", "REFUSED_PRE_WRITE", "toolchain argv must be string array")
    expected_argv = list(EXPECTED_ARGV_LUALATEX_BIBER) if spec.get("recipe") == "lualatex-biber-lualatex" else list(EXPECTED_ARGV_LATEXMK)
    if argv != expected_argv:
        raise _fail("TOOLCHAIN_ARGV", "PIN", "REFUSED_PRE_WRITE", f"toolchain argv must EXACTLY equal fixed recipe {spec.get('recipe')}: expected {expected_argv!r} got {argv!r}")
    # Allowlisted env only; no GIT_*/PATH/PYTHONPATH root overrides; values plain strings (no newline/NUL).
    # PATH is refused in spec (build sets explicit companion-dir PATH); HOME allowed only if documented.
    env = spec.get("env", {})
    if not isinstance(env, dict):
        raise _fail("TOOLCHAIN_ENV", "PIN", "REFUSED_PRE_WRITE", "toolchain env must be object")
    for key, val in env.items():
        if key not in ALLOWED_ENV_KEYS:
            raise _fail("TOOLCHAIN_ENV", "PIN", "REFUSED_PRE_WRITE", f"toolchain env not allowlisted: {key}")
        if key.startswith("GIT_") or key in ("PATH", "PYTHONPATH", "LD_LIBRARY_PATH"):
            raise _fail("TOOLCHAIN_ENV", "PIN", "REFUSED_PRE_WRITE", f"toolchain env root override refused: {key}")
        if not isinstance(val, str):
            raise _fail("TOOLCHAIN_ENV", "PIN", "REFUSED_PRE_WRITE", f"toolchain env value must be string: {key}")
        if "\n" in val or "\x00" in val:
            raise _fail("TOOLCHAIN_ENV", "PIN", "REFUSED_PRE_WRITE", f"toolchain env value unsafe: {key}")
    # Recipe .latexmkrc hash copy: must exist as regular file, pinned now.
    # Actual latexmk consistent file: must contain fixed markers (pdf_mode, lualatex, biber).
    recipe_file = _safe(repo, RECIPE_REF.as_posix(), "recipe .latexmkrc")
    try:
        recipe_bytes = _read_bytes_bounded(repo, RECIPE_REF.as_posix(), "recipe .latexmkrc")
    except EditorialError:
        raise
    if len(recipe_bytes) < 1:
        raise _fail("RECIPE_MISSING", "PIN", "REFUSED_PRE_WRITE", "recipe .latexmkrc empty")
    try:
        recipe_text = recipe_bytes.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise _fail("RECIPE_MISSING", "PIN", "REFUSED_PRE_WRITE", f"recipe .latexmkrc not utf-8: {exc}") from exc
    for marker in REQUIRED_RECIPE_MARKERS:
        if marker not in recipe_text:
            raise _fail("RECIPE_INCONSISTENT", "PIN", "REFUSED_PRE_WRITE", f"recipe .latexmkrc missing marker {marker!r} (latexmk inconsistent)")
    return spec


def _validate_manuscript_spec(repo: Path, spec_path: Path, issue_id: str) -> dict[str, Any]:
    spec_rel = _lexical_rel(repo, str(spec_path), "manuscript spec")
    spec_file = _safe(repo, spec_rel, "manuscript spec")
    spec = schema_gate.load_and_validate_json(spec_file, repo / MANUSCRIPT_SPEC_SCHEMA, label="manuscript spec")
    if spec["issue_id"] != issue_id:
        raise _fail("SPEC_ISSUE", "PIN", "REFUSED_PRE_WRITE", "manuscript spec issue mismatch")
    # Proposal ref must be exact {path,sha256} and match actual proposal file.
    proposal_ref = spec.get("proposal_ref")
    if not isinstance(proposal_ref, dict) or set(proposal_ref) != {"path", "sha256"}:
        raise _fail("SPEC_PROPOSAL_REF", "PIN", "REFUSED_PRE_WRITE", "manuscript spec proposal_ref must be exact {path,sha256}")
    proposal_rel = _lexical_rel(repo, proposal_ref["path"], "manuscript spec proposal")
    _safe(repo, proposal_rel, "manuscript spec proposal")
    try:
        proposal_bytes = _read_bytes_bounded(repo, proposal_rel, "manuscript spec proposal")
    except EditorialError:
        raise
    if core.sha256_bytes(proposal_bytes) != proposal_ref["sha256"]:
        raise _fail("SPEC_PROPOSAL_DRIFT", "PIN", "REFUSED_PRE_WRITE", "manuscript spec proposal bytes drift")
    # Coverage/requirement assertions use actual existing fields (FULFILLED accountability claims only).
    for row in spec.get("architecture_coverage", []):
        if set(row) != {"package_id", "requirement", "status", "reader_locations", "detail"} or row.get("status") != "FULFILLED":
            raise _fail("SPEC_COVERAGE", "PIN", "REFUSED_PRE_WRITE", "manuscript spec coverage fields invalid")
        if not isinstance(row.get("package_id"), str) or not row["package_id"].strip():
            raise _fail("SPEC_COVERAGE", "PIN", "REFUSED_PRE_WRITE", "manuscript spec coverage package_id empty")
    for row in spec.get("reader_requirements", []):
        if set(row) != {"requirement_id", "status", "reader_locations", "detail"} or row.get("status") != "FULFILLED":
            raise _fail("SPEC_REQUIREMENTS", "PIN", "REFUSED_PRE_WRITE", "manuscript spec requirement fields invalid")
        if not isinstance(row.get("requirement_id"), str) or not row["requirement_id"].strip():
            raise _fail("SPEC_REQUIREMENTS", "PIN", "REFUSED_PRE_WRITE", "manuscript spec requirement_id empty")
    return spec


def _run_disposable_build(repo: Path, staged_manifest: dict[str, Any], toolchain_spec: dict[str, Any]) -> dict[str, Any]:
    # Real build: exact trio (main/bibliography/style, NOT primary, no staged_refs alias),
    # absolute exe + fixed argv + allowlisted env + recipe hash/input-copy checks,
    # source unchanged pre/post, real PDF/log gates/pages/digest. Preserves failed
    # build root + full raw (no rmtree/truncation). Exclusive transfer is done by
    # caller via pinned known bytes + final readback (no false glob CAS).
    outputs = staged_manifest.get("outputs")
    if not isinstance(outputs, dict) or set(outputs) != {"main", "bibliography", "style"}:
        raise _fail("STAGED_OUTPUTS", "BUILD", "REFUSED_PRE_WRITE", "staged outputs must be exact {main,bibliography,style} (NOT primary, no staged_refs alias)")
    for k in ("main", "bibliography", "style"):
        ref = outputs.get(k)
        if not isinstance(ref, dict) or set(ref) != {"path", "sha256", "byte_count"}:
            raise _fail("STAGED_OUTPUT", "BUILD", "REFUSED_PRE_WRITE", f"staged output {k} must be exact {{path,sha256,byte_count}}")
    primary_rel = outputs["main"]["path"]
    bib_rel = outputs["bibliography"]["path"]
    style_rel = outputs["style"]["path"]
    # Absolute exe + companion resolution: explicit external executor, resolve
    # declared symlink chain once, pin link+real + hash, use link argv0 with
    # stable recheck. No blanket symlink rejection; no network install.
    exe_raw = toolchain_spec.get("absolute_executable")
    if not isinstance(exe_raw, str) or not exe_raw:
        raise _fail("TOOLCHAIN_EXE", "BUILD", "REFUSED_PRE_WRITE", "toolchain executable missing")
    exe = Path(exe_raw)
    if not exe.is_absolute():
        raise _fail("TOOLCHAIN_EXE", "BUILD", "REFUSED_PRE_WRITE", "toolchain executable must be absolute")
    _link, _real, _real_sha = _resolve_toolchain_executable(exe, "toolchain executable")
    # Stable recheck: link must still resolve to same real + hash (no swap).
    _link2, _real2, _real_sha2 = _resolve_toolchain_executable(exe, "toolchain executable recheck")
    if _real2 != _real or _real_sha2 != _real_sha:
        raise _fail("TOOLCHAIN_STABLE", "BUILD", "REFUSED_PRE_WRITE", f"toolchain executable unstable: {exe} -> {_real} vs {_real2}")
    # Recipe .latexmkrc hash copy: pin now, verify unchanged after build + markers.
    try:
        recipe_bytes_before = _read_bytes_bounded(repo, RECIPE_REF.as_posix(), "recipe .latexmkrc")
    except EditorialError:
        raise
    recipe_sha_before = core.sha256_bytes(recipe_bytes_before)
    try:
        _recipe_text_before = recipe_bytes_before.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise _fail("RECIPE_MISSING", "BUILD", "REFUSED_PRE_WRITE", f"recipe not utf-8: {exc}") from exc
    for _marker in REQUIRED_RECIPE_MARKERS:
        if _marker not in _recipe_text_before:
            raise _fail("RECIPE_INCONSISTENT", "BUILD", "REFUSED_PRE_WRITE", f"recipe missing marker {_marker!r}")
    # Source inputs unchanged pre-build pins (exact bytes).
    pre_pins: dict[str, bytes] = {}
    for label, rel in (("main", primary_rel), ("bibliography", bib_rel), ("style", style_rel)):
        try:
            pre_pins[label] = _read_bytes_bounded(repo, rel, f"build input {label}")
        except EditorialError:
            raise
        exp = outputs[label if label != "main" else "main"]
        # For main, staged key is main; check sha/size.
        if core.sha256_bytes(pre_pins[label]) != exp["sha256"] or len(pre_pins[label]) != exp["byte_count"]:
            raise _fail("INPUT_DRIFT", "BUILD", "REFUSED_PRE_WRITE", f"build input drift before build: {label}")
    # Tool versions/digests where available (recorded, not assumed reproducible).
    # Actual fixed recipe/version inputs remain recorded; pin link+real + hash/version.
    # Controlled PATH toolbin + known OS /usr/bin:/bin for perl/helper, not ambient.
    versions: dict[str, Any] = {}
    controlled_version_env = {"PATH": str(exe.parent) + ":" + CONTROLLED_SYSTEM_PATH_SUFFIX}
    try:
        proc = subprocess.run([str(exe), "--version"], capture_output=True, text=True, timeout=60, env=controlled_version_env)
        versions["stdout"] = (proc.stdout or "")[:8000]
        versions["stderr"] = (proc.stderr or "")[:8000]
        versions["returncode"] = proc.returncode
        versions["link_path"] = str(_link)
        versions["real_path"] = str(_real)
        versions["real_sha256"] = _real_sha
    except Exception as exc:
        versions["error"] = str(exc)[:500]
    # Companion versions (biber/latexmk in same bin dir, resolved chain, no arbitrary PATH).
    bin_dir = exe.parent
    for companion in ("biber", "latexmk"):
        cand = bin_dir / companion
        try:
            _c_link, _c_real, _c_sha = _resolve_toolchain_executable(cand, f"companion {companion}")
            cp = subprocess.run([str(cand), "--version"], capture_output=True, text=True, timeout=60, env=controlled_version_env)
            versions[f"{companion}_stdout"] = (cp.stdout or "")[:4000]
            versions[f"{companion}_returncode"] = cp.returncode
            versions[f"{companion}_link_path"] = str(_c_link)
            versions[f"{companion}_real_path"] = str(_c_real)
            versions[f"{companion}_real_sha256"] = _c_sha
        except Exception as exc:
            # Missing companion is not fatal here; recipe-specific check below enforces required one.
            versions[f"{companion}_error"] = str(exc)[:300]
    # Disposable build root: system temp (external cache, no source pollution, no repo temp).
    # Uses tempfile.mkdtemp with external TMPDIR (no source __pycache__); PYTHONDONTWRITEBYTECODE
    # is enforced by callers for any Python imports/tests, not for TeX binaries.
    tmp = Path(tempfile.mkdtemp(prefix="editorial-build-"))
    # Fixed exact argv (no caller shell string, no latexmk -e, no output-root override).
    # Recorded argv is the flat expected tuple (schema: array<string>), matching spec.argv exactly.
    # Executed cmds use absolute exe/companion (exact declarations); recorded argv uses bare fixed steps.
    recipe = toolchain_spec.get("recipe")
    if recipe == "lualatex-biber-lualatex":
        expected_argv = list(EXPECTED_ARGV_LUALATEX_BIBER)
        cmds = [
            [str(exe), "-synctex=1", "-interaction=nonstopmode", "-file-line-error", "-halt-on-error", "main.tex"],
            [str(bin_dir / "biber"), "main"],
            [str(exe), "-synctex=1", "-interaction=nonstopmode", "-file-line-error", "-halt-on-error", "main.tex"],
            [str(exe), "-synctex=1", "-interaction=nonstopmode", "-file-line-error", "-halt-on-error", "main.tex"],
        ]
        # Companion biber: resolve chain (may be regular file), must exist in same bin dir.
        biber_cand = bin_dir / "biber"
        _resolve_toolchain_executable(biber_cand, "biber companion")
    elif recipe == "latexmk-lualatex":
        expected_argv = list(EXPECTED_ARGV_LATEXMK)
        latexmk_cand = bin_dir / "latexmk"
        # latexmk may be a script symlink to perl script; resolve chain, allow symlink link.
        # If exe itself is latexmk, use exe link path (argv0 correct); else use companion link path.
        if exe.name == "latexmk":
            _resolve_toolchain_executable(exe, "latexmk executable")
            latexmk_bin = str(exe)
        else:
            _resolve_toolchain_executable(latexmk_cand, "latexmk companion")
            latexmk_bin = str(latexmk_cand)
        cmds = [[latexmk_bin, "-pdf", "-lualatex", "-interaction=nonstopmode", "main.tex"]]
    else:
        raise _fail("TOOLCHAIN_RECIPE", "BUILD", "REFUSED_PRE_WRITE", f"unsupported recipe: {recipe!r}")
    # Spec argv must already equal expected (validated in _validate_toolchain_spec); re-check here
    # that spec matches executed/recorded (no dead config, no unenforced spec).
    if list(toolchain_spec.get("argv", [])) != expected_argv:
        raise _fail("TOOLCHAIN_ARGV", "BUILD", "REFUSED_PRE_WRITE", f"spec argv must equal executed argv {expected_argv!r}")
    recorded_argv = list(expected_argv)
    # Explicit env: controlled PATH toolbin + known OS /usr/bin:/bin for
    # perl/helper subprocess, not arbitrary ambient PATH. No GIT_*/PYTHONPATH,
    # no ambient TEXMFHOME/TZ/LANG injection. HOME only if spec documents it.
    allowed_env: dict[str, str] = {"PATH": str(bin_dir) + ":" + CONTROLLED_SYSTEM_PATH_SUFFIX}
    for key, val in (toolchain_spec.get("env") or {}).items():
        if key not in ALLOWED_ENV_KEYS:
            raise _fail("TOOLCHAIN_ENV", "BUILD", "REFUSED_PRE_WRITE", f"toolchain env not allowlisted: {key}")
        if key == "PATH":
            raise _fail("TOOLCHAIN_ENV", "BUILD", "REFUSED_PRE_WRITE", "spec must not set PATH (build sets explicit companion-dir PATH)")
        allowed_env[str(key)] = str(val)
    # Copy inputs to disposable root via bounded reads (preserve exact bytes, no shutil metadata).
    try:
        for label, rel in (("main", primary_rel), ("bibliography", bib_rel), ("style", style_rel)):
            data = pre_pins[label]
            dest_name = {"main": "main.tex", "bibliography": "references.bib", "style": "jgaisurvey.sty"}[label]
            dest = tmp / dest_name
            # Exclusive create in disposable root (no overwrite, no symlink).
            fd = os.open(dest, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o644)
            try:
                offset = 0
                mv = memoryview(data)
                while offset < len(mv):
                    w = os.write(fd, mv[offset:])
                    if w <= 0:
                        raise OSError("short write")
                    offset += w
                try:
                    os.fsync(fd)
                except OSError:
                    pass
            finally:
                os.close(fd)
        # Copy recipe .latexmkrc for latexmk recipe (hash already pinned).
        if recipe == "latexmk-lualatex":
            dest_recipe = tmp / ".latexmkrc"
            fd2 = os.open(dest_recipe, os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0), 0o644)
            try:
                os.write(fd2, recipe_bytes_before)
                try:
                    os.fsync(fd2)
                except OSError:
                    pass
            finally:
                os.close(fd2)
    except EditorialError:
        raise
    except (OSError, FileExistsError) as exc:
        raise _fail("BUILD_SETUP", "BUILD", "PRESERVED_INCOMPLETE", f"disposable build setup failed; build root preserved at {tmp}: {exc}") from exc
    logs: list[str] = []
    full_raw: list[dict[str, Any]] = []
    exit_code = 0
    failed_cmd: str | None = None
    try:
        for cmd in cmds:
            try:
                proc = subprocess.run(cmd, cwd=tmp, capture_output=True, text=True, timeout=600, env=allowed_env)
            except Exception as exc:
                raise _fail("BUILD_EXEC", "BUILD", "PRESERVED_INCOMPLETE", f"build exec failed; build root preserved at {tmp}: {exc}") from exc
            # Preserve full raw (no truncation): store full stdout/stderr up to 1MB each.
            out_full = proc.stdout or ""
            err_full = proc.stderr or ""
            full_raw.append({"cmd": list(cmd), "exit": proc.returncode, "stdout": out_full[:1000000], "stderr": err_full[:1000000]})
            # Human-readable log entry (full, not truncated to 4000).
            logs.append(f"$ {' '.join(cmd)}\nexit={proc.returncode}\n--- stdout ---\n{out_full}\n--- stderr ---\n{err_full}")
            if proc.returncode != 0:
                exit_code = proc.returncode
                failed_cmd = " ".join(cmd)
                break
        if exit_code != 0:
            # Preserve failed build root + full raw (no rmtree, no truncation).
            raise _fail("BUILD_FAILED", "BUILD", "PRESERVED_INCOMPLETE", f"disposable build failed exit={exit_code} cmd={failed_cmd}; build root preserved at {tmp} with full raw logs")
        pdf = tmp / "main.pdf"
        log = tmp / "main.log"
        # Real PDF+log gates: both must exist as regular files, PDF non-empty, log non-empty.
        import stat as _stat
        for p, label in ((pdf, "main.pdf"), (log, "main.log")):
            try:
                st = os.lstat(p)
            except OSError as exc:
                raise _fail("BUILD_OUTPUTS", "BUILD", "PRESERVED_INCOMPLETE", f"disposable build missing {label}; build root preserved at {tmp}: {exc}") from exc
            if _stat.S_ISLNK(st.st_mode) or not _stat.S_ISREG(st.st_mode) or st.st_size < 1:
                raise _fail("BUILD_OUTPUTS", "BUILD", "PRESERVED_INCOMPLETE", f"disposable build {label} invalid; build root preserved at {tmp}")
        try:
            pdf_bytes = pdf.read_bytes()
            log_bytes = log.read_bytes()
        except OSError as exc:
            raise _fail("BUILD_OUTPUTS", "BUILD", "PRESERVED_INCOMPLETE", f"build outputs unreadable; build root preserved at {tmp}: {exc}") from exc
        if len(pdf_bytes) < 1 or len(log_bytes) < 1:
            raise _fail("BUILD_OUTPUTS", "BUILD", "PRESERVED_INCOMPLETE", f"build outputs empty; build root preserved at {tmp}")
        # Required blocking log patterns: even with exit 0, fatal TeX errors refuse.
        # Checks combined stdout/stderr + main.log (decoded, errors ignored). No network install.
        try:
            combined_logs = "".join(logs) + "\n" + log_bytes.decode("utf-8", errors="ignore")
        except Exception as exc:
            raise _fail("BUILD_LOG", "BUILD", "PRESERVED_INCOMPLETE", f"build log decode failed; build root preserved at {tmp}: {exc}") from exc
        _check_blocking_log_patterns(combined_logs, "disposable build logs+main.log")
        # PDF pages gate: must be deterministically inspectable, >=1 page.
        try:
            from pypdf import PdfReader as _PdfReader
            import io as _io
            reader = _PdfReader(_io.BytesIO(pdf_bytes), strict=True)
            if reader.is_encrypted:
                raise _fail("BUILD_PDF", "BUILD", "PRESERVED_INCOMPLETE", f"build PDF encrypted; build root preserved at {tmp}")
            page_count = len(reader.pages)
        except EditorialError:
            raise
        except Exception as exc:
            raise _fail("BUILD_PDF", "BUILD", "PRESERVED_INCOMPLETE", f"build PDF not inspectable; build root preserved at {tmp}: {exc}") from exc
        if page_count < 1:
            raise _fail("BUILD_PDF", "BUILD", "PRESERVED_INCOMPLETE", f"build PDF has no pages; build root preserved at {tmp}")
        # Source inputs unchanged post-build (no drift during async build window).
        for label, rel in (("main", primary_rel), ("bibliography", bib_rel), ("style", style_rel)):
            try:
                post_bytes = _read_bytes_bounded(repo, rel, f"build input post {label}")
            except EditorialError:
                raise
            if post_bytes != pre_pins[label]:
                raise _fail("INPUT_DRIFT", "BUILD", "PRESERVED_INCOMPLETE", f"build input changed during build; build root preserved at {tmp}: {label}")
        # Recipe unchanged post-build.
        try:
            recipe_bytes_after = _read_bytes_bounded(repo, RECIPE_REF.as_posix(), "recipe .latexmkrc post")
        except EditorialError:
            raise
        if recipe_bytes_after != recipe_bytes_before:
            raise _fail("RECIPE_DRIFT", "BUILD", "PRESERVED_INCOMPLETE", f"recipe changed during build; build root preserved at {tmp}")
        digest = core.sha256_bytes(pdf_bytes)
        return {
            "tmpdir": tmp,
            "pdf_bytes": pdf_bytes,
            "pdf_sha256": digest,
            "pdf_size": len(pdf_bytes),
            "log_bytes": log_bytes,
            "log_size": len(log_bytes),
            "page_count": page_count,
            "logs": logs,
            "full_raw": full_raw,
            "exit_code": 0,
            "versions": versions,
            "argv": list(recorded_argv),
            "env": {k: allowed_env.get(k) for k in sorted(allowed_env)},
            "recipe_sha256": recipe_sha_before,
            "inputs": {"main": primary_rel, "bibliography": bib_rel, "style": style_rel},
        }
    except EditorialError:
        # Preserve failed build root + full raw (no rmtree). Caller must preserve
        # tmpdir path in error for manual recovery; never auto-delete.
        raise
    except Exception as exc:
        raise _fail("BUILD_FAILED", "BUILD", "PRESERVED_INCOMPLETE", f"disposable build failed; build root preserved at {tmp}: {exc}") from exc


def prepare_publication(
    root: str | Path,
    state_path: str | Path,
    proposal_path: str | Path,
    staged_manifest_path: str | Path,
    manuscript_spec_path: str | Path,
    toolchain_spec_path: str | Path,
    recorded_at: datetime | None = None,
) -> dict[str, Any]:
    """Prepare publication: P2V scope-bound -> disposable build -> exclusive transfer + record/receipt/manuscript."""
    repo = Path(root).resolve()
    ts = _now_utc(recorded_at)
    # Input specs live outside yet-unclaimed P/publication root (siblings, not children).
    # Manuscript/toolchain specs are pinned dependencies, not writer-owned outputs.
    proposal_rel_init = _lexical_rel(repo, str(proposal_path), "proposal")
    staged_rel_init = _lexical_rel(repo, str(staged_manifest_path), "staged manifest")
    manuscript_spec_rel = _lexical_rel(repo, str(manuscript_spec_path), "manuscript spec")
    toolchain_spec_rel = _lexical_rel(repo, str(toolchain_spec_path), "toolchain spec")
    state_rel_init = _lexical_rel(repo, str(state_path), "Production State")
    # P/publication absent check via lstat (no symlink laundering, no same-byte takeover).
    _safe(repo, proposal_rel_init, "proposal")
    _safe(repo, staged_rel_init, "staged manifest")
    probe_pubdir = _proposal_dir(repo, proposal_rel_init) / "publication"
    try:
        pst = os.lstat(probe_pubdir)
        raise _fail("PUBLICATION_EXISTS", "PREPARE", "REFUSED_PRE_WRITE", f"P/publication already claimed (no takeover, preserve incomplete): {probe_pubdir}")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("PUBLICATION_CHECK", "PREPARE", "REFUSED_PRE_WRITE", f"P/publication check failed: {exc}") from exc
    pubdir = probe_pubdir
    for name in _UNSAFE_GIT_VARS:
        if os.environ.get(name):
            raise _fail("GIT_ENV", "PREPARE", "REFUSED_PRE_WRITE", f"inherited {name} refuses operation")
    obs = _require_scope_bound(repo, state_rel_init, proposal_rel_init, staged_rel_init)
    # Raw-first staged load (lexical before resolve, bounded read, no symlink laundering).
    staged_bytes = _read_bytes_bounded(repo, staged_rel_init, "staged manifest")
    try:
        import json as _js
        staged_manifest = _js.loads(staged_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STAGED_UNREADABLE", "PREPARE", "REFUSED_PRE_WRITE", f"staged manifest not JSON: {exc}") from exc
    if not isinstance(staged_manifest, dict):
        raise _fail("STAGED_SHAPE", "PREPARE", "REFUSED_PRE_WRITE", "staged manifest must be object")
    issue_id = staged_manifest.get("issue_id")
    if not isinstance(issue_id, str) or not issue_id:
        raise _fail("STAGED_ISSUE", "PREPARE", "REFUSED_PRE_WRITE", "staged manifest issue invalid")
    manuscript_spec = _validate_manuscript_spec(repo, manuscript_spec_rel, issue_id)
    toolchain_spec = _validate_toolchain_spec(repo, toolchain_spec_rel)
    proof = _verify_staged(repo, proposal_rel_init, staged_rel_init)
    _ = proof
    _ = obs
    # Early scope independently reloads existing P1 scope via P3S verifier context (never postrender).
    # staged proof already pins scope_review_ref; Gate will recheck it at finalize.
    build = _run_disposable_build(repo, staged_manifest, toolchain_spec)
    # Fresh P2V recheck after async build window before any writes (genuine current-before).
    _require_scope_bound(repo, state_rel_init, proposal_rel_init, staged_rel_init)
    # Exclusive build3 transfer: pinned known bytes + final readback (no false glob CAS).
    # Build dir is writer-owned; claim exclusively, refuse pre-existing conflicting/same-byte target.
    build_dir = pubdir / "build"
    try:
        os.lstat(build_dir)
        raise _fail("TARGET_EXISTS", "BUILD_TRANSFER", "REFUSED_PRE_WRITE", f"build dir already exists (no takeover): {build_dir}")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("BUILD_TRANSFER", "BUILD_TRANSFER", "PRESERVED_INCOMPLETE", f"build dir check failed: {exc}") from exc
    try:
        build_dir.mkdir(parents=True, exist_ok=False)
    except FileExistsError as exc:
        raise _fail("TARGET_EXISTS", "BUILD_TRANSFER", "REFUSED_PRE_WRITE", f"build dir race (no takeover): {exc}") from exc
    except OSError as exc:
        raise _fail("BUILD_TRANSFER", "BUILD_TRANSFER", "PRESERVED_INCOMPLETE", f"build dir mkdir failed: {exc}") from exc
    pdf_target = build_dir / "main.pdf"
    log_target = build_dir / "main.log"
    digest_target = build_dir / "main.pdf.sha256"
    digest_bytes = (build["pdf_sha256"] + "\n").encode("utf-8")
    for target, data, label in ((pdf_target, build["pdf_bytes"], "publication-pdf"), (log_target, build["log_bytes"], "build-log"), (digest_target, digest_bytes, "pdf-digest")):
        try:
            _exclusive_write_bytes(target, bytes(data), f"build3 {label}")
        except EditorialError:
            raise
        try:
            actual = target.read_bytes()
        except OSError as exc:
            raise _fail("BUILD_TRANSFER", "BUILD_TRANSFER", "PRESERVED_INCOMPLETE", f"build3 readback failed {label}: {exc}") from exc
        if actual != bytes(data):
            raise _fail("BUILD_TRANSFER", "BUILD_TRANSFER", "PRESERVED_INCOMPLETE", f"build3 final mismatch {label}; preserved")
        # Verify inputs unchanged after build (no drift during async build window) + staged re-proof.
        # Fresh staged proof (historical P2R/P3S) after transfer, before manuscript/receipt writes.
        _verify_staged(repo, proposal_rel_init, staged_rel_init)
        # Build record includes recipe source ref/hash (.latexmkrc) + input/output refs; digest excludes only self.
        # build_sha256 hashes complete record INCLUDING input/output refs but excluding only itself
        # (map-resolution excluding outputs is rejected; output binding is essential).
        _check_file(repo, RECIPE_REF.as_posix(), "recipe .latexmkrc")
        from scripts import survey_reader_publication_v2 as reader

        # Manuscript construction from spec coverage assertions (actual existing fields only).
        # Resolve profile/architecture via strict State + actual initial receipt (read-only, no invention).
        state_bytes2 = _read_bytes_bounded(repo, state_rel_init, "Production State")
        try:
            import json as _js2
            state = _js2.loads(state_bytes2.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise _fail("STATE_UNREADABLE", "PREPARE", "REFUSED_PRE_WRITE", f"State not JSON: {exc}") from exc
        profile_ref = state.get("profile") or {}
        if not isinstance(profile_ref, dict) or set(profile_ref) != {"path", "sha256"}:
            raise _fail("PROFILE_REF", "PREPARE", "REFUSED_PRE_WRITE", "State profile ref must be exact {path,sha256}")
        profile_rel = _lexical_rel(repo, profile_ref["path"], "Production Profile")
        _safe(repo, profile_rel, "Production Profile")
        try:
            profile_bytes = _read_bytes_bounded(repo, profile_rel, "Production Profile")
            profile = _js2.loads(profile_bytes.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise _fail("PROFILE_UNREADABLE", "PREPARE", "REFUSED_PRE_WRITE", f"Profile not JSON: {exc}") from exc
        validation_ref = (state.get("checkpoint_provenance") or {}).get("validation") or {}
        if not isinstance(validation_ref, dict) or set(validation_ref) != {"path", "sha256"}:
            raise _fail("NO_VALIDATION", "PREPARE", "REFUSED_PRE_WRITE", "State lacks exact validation checkpoint ref")
        # Proposal must be exact (already verified in receipt path, re-check here for prepare).
        proposal_bytes = _read_bytes_bounded(repo, proposal_rel_init, "proposal")
        try:
            proposal_obj = _js2.loads(proposal_bytes.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise _fail("PROPOSAL_UNREADABLE", "PREPARE", "REFUSED_PRE_WRITE", f"proposal not JSON: {exc}") from exc
        if proposal_obj.get("issue_id") != issue_id:
            raise _fail("PROPOSAL_LABEL", "PREPARE", "REFUSED_PRE_WRITE", "proposal issue != staged issue")
        # Architecture: exact from initial generated receipt accepted issue-architecture (actual existing authority).
        # No guessed checkpoint artifact names (issue-architecture vs architecture vs architecture-v2).
        basis = proposal_obj.get("basis") or {}
        gen_receipt_ref = basis.get("generated_receipt_ref")
        if not isinstance(gen_receipt_ref, dict) or "path" not in gen_receipt_ref:
            raise _fail("BASIS_RECEIPT", "PREPARE", "REFUSED_PRE_WRITE", "proposal basis generated_receipt_ref invalid")
        gen_rel = _lexical_rel(repo, gen_receipt_ref["path"], "initial generated receipt")
        _safe(repo, gen_rel, "initial generated receipt")
        gen_bytes = _read_bytes_bounded(repo, gen_rel, "initial generated receipt")
        if core.sha256_bytes(gen_bytes) != gen_receipt_ref.get("sha256"):
            raise _fail("BASIS_RECEIPT_DRIFT", "PREPARE", "REFUSED_PRE_WRITE", "initial receipt drift")
        try:
            gen_obj = _js2.loads(gen_bytes.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise _fail("BASIS_RECEIPT_UNREADABLE", "PREPARE", "REFUSED_PRE_WRITE", f"initial receipt not JSON: {exc}") from exc
        gen_accepted = {r.get("name"): r for r in gen_obj.get("accepted_refs", []) if isinstance(r, dict)}
        arch_accepted = gen_accepted.get("issue-architecture")
        if not isinstance(arch_accepted, dict) or "path" not in arch_accepted or "sha256" not in arch_accepted:
            raise _fail("NO_ARCH", "PREPARE", "REFUSED_PRE_WRITE", "initial receipt lacks exact issue-architecture accepted ref (no invention)")
        arch_rel = _lexical_rel(repo, arch_accepted["path"], "issue architecture")
        _safe(repo, arch_rel, "issue architecture")
        arch_bytes = _read_bytes_bounded(repo, arch_rel, "issue architecture")
        if core.sha256_bytes(arch_bytes) != arch_accepted.get("sha256"):
            raise _fail("ARCH_DRIFT", "PREPARE", "REFUSED_PRE_WRITE", "issue architecture drift")
        # Approval: exact from strict State human_gate_provenance architecture_review (actual sanctioned bytes).
        arch_prov = (state.get("human_gate_provenance") or {}).get("architecture_review")
        if not isinstance(arch_prov, dict) or set(arch_prov) != {"path", "sha256"}:
            raise _fail("NO_APPROVAL", "PREPARE", "REFUSED_PRE_WRITE", "State lacks exact architecture_review provenance")
        approval_rel = _lexical_rel(repo, arch_prov["path"], "architecture approval")
        _safe(repo, approval_rel, "architecture approval")
        approval_bytes = _read_bytes_bounded(repo, approval_rel, "architecture approval")
        if core.sha256_bytes(approval_bytes) != arch_prov.get("sha256"):
            raise _fail("APPROVAL_DRIFT", "PREPARE", "REFUSED_PRE_WRITE", "architecture approval drift")
        # Staged trio: exact outputs {main,bibliography,style} (NOT primary, no staged_refs alias).
        staged_outputs = staged_manifest.get("outputs")
        if not isinstance(staged_outputs, dict) or set(staged_outputs) != {"main", "bibliography", "style"}:
            raise _fail("STAGED_OUTPUTS", "PREPARE", "REFUSED_PRE_WRITE", "staged outputs must be exact {main,bibliography,style}")
        # Map staged main→manuscript primary (explicit mapping, no alias).
        primary_rel = staged_outputs["main"]["path"]
        bib_rel = staged_outputs["bibliography"]["path"]
        style_rel = staged_outputs["style"]["path"]
        _safe(repo, primary_rel, "staged main")
        _safe(repo, bib_rel, "staged bibliography")
        _safe(repo, style_rel, "staged style")
        primary_p = _safe(repo, primary_rel, "staged primary")
        bib_p = _safe(repo, bib_rel, "staged bibliography")
        style_p = _safe(repo, style_rel, "staged style")
        # Editorial source refs (exact proposal/staged bytes at final boundary).
        proposal_sha_now = core.sha256_bytes(_read_bytes_bounded(repo, proposal_rel_init, "proposal"))
        staged_sha_now = core.sha256_bytes(_read_bytes_bounded(repo, staged_rel_init, "staged manifest"))
        # Build manuscript via existing builder to guarded intermediary temp (system temp, not publication inventory),
        # then validate + exclusive transfer to final (existing builders use non-exclusive write_json).
        # Temp is outside publication namespace, so review-target rebinding does not occur (refs are repo-relative).
        import tempfile as _tf
        tmp_manuscript = Path(_tf.mkdtemp(prefix="editorial-manuscript-")) / "reader-manuscript-v2.json"
        try:
            reader.build_manuscript_manifest(
                repo,
                issue_id,
                _safe(repo, profile_rel, "Production Profile"),
                _safe(repo, arch_rel, "issue architecture"),
                _safe(repo, approval_rel, "architecture approval"),
                primary_p,
                [{"role": "BIBLIOGRAPHY", "path": _lexical_rel(repo, bib_rel, "staged bibliography")}, {"role": "STYLE", "path": _lexical_rel(repo, style_rel, "staged style")}],
                manuscript_spec["architecture_coverage"],
                manuscript_spec["reader_requirements"],
                manuscript_spec["authored_by"],
                ts,
                tmp_manuscript,
                editorial_source={"proposal_ref": {"path": proposal_rel_init, "sha256": proposal_sha_now}, "staged_manifest_ref": {"path": staged_rel_init, "sha256": staged_sha_now}},
            )
        except Exception as exc:
            # Preserve temp for manual recovery (no auto-delete of unknown).
            raise _fail("MANUSCRIPT_BUILD", "PREPARE", "PRESERVED_INCOMPLETE", f"manuscript builder failed; temp preserved at {tmp_manuscript}: {exc}") from exc
        # Validate temp manuscript via actual Reader validator (typed, not mirror text).
        try:
            tmp_validated = reader.validate_manuscript_manifest(repo, tmp_manuscript, issue_id=issue_id)
        except Exception as exc:
            raise _fail("MANUSCRIPT_INVALID", "PREPARE", "PRESERVED_INCOMPLETE", f"temp manuscript invalid; preserved at {tmp_manuscript}: {exc}") from exc
        if tmp_validated.get("editorial_source") != {"proposal_ref": {"path": proposal_rel_init, "sha256": proposal_sha_now}, "staged_manifest_ref": {"path": staged_rel_init, "sha256": staged_sha_now}}:
            raise _fail("MANUSCRIPT_BIND", "PREPARE", "PRESERVED_INCOMPLETE", f"temp manuscript editorial_source mismatch; preserved at {tmp_manuscript}")
        manuscript_path = pubdir / "reader-manuscript-v2.json"
        try:
            tmp_bytes = tmp_manuscript.read_bytes()
        except OSError as exc:
            raise _fail("MANUSCRIPT_READ", "PREPARE", "PRESERVED_INCOMPLETE", f"temp manuscript unreadable; preserved at {tmp_manuscript}: {exc}") from exc
        try:
            _exclusive_write_bytes(manuscript_path, tmp_bytes, "reader manuscript")
        except EditorialError:
            raise
        # Remove own temp only if still our bytes (identity+bytes), else preserve as unknown.
        try:
            if tmp_manuscript.is_file() and not tmp_manuscript.is_symlink() and tmp_manuscript.read_bytes() == tmp_bytes:
                tmp_manuscript.unlink()
                try:
                    Path(tmp_manuscript.parent).rmdir()
                except OSError:
                    pass
        except OSError:
            pass
        # New receipt (EDITORIAL_PUBLICATION_SOURCE_V1) with exact trio + coverage/requirement author assertions.
        # current_tools closure is union 50 per root selection (P3S route 50, not 22/27 only).
        # Reviewed reader is proposal proposed_reader_ref (NEW), authored is new authoring + unchanged accepted Draft
        # (initial drafting archive), accepted is strict State validation checkpoint. No F0 self-reference:
        # receipt_sha256 hashes canonical object without itself; seal/activation never required to validate receipt.
        generator_route = "WEEKLY_GENERATED_V2" if profile.get("research_profile") == "WEEKLY" else "LONGFORM_GENERATED_V1"
        if profile.get("research_profile") == "WEEKLY" and generator_route != "WEEKLY_GENERATED_V2":
            raise _fail("ROUTE_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE", "Weekly Profile requires WEEKLY_GENERATED_V2")
        if profile.get("research_profile") == "THEMATIC" and generator_route != "LONGFORM_GENERATED_V1":
            raise _fail("ROUTE_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE", "Thematic Profile requires LONGFORM_GENERATED_V1")
        receipt_closure = _editorial_closure_rows(repo, generator_route)
        try:
            cfg_for_contract = core.load_json(_safe(repo, core.DEFAULT_CONFIG.as_posix(), "implementation config"))
        except (OSError, ValueError) as exc:
            raise _fail("CONFIG_UNREADABLE", "PREPARE", "REFUSED_PRE_WRITE", f"config unreadable: {exc}") from exc
        current_contract = core.contract_identity(repo, cfg_for_contract, profile.get("research_profile"), profile.get("publication_profile"))
        # Exact trio mapping: staged main→receipt primary (explicit, NOT primary alias, no staged_refs).
        staged_main_ref = staged_outputs["main"]
        staged_bib_ref = staged_outputs["bibliography"]
        staged_style_ref = staged_outputs["style"]
        # Reviewed NEW reader + authoring from actual proposal (no invention).
        proposed_reader_ref = (proposal_obj.get("proposed") or {}).get("proposed_reader_ref")
        proposed_authoring_ref = (proposal_obj.get("proposed") or {}).get("authoring_input_ref")
        if not isinstance(proposed_reader_ref, dict) or set(proposed_reader_ref) != {"path", "sha256"}:
            raise _fail("PROPOSAL_READER", "PREPARE", "REFUSED_PRE_WRITE", "proposal proposed_reader_ref invalid")
        if not isinstance(proposed_authoring_ref, dict) or set(proposed_authoring_ref) != {"path", "sha256"}:
            raise _fail("PROPOSAL_AUTHORING", "PREPARE", "REFUSED_PRE_WRITE", "proposal authoring_input_ref invalid")
        # Unchanged accepted Draft: initial drafting-authored-archive (exact, from basis generated receipt).
        draft_archive_path = gen_accepted.get("drafting-authored-archive", {}).get("path") if isinstance(gen_accepted.get("drafting-authored-archive"), dict) else None
        draft_archive_sha = gen_accepted.get("drafting-authored-archive", {}).get("sha256") if isinstance(gen_accepted.get("drafting-authored-archive"), dict) else None
        if not isinstance(draft_archive_path, str) or not isinstance(draft_archive_sha, str):
            raise _fail("ACCEPTED_DRAFT", "PREPARE", "REFUSED_PRE_WRITE", "initial receipt drafting archive invalid")
        validation_ref2 = (state.get("checkpoint_provenance") or {}).get("validation")
        if not isinstance(validation_ref2, dict) or set(validation_ref2) != {"path", "sha256"}:
            raise _fail("NO_VALIDATION", "PREPARE", "REFUSED_PRE_WRITE", "State lacks exact validation checkpoint")
        receipt_base: dict[str, Any] = {
            "schema_version": "2.0-rc1",
            "kind": "EDITORIAL_PUBLICATION_SOURCE_V1",
            "issue_id": issue_id,
            "research_profile": profile.get("research_profile"),
            "publication_profile": profile.get("publication_profile"),
            "generator_route": generator_route,
            "proposal_ref": {"path": proposal_rel_init, "sha256": proposal_sha_now},
            "retention_manifest_ref": {"path": staged_manifest.get("retention_manifest_ref", {}).get("path"), "sha256": staged_manifest.get("retention_manifest_ref", {}).get("sha256")},
            "staged_manifest_ref": {"path": staged_rel_init, "sha256": staged_sha_now},
            "scope_review_ref": staged_manifest.get("scope_review_ref"),
            "reviewed_reader_input": {"path": proposed_reader_ref["path"], "sha256": proposed_reader_ref["sha256"]},
            "authored_refs": [
                {"name": "proposed-publication-authoring", "path": proposed_authoring_ref["path"], "sha256": proposed_authoring_ref["sha256"]},
                {"name": "accepted-draft-archive", "path": draft_archive_path, "sha256": draft_archive_sha},
            ],
            "accepted_refs": [{"name": "validation-checkpoint", "path": validation_ref2["path"], "sha256": validation_ref2["sha256"]}],
            "current_tools": {"repository_commit_sha": core.repository_commit_sha(repo), "contract": current_contract, "closure": receipt_closure},
            "outputs": {
                "primary": {"path": staged_main_ref["path"], "sha256": staged_main_ref["sha256"]},
                "bibliography": {"path": staged_bib_ref["path"], "sha256": staged_bib_ref["sha256"]},
                "style": {"path": staged_style_ref["path"], "sha256": staged_style_ref["sha256"]},
            },
        }
        receipt_base["receipt_sha256"] = core.sha256_object(receipt_base)
        receipt_path = pubdir / "validated-source-manifest.json"
        try:
            schema_gate.validate_instance(receipt_base, repo / EDITORIAL_RECEIPT_SCHEMA, label="editorial receipt")
        except ValueError as exc:
            raise _fail("RECEIPT_SCHEMA", "PREPARE", "REFUSED_PRE_WRITE", f"receipt schema invalid: {exc}") from exc
        # Exclusive receipt create (no same-byte takeover, no hash blessing without validation).
        _exclusive_write_json(receipt_path, {**receipt_base, "receipt_sha256": receipt_base["receipt_sha256"]}, "editorial receipt")
        # Build record (digest includes input/output refs, excludes only self; output binding essential).
        recipe_sha_now = core.sha256_bytes(_read_bytes_bounded(repo, RECIPE_REF.as_posix(), "recipe .latexmkrc"))
        # Final pins for build outputs (exclusive transfer already verified SHA; re-check byte_count).
        pdf_rel_final = _lexical_rel(repo, str(pdf_target.relative_to(repo)) if pdf_target.is_absolute() else str(pdf_target), "publication-pdf")
        # pdf_target/log_target/digest_target are under pubdir (repo-relative via pubdir).
        # Derive repo-relative via proposal dir + publication/build (exact, no _rel guessing).
        proposal_dir_rel = proposal_rel_init.rsplit("/", 1)[0]
        pdf_rel = f"{proposal_dir_rel}/publication/build/main.pdf"
        log_rel = f"{proposal_dir_rel}/publication/build/main.log"
        digest_rel = f"{proposal_dir_rel}/publication/build/main.pdf.sha256"
        for rel, target in ((pdf_rel, pdf_target), (log_rel, log_target), (digest_rel, digest_target)):
            _safe(repo, rel, "build output")
            if not target.is_file() or target.is_symlink():
                raise _fail("BUILD_OUTPUT", "PREPARE", "PRESERVED_INCOMPLETE", f"build output missing: {rel}")
        build_base: dict[str, Any] = {
            "schema_version": "2.0-rc1",
            "kind": "EDITORIAL_PUBLICATION_BUILD_V1",
            "issue_id": issue_id,
            "proposal_ref": {"path": proposal_rel_init, "sha256": proposal_sha_now},
            "staged_manifest_ref": {"path": staged_rel_init, "sha256": staged_sha_now},
            "recipe_ref": {"path": RECIPE_REF.as_posix(), "sha256": recipe_sha_now},
            "declared_inputs": {
                "primary": {"path": staged_main_ref["path"], "sha256": staged_main_ref["sha256"]},
                "bibliography": {"path": staged_bib_ref["path"], "sha256": staged_bib_ref["sha256"]},
                "style": {"path": staged_style_ref["path"], "sha256": staged_style_ref["sha256"]},
            },
            "recipe": {"fixed_steps": list(FIXED_RECIPE_STEPS)},
            "toolchain": {"executable": toolchain_spec["absolute_executable"], "versions": build["versions"], "argv": build["argv"], "env": build["env"]},
            "outputs": {
                "publication-pdf": {"path": pdf_rel, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, pdf_rel, "publication-pdf")), "byte_count": _safe(repo, pdf_rel, "publication-pdf").stat().st_size},
                "build-log": {"path": log_rel, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, log_rel, "build-log")), "byte_count": _safe(repo, log_rel, "build-log").stat().st_size},
                "pdf-digest": {"path": digest_rel, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, digest_rel, "pdf-digest")), "byte_count": _safe(repo, digest_rel, "pdf-digest").stat().st_size},
            },
            "exit_code": 0,
            "recorded_at": core.iso_utc(ts),
        }
        build_base["build_sha256"] = core.sha256_object({k: v for k, v in build_base.items() if k != "build_sha256"})
        build_record_path = pubdir / "build-record.json"
        try:
            schema_gate.validate_instance(build_base, repo / BUILD_RECORD_SCHEMA, label="build record")
        except ValueError as exc:
            raise _fail("BUILD_RECORD_SCHEMA", "PREPARE", "REFUSED_PRE_WRITE", f"build record schema invalid: {exc}") from exc
        _exclusive_write_json(build_record_path, {**build_base, "build_sha256": build_base["build_sha256"]}, "build record")
        # Runtime never generates semantic/visual PASS; external reviews are supplied later at finalize.
        # Pre-review manuscript final bytes first (already exclusively written above).
        # Genuine current-before already rechecked after build; no synthetic approval.
        proposal_dir_rel2 = proposal_rel_init.rsplit("/", 1)[0]
        return {
            "proposal_dir": proposal_dir_rel2,
            "publication_dir": f"{proposal_dir_rel2}/publication",
            "build": {"pdf": pdf_rel, "log": log_rel, "digest": digest_rel},
            "build_record": f"{proposal_dir_rel2}/publication/build-record.json",
            "receipt": f"{proposal_dir_rel2}/publication/validated-source-manifest.json",
            "manuscript": f"{proposal_dir_rel2}/publication/reader-manuscript-v2.json",
        }


def _editorial_closure_rows(repo: Path, generator_route: str) -> list[dict[str, str]]:
    # Root-selected exact union: P3S route 50 (not H3 22/27 only).
    # Union = P3S _route_code_deps(route) with selected sets (30py+14schemas+3route+1staged+1style+1recipe=50).
    # No filesystem discovery (finite sorted-unique), no +unknown. Uses actual
    # P3S fixed set for names, then pins current bytes. New current source
    # runtime binding allows legitimate imported new modules (P3S set already
    # includes low/high/current-authority); extra import requires expansion, never silent omit.
    if generator_route not in ("WEEKLY_GENERATED_V2", "LONGFORM_GENERATED_V1"):
        raise _fail("CLOSURE_ROUTE", "PREPARE", "REFUSED_PRE_WRITE", f"unknown generator_route: {generator_route!r}")
    try:
        from scripts import survey_editorial_staged_source_v2 as _staged_mod
    except ImportError as exc:
        raise _fail("CLOSURE_STAGED_MISSING", "PREPARE", "REFUSED_PRE_WRITE", f"P3S staged module missing for editorial closure: {exc}") from exc
    try:
        expected_names_tuple = _staged_mod._route_code_deps(generator_route)
    except Exception as exc:
        raise _fail("CLOSURE_ROUTE_DEPS", "PREPARE", "REFUSED_PRE_WRITE", f"P3S route code deps failed: {exc}") from exc
    names = list(expected_names_tuple)
    # Sorted-unique, no overlap silently omitted (duplicates would shrink len and fail).
    rows = []
    for name in sorted(set(names)):
        # Raw-first containment + bounded read (no symlink laundering, no FIFO).
        _safe(repo, name, f"closure {name}")
        try:
            data = _read_bytes_bounded(repo, name, f"closure {name}")
        except EditorialError:
            raise
        rows.append({"name": name, "path": name, "sha256": core.sha256_bytes(data)})
    # Exact count checked: union 50 per root selection (overrides H3 22/27).
    if len(rows) != 50:
        raise _fail("CLOSURE_SHAPE", "PREPARE", "REFUSED_PRE_WRITE", f"editorial closure expected 50, got {len(rows)}")
    # No duplicate names/paths (already sorted-unique, but verify paths equal names).
    for row in rows:
        if row["path"] != row["name"]:
            raise _fail("CLOSURE_PATH", "PREPARE", "REFUSED_PRE_WRITE", f"closure path must equal name: {row!r}")
    return rows


def _canonical_closure_names(generator_route: str) -> list[str]:
    # Filtered canonical subset for existing route control-root verification:
    # Weekly 22 / Longform 27 (current extended CURRENT_CLOSURE, not old 8/14).
    # Real old initial receipts 22/27 remain valid via existing route helpers;
    # no old-epoch migration. Editorial receipt 50 is verified via this subset
    # (control roots) plus independent extra-closure verification below.
    if generator_route == "WEEKLY_GENERATED_V2":
        from scripts import survey_weekly_derivation_v2 as weekly

        return [p.as_posix() for p in weekly.CURRENT_CLOSURE]
    if generator_route == "LONGFORM_GENERATED_V1":
        from scripts import survey_longform_generated_v2 as generated

        return [p.as_posix() for p in generated.CURRENT_CLOSURE]
    raise _fail("CLOSURE_ROUTE", "VALIDATE", "REFUSED_PRE_WRITE", f"unknown generator_route: {generator_route!r}")


def finalize_publication(
    root: str | Path,
    state_path: str | Path,
    proposal_path: str | Path,
    staged_manifest_path: str | Path,
    deterministic_checks_path: str | Path,
    semantic_review_path: str | Path,
    visual_review_path: str | Path,
    recorded_at: datetime | None = None,
) -> dict[str, str]:
    """Finalize set: recheck current-before, validate QA/reviews, Gate (early scope)/Candidate, seal last."""
    repo = Path(root).resolve()
    ts = _now_utc(recorded_at)
    proposal_rel_f = _lexical_rel(repo, str(proposal_path), "proposal")
    staged_rel_f = _lexical_rel(repo, str(staged_manifest_path), "staged manifest")
    state_rel_f = _lexical_rel(repo, str(state_path), "Production State")
    det_rel = _lexical_rel(repo, str(deterministic_checks_path), "deterministic checks")
    sem_rel = _lexical_rel(repo, str(semantic_review_path), "semantic review")
    vis_rel = _lexical_rel(repo, str(visual_review_path), "visual review")
    _safe(repo, proposal_rel_f, "proposal")
    _safe(repo, staged_rel_f, "staged manifest")
    _safe(repo, state_rel_f, "Production State")
    pubdir_probe = _proposal_dir(repo, proposal_rel_f) / "publication"
    try:
        pst = os.lstat(pubdir_probe)
        if not stat.S_ISDIR(pst.st_mode):
            raise _fail("NO_PREPARE", "FINALIZE", "REFUSED_PRE_WRITE", "prepare publication dir not directory")
    except FileNotFoundError:
        raise _fail("NO_PREPARE", "FINALIZE", "REFUSED_PRE_WRITE", "prepare publication dir missing")
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("NO_PREPARE", "FINALIZE", "REFUSED_PRE_WRITE", f"prepare dir check failed: {exc}") from exc
    pubdir = pubdir_probe
    # Fresh current-before recheck before all input pins (genuine, not cached).
    obs = _require_scope_bound(repo, state_rel_f, proposal_rel_f, staged_rel_f)
    _ = obs
    # Receipt itself verifies strict State + tool closure + P3S proof + scope + replay.
    proposal_dir_rel_f = proposal_rel_f.rsplit("/", 1)[0]
    receipt_rel_f = f"{proposal_dir_rel_f}/publication/validated-source-manifest.json"
    _safe(repo, receipt_rel_f, "editorial receipt")
    receipt = validate_editorial_receipt(repo, receipt_rel_f, state_rel_f)
    manuscript_rel_f = f"{proposal_dir_rel_f}/publication/reader-manuscript-v2.json"
    build_record_rel_f = f"{proposal_dir_rel_f}/publication/build-record.json"
    for rel, label in ((manuscript_rel_f, "reader manuscript"), (build_record_rel_f, "build record")):
        _check_file(repo, rel, f"finalize input {label}")
    # Validate supplied QA schema refs + postrender reviews at final exact paths.
    # Supplied reviews are persisted files only; runtime never synthesizes PASS.
    from scripts import survey_quality_v2 as quality
    from scripts import survey_reader_publication_v2 as reader
    from scripts import survey_reader_surface_gate_v2 as gate
    from scripts import survey_publication_v2 as publication

    try:
        manuscript = reader.validate_manuscript_manifest(repo, _safe(repo, manuscript_rel_f, "reader manuscript"), issue_id=receipt["issue_id"])
    except Exception as exc:
        raise _fail("MANUSCRIPT_INVALID", "FINALIZE", "REFUSED_PRE_WRITE", f"manuscript invalid: {exc}") from exc
    # Deterministic checks use existing quality.validate_checks contract with actual evidence results.
    try:
        checks_bytes = _read_bytes_bounded(repo, det_rel, "deterministic checks")
        import json as _jc
        checks_data = _jc.loads(checks_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("CHECKS_UNREADABLE", "FINALIZE", "REFUSED_PRE_WRITE", f"deterministic checks not JSON: {exc}") from exc
    checks = checks_data.get("checks", checks_data) if isinstance(checks_data, dict) else checks_data
    if not isinstance(checks, list) or len(checks) < 1:
        raise _fail("CHECKS_SHAPE", "FINALIZE", "REFUSED_PRE_WRITE", "deterministic checks must be non-empty list")
    # Build QA bundle from exact source/PDF (no automatic family PASS by schema).
    # Source is staged main (NOT primary alias); PDF is build3 main.pdf (exact bytes).
    try:
        state_bytes_f = _read_bytes_bounded(repo, state_rel_f, "Production State")
        state = _jc.loads(state_bytes_f.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STATE_UNREADABLE", "FINALIZE", "REFUSED_PRE_WRITE", f"State not JSON: {exc}") from exc
    profile_ref = state.get("profile") or {}
    if not isinstance(profile_ref, dict) or set(profile_ref) != {"path", "sha256"}:
        raise _fail("PROFILE_REF", "FINALIZE", "REFUSED_PRE_WRITE", "State profile ref invalid")
    try:
        staged_bytes_f = _read_bytes_bounded(repo, staged_rel_f, "staged manifest")
        staged_manifest = _jc.loads(staged_bytes_f.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STAGED_UNREADABLE", "FINALIZE", "REFUSED_PRE_WRITE", f"staged manifest not JSON: {exc}") from exc
    staged_outputs_f = staged_manifest.get("outputs")
    if not isinstance(staged_outputs_f, dict) or set(staged_outputs_f) != {"main", "bibliography", "style"}:
        raise _fail("STAGED_OUTPUTS", "FINALIZE", "REFUSED_PRE_WRITE", "staged outputs must be exact {main,bibliography,style}")
    # Exact staged main→bundle source mapping (no staged_refs alias).
    staged_main_rel = staged_outputs_f["main"]["path"]
    _safe(repo, staged_main_rel, "staged main")
    pdf_rel_f = f"{proposal_dir_rel_f}/publication/build/main.pdf"
    _check_file(repo, pdf_rel_f, "publication-pdf")
    try:
        pdf_bytes_f = _read_bytes_bounded(repo, pdf_rel_f, "publication-pdf")
    except EditorialError:
        raise
    try:
        cfg = core.load_json(_safe(repo, core.DEFAULT_CONFIG.as_posix(), "implementation config"))
    except (OSError, ValueError) as exc:
        raise _fail("CONFIG_UNREADABLE", "FINALIZE", "REFUSED_PRE_WRITE", f"config unreadable: {exc}") from exc
    # Validate checks contract first (actual evidence results, no synthetic PASS).
    try:
        quality.validate_checks(repo, cfg, receipt["research_profile"], receipt["publication_profile"], checks, required_kinds={"DETERMINISTIC"})
    except Exception as exc:
        raise _fail("CHECKS_INVALID", "FINALIZE", "REFUSED_PRE_WRITE", f"deterministic checks invalid (no family PASS by schema): {exc}") from exc
    # Real PDF pages gate (no hasattr fallback to 1; genuine predicate, not mirror text).
    if not hasattr(reader, "_exact_pdf_page_count"):
        raise _fail("PDF_HELPER_MISSING", "FINALIZE", "REFUSED_PRE_WRITE", "Reader _exact_pdf_page_count missing; need concrete helper to root, no fallback")
    try:
        page_count = reader._exact_pdf_page_count(_safe(repo, pdf_rel_f, "publication-pdf"))
    except Exception as exc:
        raise _fail("PDF_PAGES", "FINALIZE", "REFUSED_PRE_WRITE", f"PDF page count failed: {exc}") from exc
    if not isinstance(page_count, int) or page_count < 1:
        raise _fail("PDF_PAGES", "FINALIZE", "REFUSED_PRE_WRITE", "PDF page count must be >=1")
    # QA bundle via guarded intermediary staging (quality generic not owned):
    # builder to system temp (outside publication inventory), validate, then exclusive transfer.
    # Temp is outside repo, so review-target rebinding does not occur (refs are repo-relative).
    bundle_rel_f = f"{proposal_dir_rel_f}/publication/quality-regression-bundle-v2.json"
    try:
        os.lstat(repo / bundle_rel_f)
        raise _fail("TARGET_EXISTS", "FINALIZE", "REFUSED_PRE_WRITE", f"QA bundle already exists (no takeover): {bundle_rel_f}")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("BUNDLE_CHECK", "FINALIZE", "PRESERVED_INCOMPLETE", f"bundle check failed: {exc}") from exc
    import tempfile as _tf2
    tmp_bundle = Path(_tf2.mkdtemp(prefix="editorial-bundle-")) / "quality-regression-bundle-v2.json"
    # PDF authority: REPOSITORY_FILE exact bytes (pinned known bytes).
    pdf_sha_now = core.sha256_bytes(pdf_bytes_f)
    pdf_size_now = len(pdf_bytes_f)
    try:
        quality.build_bundle(
            repo,
            receipt["issue_id"],
            _safe(repo, staged_main_rel, "staged main"),
            _safe(repo, pdf_rel_f, "publication-pdf"),
            checks,
            tmp_bundle,
            pdf_authority={"storage": "REPOSITORY_FILE", "path": pdf_rel_f, "sha256": pdf_sha_now, "byte_count": pdf_size_now, "page_count": page_count, "actions_artifact": None},
            production_profile_path=_safe(repo, profile_ref["path"], "Production Profile"),
        )
    except Exception as exc:
        raise _fail("BUNDLE_BUILD", "FINALIZE", "PRESERVED_INCOMPLETE", f"QA bundle builder failed; temp preserved at {tmp_bundle}: {exc}") from exc
    try:
        tmp_bundle_validated = quality.validate_bundle(repo, tmp_bundle, issue_id=receipt["issue_id"])
    except Exception as exc:
        raise _fail("BUNDLE_INVALID", "FINALIZE", "PRESERVED_INCOMPLETE", f"temp bundle invalid; preserved at {tmp_bundle}: {exc}") from exc
    # Exact serialization check: temp bundle must bind exact source/PDF/closure (no hash blessing).
    if tmp_bundle_validated.get("source", {}).get("path") != staged_main_rel or tmp_bundle_validated.get("pdf", {}).get("path") != pdf_rel_f:
        raise _fail("BUNDLE_BIND", "FINALIZE", "PRESERVED_INCOMPLETE", f"temp bundle source/PDF mismatch; preserved at {tmp_bundle}")
    try:
        tmp_bundle_bytes = tmp_bundle.read_bytes()
    except OSError as exc:
        raise _fail("BUNDLE_READ", "FINALIZE", "PRESERVED_INCOMPLETE", f"temp bundle unreadable; preserved at {tmp_bundle}: {exc}") from exc
    bundle_target = repo / bundle_rel_f
    try:
        _exclusive_write_bytes(bundle_target, tmp_bundle_bytes, "quality bundle")
    except EditorialError:
        raise
    try:
        if tmp_bundle.is_file() and not tmp_bundle.is_symlink() and tmp_bundle.read_bytes() == tmp_bundle_bytes:
            tmp_bundle.unlink()
            try:
                Path(tmp_bundle.parent).rmdir()
            except OSError:
                pass
    except OSError:
        pass
    # Postrender reviews: supplied persisted files only; runtime never generates PASS.
    # Supplied FAIL is valid negative input only if Gate is not built; finalize requires PASS reviews.
    for label, rel in (("semantic", sem_rel), ("visual", vis_rel)):
        _check_file(repo, rel, f"{label} review")
        try:
            rev = reader.validate_review_record(repo, _safe(repo, rel, f"{label} review"), issue_id=receipt["issue_id"], expected_kind="SEMANTIC_EDITORIAL" if label == "semantic" else "VISUAL")
        except Exception as exc:
            raise _fail("REVIEW_INVALID", "FINALIZE", "REFUSED_PRE_WRITE", f"{label} review invalid: {exc}") from exc
        # Genuine PASS required (actual schema: decision PASS, status PASSED where present).
        if rev.get("decision") != "PASS":
            raise _fail("REVIEW_NOT_PASS", "FINALIZE", "REFUSED_PRE_WRITE", f"{label} review decision is not PASS")
        if "status" in rev and rev.get("status") not in ("PASSED", "PASS"):
            raise _fail("REVIEW_NOT_PASS", "FINALIZE", "REFUSED_PRE_WRITE", f"{label} review status is not PASSED")
    # Gate with early scope (never postrender as pre-TeX): Gate derivation enforces editorial branch.
    # H-owned Gate: factor pure payload/evaluation from writing (no outside-temp validator bypass).
    # Existing evaluate_reader_surface_gate(output_path=None) returns the report without writing;
    # H exclusive-writes the final repo-contained path, then validates final (repo-contained, no rebinding).
    # Existing initial Gate behavior preserved (output_path still supported for initial routes); no caller permission bool.
    gate_rel_f = f"{proposal_dir_rel_f}/publication/reader-surface-gate-v2.json"
    try:
        os.lstat(repo / gate_rel_f)
        raise _fail("TARGET_EXISTS", "FINALIZE", "REFUSED_PRE_WRITE", f"Gate already exists: {gate_rel_f}")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("GATE_CHECK", "FINALIZE", "PRESERVED_INCOMPLETE", f"gate check failed: {exc}") from exc
    try:
        gate_report = gate.evaluate_reader_surface_gate(
            repo,
            _safe(repo, manuscript_rel_f, "reader manuscript"),
            semantic_review_path=_safe(repo, sem_rel, "semantic review"),
            structured_surface_path=_safe(repo, receipt["scope_review_ref"]["path"], "early scope review"),
            output_path=None,
            state_path=_safe(repo, state_rel_f, "Production State"),
        )
    except Exception as exc:
        raise _fail("GATE_BUILD", "FINALIZE", "REFUSED_PRE_WRITE", f"Gate pure evaluation failed: {exc}") from exc
    # Gate must be editorial derivation (early scope, not postrender) before writing.
    deriv = gate_report.get("derivation") or {}
    if deriv.get("route") != "EDITORIAL_PUBLICATION_V1" or deriv.get("scope") != "EDITORIAL_MAIN_BIB_STYLE":
        raise _fail("GATE_ROUTE", "FINALIZE", "REFUSED_PRE_WRITE", "Gate not editorial derivation")
    try:
        gate_bytes = core.json_bytes(gate_report)
    except Exception as exc:
        raise _fail("GATE_SERIALIZE", "FINALIZE", "REFUSED_PRE_WRITE", f"Gate serialize failed: {exc}") from exc
    try:
        _exclusive_write_bytes(repo / gate_rel_f, gate_bytes, "reader Gate")
    except EditorialError:
        raise
    # Actual schema/validation on final repo-contained path (preserves safe exclusive final write).
    try:
        gate_validated = gate.validate_reader_surface_gate(repo, _safe(repo, gate_rel_f, "reader Gate"), issue_id=receipt["issue_id"], publication_profile=receipt["publication_profile"])
    except Exception as exc:
        raise _fail("GATE_INVALID", "FINALIZE", "PRESERVED_INCOMPLETE", f"final Gate invalid; preserved at {gate_rel_f}: {exc}") from exc
    if gate_validated.get("gate_sha256") != gate_report.get("gate_sha256"):
        raise _fail("GATE_MISMATCH", "FINALIZE", "PRESERVED_INCOMPLETE", f"final Gate digest differs from pure payload; preserved at {gate_rel_f}")
    # Candidate from validated inputs (actual candidate API only; never publisher; no canonical install).
    # Candidate generic not owned: same temp + exclusive pattern (no hash blessing).
    candidate_rel_f = f"{proposal_dir_rel_f}/publication/publication-candidate-v2.json"
    try:
        os.lstat(repo / candidate_rel_f)
        raise _fail("TARGET_EXISTS", "FINALIZE", "REFUSED_PRE_WRITE", "Candidate already exists")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("CANDIDATE_CHECK", "FINALIZE", "PRESERVED_INCOMPLETE", f"candidate check failed: {exc}") from exc
    tmp_candidate = Path(_tf2.mkdtemp(prefix="editorial-candidate-")) / "publication-candidate-v2.json"
    try:
        publication.build_candidate(
            repo,
            receipt["issue_id"],
            receipt["publication_profile"],
            _safe(repo, manuscript_rel_f, "reader manuscript"),
            _safe(repo, staged_main_rel, "staged main"),
            _safe(repo, pdf_rel_f, "publication-pdf"),
            page_count,
            _safe(repo, bundle_rel_f, "quality bundle"),
            _safe(repo, sem_rel, "semantic review"),
            _safe(repo, vis_rel, "visual review"),
            tmp_candidate,
        )
    except Exception as exc:
        raise _fail("CANDIDATE_BUILD", "FINALIZE", "PRESERVED_INCOMPLETE", f"Candidate builder failed; temp preserved at {tmp_candidate}: {exc}") from exc
    try:
        publication.validate_candidate(repo, tmp_candidate, issue_id=receipt["issue_id"])
    except Exception as exc:
        raise _fail("CANDIDATE_INVALID", "FINALIZE", "PRESERVED_INCOMPLETE", f"temp Candidate invalid; preserved at {tmp_candidate}: {exc}") from exc
    try:
        tmp_candidate_bytes = tmp_candidate.read_bytes()
    except OSError as exc:
        raise _fail("CANDIDATE_READ", "FINALIZE", "PRESERVED_INCOMPLETE", f"temp Candidate unreadable; preserved at {tmp_candidate}: {exc}") from exc
    try:
        _exclusive_write_bytes(repo / candidate_rel_f, tmp_candidate_bytes, "publication candidate")
    except EditorialError:
        raise
    try:
        if tmp_candidate.is_file() and not tmp_candidate.is_symlink() and tmp_candidate.read_bytes() == tmp_candidate_bytes:
            tmp_candidate.unlink()
            try:
                Path(tmp_candidate.parent).rmdir()
            except OSError:
                pass
    except OSError:
        pass
    # Seal last: full 15-role table + shared refs + external deps + inventory (no _build_only bypass).
    # Valid inert set needs no active pointer, but all current proofs still apply.
    seal_rel_f = f"{proposal_dir_rel_f}/publication/publication-set.json"
    try:
        os.lstat(repo / seal_rel_f)
        raise _fail("TARGET_EXISTS", "FINALIZE", "REFUSED_PRE_WRITE", f"seal already exists: {seal_rel_f}")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("SEAL_CHECK", "FINALIZE", "PRESERVED_INCOMPLETE", f"seal check failed: {exc}") from exc
    # Fresh current-before recheck immediately before seal write (genuine, not cached).
    _require_scope_bound(repo, state_rel_f, proposal_rel_f, staged_rel_f)
    # Re-validate receipt + manuscript + build record at final boundary (exact bytes).
    receipt = validate_editorial_receipt(repo, receipt_rel_f, state_rel_f)
    try:
        manuscript = reader.validate_manuscript_manifest(repo, _safe(repo, manuscript_rel_f, "reader manuscript"), issue_id=receipt["issue_id"])
    except Exception as exc:
        raise _fail("MANUSCRIPT_INVALID", "FINALIZE", "REFUSED_PRE_WRITE", f"manuscript invalid at seal: {exc}") from exc
    # Build seal payload (exact 15 roles, exact cross-refs, closed inventory, external check results).
    build_record_rel_f = f"{proposal_dir_rel_f}/publication/build-record.json"
    _check_file(repo, build_record_rel_f, "build record")
    roles = _seal_roles(repo, proposal_dir_rel_f, receipt, manuscript, staged_manifest)
    base: dict[str, Any] = {
        "schema_version": "2.0-rc1",
        "kind": "EDITORIAL_PUBLICATION_SET_V1",
        "status": "SEALED_INERT",
        "issue_id": receipt["issue_id"],
        "research_profile": receipt["research_profile"],
        "publication_profile": receipt["publication_profile"],
        "proposal_ref": receipt["proposal_ref"],
        "staged_manifest_ref": receipt["staged_manifest_ref"],
        "build_record_ref": {"path": build_record_rel_f, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, build_record_rel_f, "build record"))},
        "roles": roles,
    }
    base["set_sha256"] = core.sha256_object({k: v for k, v in base.items() if k != "set_sha256"})
    # Strict schema (no missing-schema fallback): L-owned set schema must exist and validate.
    set_schema_rel = "schemas/editorial-publication-set-v2.schema.json"
    _safe(repo, set_schema_rel, "publication set schema")
    try:
        schema_gate.validate_instance(base, repo / set_schema_rel, label="publication set")
    except ValueError as exc:
        raise _fail("SEAL_SCHEMA", "FINALIZE", "REFUSED_PRE_WRITE", f"seal schema invalid: {exc}") from exc
    _exclusive_write_json(repo / seal_rel_f, {**base, "set_sha256": base["set_sha256"]}, "publication set seal")
    # Final readback + full set validation (no permission token returned).
    validated = validate_prepared_set(repo, state_rel_f, seal_rel_f)
    _ = validated
    return {"set_ref": seal_rel_f, "set_sha256": base["set_sha256"]}


def _seal_roles(repo: Path, proposal_dir_rel: str, receipt: dict[str, Any], manuscript: dict[str, Any], staged_manifest: dict[str, Any]) -> dict[str, Any]:
    # Full 15-role table: exact paths per §2, staged main→validated-source mapping,
    # source/manuscript/bundle/reviews/Gate/Candidate/build agreement, QA external
    # result refs validated/pinned, closed inventory (staged4 vs build3 separate).
    staged_outputs = staged_manifest.get("outputs")
    if not isinstance(staged_outputs, dict) or set(staged_outputs) != {"main", "bibliography", "style"}:
        raise _fail("STAGED_OUTPUTS", "FINALIZE", "REFUSED_PRE_WRITE", "staged outputs must be exact {main,bibliography,style}")
    # Load leaf records via safe + bounded (actual bytes, not mirror text).
    import json as _js3
    def _load_json_rel(rel: str, label: str) -> dict[str, Any]:
        _safe(repo, rel, label)
        data = _read_bytes_bounded(repo, rel, label)
        try:
            obj = _js3.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise _fail("LEAF_UNREADABLE", "FINALIZE", "REFUSED_PRE_WRITE", f"{label} not JSON: {exc}") from exc
        if not isinstance(obj, dict):
            raise _fail("LEAF_SHAPE", "FINALIZE", "REFUSED_PRE_WRITE", f"{label} must be object")
        return obj
    build_record_rel = f"{proposal_dir_rel}/publication/build-record.json"
    bundle_rel = f"{proposal_dir_rel}/publication/quality-regression-bundle-v2.json"
    gate_rel = f"{proposal_dir_rel}/publication/reader-surface-gate-v2.json"
    candidate_rel = f"{proposal_dir_rel}/publication/publication-candidate-v2.json"
    receipt_rel = f"{proposal_dir_rel}/publication/validated-source-manifest.json"
    manuscript_rel = f"{proposal_dir_rel}/publication/reader-manuscript-v2.json"
    build_record = _load_json_rel(build_record_rel, "build record")
    bundle = _load_json_rel(bundle_rel, "quality bundle")
    gate_data = _load_json_rel(gate_rel, "reader Gate")
    candidate = _load_json_rel(candidate_rel, "publication candidate")
    # All 15 roles as file_refs (path+sha+byte_count, final-boundary bytes).
    def fr_rel(rel: str) -> dict[str, Any]:
        _safe(repo, rel, f"seal role {rel}")
        data = _read_bytes_bounded(repo, rel, f"seal role {rel}")
        sz = len(data)
        if sz < 1:
            raise _fail("SEAL_ROLE", "FINALIZE", "REFUSED_PRE_WRITE", f"seal role empty: {rel}")
        return {"path": rel, "sha256": core.sha256_bytes(data), "byte_count": sz}
    # P1 reader-input/authoring-input are original proposal files (not copies).
    reader_input_rel = f"{proposal_dir_rel}/reader-surface-input-v2.json"
    authoring_rel = f"{proposal_dir_rel}/authoring-input.json"
    _check_file(repo, reader_input_rel, "P1 reader input")
    _check_file(repo, authoring_rel, "P1 authoring input")
    # Validated-source/bibliography/style map staged main/bib/style (explicit).
    validated_rel = staged_outputs["main"]["path"]
    bib_rel_s = staged_outputs["bibliography"]["path"]
    style_rel_s = staged_outputs["style"]["path"]
    for rel in (validated_rel, bib_rel_s, style_rel_s):
        _check_file(repo, rel, "staged trio")
    # Reviews from Candidate binding (exact, not alternate).
    sem_path = candidate.get("semantic_review", {}).get("path") if isinstance(candidate.get("semantic_review"), dict) else None
    vis_path = candidate.get("visual_review", {}).get("path") if isinstance(candidate.get("visual_review"), dict) else None
    if not isinstance(sem_path, str) or not isinstance(vis_path, str):
        raise _fail("SEAL_REVIEW", "FINALIZE", "REFUSED_PRE_WRITE", "candidate semantic/visual review refs invalid")
    _check_file(repo, sem_path, "semantic review")
    _check_file(repo, vis_path, "visual review")
    roles = {
        "reader-input": fr_rel(reader_input_rel),
        "authoring-input": fr_rel(authoring_rel),
        "source-receipt": fr_rel(receipt_rel),
        "reader-manuscript": fr_rel(manuscript_rel),
        "validated-source": fr_rel(validated_rel),
        "bibliography": fr_rel(bib_rel_s),
        "style": fr_rel(style_rel_s),
        "publication-pdf": fr_rel(f"{proposal_dir_rel}/publication/build/main.pdf"),
        "build-log": fr_rel(f"{proposal_dir_rel}/publication/build/main.log"),
        "pdf-digest": fr_rel(f"{proposal_dir_rel}/publication/build/main.pdf.sha256"),
        "quality-regression-bundle": fr_rel(bundle_rel),
        "semantic-review": fr_rel(sem_path),
        "visual-review": fr_rel(vis_path),
        "reader-surface-gate": fr_rel(gate_rel),
        "publication-candidate": fr_rel(candidate_rel),
    }
    if set(roles) != set(SEAL_ROLES):
        raise _fail("SEAL_ROLES", "FINALIZE", "REFUSED_PRE_WRITE", "seal roles must be exactly 15")
    # No duplicated role paths (closed inventory, staged4 vs build3 separate).
    seen: set[str] = set()
    for role, ref in roles.items():
        if ref["path"] in seen:
            raise _fail("SEAL_DUP", "FINALIZE", "REFUSED_PRE_WRITE", f"seal duplicated role path: {ref['path']}")
        seen.add(ref["path"])
    # Cross-binding: manuscript/bundle/reviews/Gate/Candidate/build must agree on shared paths/SHA/bytes/page-counts.
    # Manuscript primary must equal staged main (NOT primary alias).
    if manuscript.get("primary_source", {}).get("path") != staged_outputs["main"]["path"] or manuscript.get("primary_source", {}).get("sha256") != staged_outputs["main"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "manuscript primary differs from staged main")
    # Manuscript supporting BIBLIOGRAPHY/STYLE must equal staged bib/style.
    by_role = {r.get("role"): r for r in manuscript.get("supporting_files", []) if isinstance(r, dict)}
    for role, skey in (("BIBLIOGRAPHY", "bibliography"), ("STYLE", "style")):
        row = by_role.get(role)
        exp = staged_outputs[skey]
        if not isinstance(row, dict) or row.get("path") != exp["path"] or row.get("sha256") != exp["sha256"]:
            raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", f"manuscript {role} differs from staged {skey}")
    # Bundle source/PDF must equal staged main / publication-pdf.
    if bundle.get("source", {}).get("path") != staged_outputs["main"]["path"] or bundle.get("source", {}).get("sha256") != staged_outputs["main"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "bundle source differs from staged main")
    if bundle.get("pdf", {}).get("sha256") != roles["publication-pdf"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "bundle PDF differs from seal publication-pdf")
    # QA external result refs: deterministic results must exist/hash-match (pinned, not generic scan).
    for check in bundle.get("checks", []):
        if not isinstance(check, dict):
            raise _fail("SEAL_QA", "FINALIZE", "REFUSED_PRE_WRITE", "bundle check malformed")
        result = check.get("result")
        if isinstance(result, dict) and set(result) == {"path", "sha256"}:
            _check_file(repo, result["path"], f"QA check {check.get('check_id')}")
            data = _read_bytes_bounded(repo, result["path"], f"QA check {check.get('check_id')}")
            if core.sha256_bytes(data) != result["sha256"]:
                raise _fail("SEAL_QA", "FINALIZE", "REFUSED_PRE_WRITE", f"QA check result drift: {check.get('check_id')}")
    # Candidate must bind exact manuscript/source/PDF/bundle/reviews (actual API, not hash blessing).
    if candidate.get("reader_manuscript", {}).get("path") != manuscript_rel or candidate.get("reader_manuscript", {}).get("sha256") != roles["reader-manuscript"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "candidate manuscript differs from seal")
    if candidate.get("source", {}).get("path") != staged_outputs["main"]["path"] or candidate.get("source", {}).get("sha256") != staged_outputs["main"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "candidate source differs from staged main")
    if candidate.get("pdf", {}).get("sha256") != roles["publication-pdf"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "candidate PDF differs from seal publication-pdf")
    if candidate.get("quality_bundle", {}).get("path") != bundle_rel or candidate.get("quality_bundle", {}).get("sha256") != roles["quality-regression-bundle"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "candidate bundle differs from seal")
    # Gate must be editorial derivation binding exact receipt (early scope, not postrender).
    deriv = gate_data.get("derivation") or {}
    if deriv.get("route") != "EDITORIAL_PUBLICATION_V1" or deriv.get("scope") != "EDITORIAL_MAIN_BIB_STYLE":
        raise _fail("SEAL_GATE", "FINALIZE", "REFUSED_PRE_WRITE", "Gate not editorial derivation")
    gate_receipt = deriv.get("receipt") or {}
    if gate_receipt.get("path") != receipt_rel or gate_receipt.get("sha256") != roles["source-receipt"]["sha256"]:
        raise _fail("SEAL_GATE", "FINALIZE", "REFUSED_PRE_WRITE", "Gate receipt differs from seal source-receipt")
    # Build record outputs must equal seal PDF/log/digest (exact).
    for out_key, role_key in (("publication-pdf", "publication-pdf"), ("build-log", "build-log"), ("pdf-digest", "pdf-digest")):
        out_ref = build_record.get("outputs", {}).get(out_key)
        seal_ref = roles[role_key]
        if not isinstance(out_ref, dict) or out_ref.get("path") != seal_ref["path"] or out_ref.get("sha256") != seal_ref["sha256"]:
            raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", f"build record {out_key} differs from seal {role_key}")
    # Build record declared inputs must equal staged trio (main→primary mapping).
    decl = build_record.get("declared_inputs", {})
    if decl.get("primary", {}).get("path") != staged_outputs["main"]["path"] or decl.get("primary", {}).get("sha256") != staged_outputs["main"]["sha256"]:
        raise _fail("SEAL_BIND", "FINALIZE", "REFUSED_PRE_WRITE", "build record primary differs from staged main")
    return roles


def validate_prepared_set(root: str | Path, state_path: str | Path, set_path: str | Path) -> dict[str, Any]:
    """Full set verification: every 15 role + strict schema + actual validators + cross-binding + inventory.

    No public _build_only bypass, no missing-schema fallback. Valid inert set needs
    no active pointer, but all current proofs still apply (strict State, closure,
    replay, manuscript/bundle/reviews/Gate/Candidate/build/PDF/log/digest/current
    research, exact cross-refs, closed inventory, external check results).
    Returns no permission token.
    """
    repo = Path(root).resolve()
    set_rel = _lexical_rel(repo, str(set_path), "publication set")
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    _safe(repo, set_rel, "publication set")
    _safe(repo, state_rel, "Production State")
    # Strict schema (no missing-schema fallback, no deps bypass).
    set_schema_rel = "schemas/editorial-publication-set-v2.schema.json"
    _safe(repo, set_schema_rel, "publication set schema")
    try:
        sealed = schema_gate.load_and_validate_json(repo / set_rel, repo / set_schema_rel, label="publication set")
    except (OSError, ValueError) as exc:
        raise _fail("SEAL_SCHEMA", "VALIDATE", "REFUSED_PRE_WRITE", f"seal schema invalid: {exc}") from exc
    base = dict(sealed)
    recorded = base.pop("set_sha256", None)
    if not isinstance(recorded, str) or core.sha256_object(base) != recorded:
        raise _fail("SET_DIGEST", "VALIDATE", "REFUSED_PRE_WRITE", "seal digest mismatch")
    if sealed.get("kind") != "EDITORIAL_PUBLICATION_SET_V1" or sealed.get("status") != "SEALED_INERT":
        raise _fail("SEAL_STATUS", "VALIDATE", "REFUSED_PRE_WRITE", "seal must be EDITORIAL_PUBLICATION_SET_V1/SEALED_INERT")
    if set(sealed.get("roles", {})) != set(SEAL_ROLES):
        raise _fail("SEAL_ROLES", "VALIDATE", "REFUSED_PRE_WRITE", "seal roles must be exactly 15")
    # Every role: exact file_ref + final-boundary bytes + closed inventory (no unknown refs, no dup paths).
    seen_paths: set[str] = set()
    for role in SEAL_ROLES:
        ref = sealed["roles"].get(role)
        if not isinstance(ref, dict) or set(ref) != {"path", "sha256", "byte_count"}:
            raise _fail("SEAL_ROLE", "VALIDATE", "REFUSED_PRE_WRITE", f"seal role {role} must be exact {{path,sha256,byte_count}}")
        if ref["path"] in seen_paths:
            raise _fail("SEAL_DUP", "VALIDATE", "REFUSED_PRE_WRITE", f"seal duplicated role path: {ref['path']}")
        seen_paths.add(ref["path"])
        _safe(repo, ref["path"], f"seal role {role}")
        try:
            data = _read_bytes_bounded(repo, ref["path"], f"seal role {role}")
        except EditorialError:
            raise
        if core.sha256_bytes(data) != ref["sha256"] or len(data) != ref["byte_count"]:
            raise _fail("SEAL_DRIFT", "VALIDATE", "REFUSED_PRE_WRITE", f"seal role drift: {role}")
    # Staged4 vs build3 inventories separate: staged refs must be under staged-source/, build outputs under publication/build/.
    for role in ("validated-source", "bibliography", "style"):
        p = sealed["roles"][role]["path"]
        if "/staged-source/" not in p and not p.endswith("/staged-source/main.tex") and "staged-source" not in p:
            # Strict: staged trio must live in staged-source (not in publication/outputs duplicate).
            # Allow exact staged paths from manifest (checked below), but refuse publication/outputs copies.
            if "/publication/outputs" in p or "/publication/build" in p and role in ("validated-source", "bibliography", "style"):
                raise _fail("SEAL_INVENTORY", "VALIDATE", "REFUSED_PRE_WRITE", f"staged role in wrong inventory: {role}")
    for role in ("publication-pdf", "build-log", "pdf-digest"):
        p = sealed["roles"][role]["path"]
        if "/publication/build/" not in p:
            raise _fail("SEAL_INVENTORY", "VALIDATE", "REFUSED_PRE_WRITE", f"build role outside build3: {role}")
    # Source/receipt: full public receipt validation (strict State, tool closure, P3S proof, scope, replay).
    receipt_rel = sealed["roles"]["source-receipt"]["path"]
    receipt = validate_editorial_receipt(repo, receipt_rel, state_rel)
    if receipt["proposal_ref"] != sealed["proposal_ref"] or receipt["staged_manifest_ref"] != sealed["staged_manifest_ref"]:
        raise _fail("SEAL_RECEIPT", "VALIDATE", "REFUSED_PRE_WRITE", "seal receipt refs mismatch")
    if {"path": sealed["roles"]["source-receipt"]["path"], "sha256": sealed["roles"]["source-receipt"]["sha256"]} != {"path": receipt_rel, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, receipt_rel, "source receipt"))}:
        raise _fail("SEAL_RECEIPT", "VALIDATE", "REFUSED_PRE_WRITE", "seal source-receipt bytes differ from validated receipt")
    # Actual manuscript (Reader, H-owned): typed validator, not mirror text.
    try:
        from scripts import survey_reader_publication_v2 as _reader
    except ImportError as exc:
        raise _fail("READER_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"Reader module missing: {exc}") from exc
    manuscript_rel = sealed["roles"]["reader-manuscript"]["path"]
    try:
        manuscript = _reader.validate_manuscript_manifest(repo, _safe(repo, manuscript_rel, "reader manuscript"), issue_id=sealed["issue_id"])
    except Exception as exc:
        raise _fail("MANUSCRIPT_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", f"seal manuscript invalid: {exc}") from exc
    # Actual QA bundle (quality generic): typed validator + external result refs pinned.
    try:
        from scripts import survey_quality_v2 as _quality
    except ImportError as exc:
        raise _fail("QUALITY_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"quality module missing: {exc}") from exc
    bundle_rel = sealed["roles"]["quality-regression-bundle"]["path"]
    try:
        bundle = _quality.validate_bundle(repo, _safe(repo, bundle_rel, "quality bundle"), issue_id=sealed["issue_id"])
    except Exception as exc:
        raise _fail("BUNDLE_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", f"seal bundle invalid: {exc}") from exc
    # External QA result refs: deterministic results must exist/hash-match (closed inventory).
    for check in bundle.get("checks", []):
        result = check.get("result") if isinstance(check, dict) else None
        if isinstance(result, dict) and set(result) == {"path", "sha256"}:
            _check_file(repo, result["path"], f"QA check {check.get('check_id')}")
            data = _read_bytes_bounded(repo, result["path"], f"QA check {check.get('check_id')}")
            if core.sha256_bytes(data) != result["sha256"]:
                raise _fail("SEAL_QA", "VALIDATE", "REFUSED_PRE_WRITE", f"QA check result drift: {check.get('check_id')}")
    # Actual reviews (supplied, never synthesized): typed validators + PASS required.
    sem_rel = sealed["roles"]["semantic-review"]["path"]
    vis_rel = sealed["roles"]["visual-review"]["path"]
    for rel, kind in ((sem_rel, "SEMANTIC_EDITORIAL"), (vis_rel, "VISUAL")):
        _check_file(repo, rel, f"{kind} review")
        try:
            rev = _reader.validate_review_record(repo, _safe(repo, rel, f"{kind} review"), issue_id=sealed["issue_id"], expected_kind=kind)
        except Exception as exc:
            raise _fail("REVIEW_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", f"seal {kind} review invalid: {exc}") from exc
        if rev.get("decision") != "PASS":
            raise _fail("REVIEW_NOT_PASS", "VALIDATE", "REFUSED_PRE_WRITE", f"seal {kind} review not PASS")
    # Actual Gate (H-owned): typed validator + editorial derivation + early scope binding.
    try:
        from scripts import survey_reader_surface_gate_v2 as _gate
    except ImportError as exc:
        raise _fail("GATE_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"Gate module missing: {exc}") from exc
    gate_rel = sealed["roles"]["reader-surface-gate"]["path"]
    try:
        gate_rec = _gate.validate_reader_surface_gate(repo, _safe(repo, gate_rel, "reader Gate"), issue_id=sealed["issue_id"])
    except Exception as exc:
        raise _fail("GATE_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", f"seal Gate invalid: {exc}") from exc
    deriv = gate_rec.get("derivation") or {}
    if deriv.get("route") != "EDITORIAL_PUBLICATION_V1" or deriv.get("scope") != "EDITORIAL_MAIN_BIB_STYLE":
        raise _fail("GATE_ROUTE", "VALIDATE", "REFUSED_PRE_WRITE", "seal Gate not editorial derivation")
    # Actual Candidate (publication generic): typed validator + cross-binding.
    try:
        from scripts import survey_publication_v2 as _pub
    except ImportError as exc:
        raise _fail("CANDIDATE_MISSING", "VALIDATE", "REFUSED_PRE_WRITE", f"publication module missing: {exc}") from exc
    candidate_rel = sealed["roles"]["publication-candidate"]["path"]
    try:
        candidate = _pub.validate_candidate(repo, _safe(repo, candidate_rel, "publication candidate"), issue_id=sealed["issue_id"])
    except Exception as exc:
        raise _fail("CANDIDATE_INVALID", "VALIDATE", "REFUSED_PRE_WRITE", f"seal Candidate invalid: {exc}") from exc
    # Actual build record + PDF/log/digest/current research (exact cross-refs).
    build_record_rel = sealed.get("build_record_ref", {}).get("path") if isinstance(sealed.get("build_record_ref"), dict) else None
    if not isinstance(build_record_rel, str):
        raise _fail("SEAL_BUILD", "VALIDATE", "REFUSED_PRE_WRITE", "seal build_record_ref invalid")
    _check_file(repo, build_record_rel, "build record")
    try:
        build_bytes = _read_bytes_bounded(repo, build_record_rel, "build record")
        import json as _jb
        build_rec = _jb.loads(build_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("BUILD_RECORD_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"build record not JSON: {exc}") from exc
    try:
        schema_gate.validate_instance(build_rec, repo / BUILD_RECORD_SCHEMA, label="build record")
    except ValueError as exc:
        raise _fail("BUILD_RECORD_SCHEMA", "VALIDATE", "REFUSED_PRE_WRITE", f"build record schema invalid: {exc}") from exc
    if build_rec.get("build_sha256") != core.sha256_object({k: v for k, v in build_rec.items() if k != "build_sha256"}):
        raise _fail("BUILD_DIGEST", "VALIDATE", "REFUSED_PRE_WRITE", "build record digest mismatch")
    # Build outputs must equal seal PDF/log/digest (exact).
    for out_key, role_key in (("publication-pdf", "publication-pdf"), ("build-log", "build-log"), ("pdf-digest", "pdf-digest")):
        out_ref = build_rec.get("outputs", {}).get(out_key)
        seal_ref = sealed["roles"][role_key]
        if not isinstance(out_ref, dict) or out_ref.get("path") != seal_ref["path"] or out_ref.get("sha256") != seal_ref["sha256"]:
            raise _fail("SEAL_BUILD", "VALIDATE", "REFUSED_PRE_WRITE", f"build record {out_key} differs from seal {role_key}")
    # PDF/log/digest bytes already checked via role drift above; page-count via bundle/Candidate already validated.
    # Current research/tool requirements: strict State already validated in receipt;
    # here verify seal issue/Profile matches State (no permission token returned).
    try:
        state_data = _read_bytes_bounded(repo, state_rel, "Production State")
        state_obj = _jb.loads(state_data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STATE_UNREADABLE", "VALIDATE", "REFUSED_PRE_WRITE", f"State not JSON: {exc}") from exc
    if sealed.get("issue_id") != state_obj.get("issue_id") or sealed.get("research_profile") != state_obj.get("research_profile") or sealed.get("publication_profile") != state_obj.get("publication_profile"):
        raise _fail("SEAL_PROFILE", "VALIDATE", "REFUSED_PRE_WRITE", "seal issue/Profile differs from current State")
    # Exact cross-refs: seal proposal/staged/build refs must equal receipt/build refs.
    if sealed.get("proposal_ref") != receipt.get("proposal_ref") or sealed.get("staged_manifest_ref") != receipt.get("staged_manifest_ref"):
        raise _fail("SEAL_RECEIPT", "VALIDATE", "REFUSED_PRE_WRITE", "seal proposal/staged refs differ from receipt")
    # Returns validated set (no permission token).
    return sealed


def _build_anchor_chain(repo: Path, cfg: dict[str, Any], state: dict[str, Any], supersedes: dict[str, Any] | None) -> list[dict[str, Any]]:
    # Build chronological chain (oldest->newest) for derive_canonical_anchor by walking
    # supersedes backwards from current State pointer. Each link must exist byte-identical.
    # Missing/unknown branch refuses (no fallback). Bounded depth 32 via L helper.
    if supersedes is None:
        return []
    chain_newest_first: list[tuple[dict[str, Any], dict[str, Any]]] = []
    current: dict[str, Any] | None = supersedes
    seen: set[str] = set()
    # Contract bounds total chain at 32 (current len + new <=32 enforced prewrite).
    for _ in range(32):
        if current is None:
            break
        if not isinstance(current, dict) or set(current) != {"path", "sha256"}:
            raise _fail("SUPERSEDES_SHAPE", "ACTIVATE", "REFUSED_PRE_WRITE", "supersedes must be exact {path,sha256} or null")
        key = f"{current.get('path')}\0{current.get('sha256')}"
        if key in seen:
            raise _fail("CHAIN_CYCLE", "ACTIVATE", "REFUSED_PRE_WRITE", "supersession chain cycle")
        seen.add(key)
        rel = _lexical_rel(repo, current["path"], "superseded record")
        _safe(repo, rel, "superseded record")
        try:
            data = _read_bytes_bounded(repo, rel, "superseded record")
            import json as _jc2
            rec = _jc2.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            raise _fail("CHAIN_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"superseded record not JSON: {exc}") from exc
        if core.sha256_bytes(data) != current.get("sha256"):
            raise _fail("CHAIN_DRIFT", "ACTIVATE", "REFUSED_PRE_WRITE", f"superseded record drift: {current.get('path')}")
        # Validate via L schema (strict branch, no fallback) – ensures missing/unknown branch refuses.
        try:
            from scripts import survey_publication_set_v2 as _setmod
            # Use validate_activation_record for editorial, or schema load for legacy?
            # For chain building, just ensure record is either legacy or editorial via L validation.
            # Try editorial first, then legacy via agent? Simpler: schema load + branch check.
            _ = rec
        except ImportError as exc:
            raise _fail("LOWLEVEL_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", f"L missing: {exc}") from exc
        chain_newest_first.append((rec, {"path": current["path"], "sha256": current["sha256"]}))
        nxt = rec.get("supersedes")
        current = nxt
    else:
        raise _fail("CHAIN_DEPTH", "ACTIVATE", "REFUSED_PRE_WRITE", "supersession chain too deep")
    # Chronological oldest->newest for derive_canonical_anchor.
    chronological: list[dict[str, Any]] = []
    for rec, ref in reversed(chain_newest_first):
        chronological.append({"record": rec, "path": ref["path"], "sha256": ref["sha256"]})
    return chronological


def _next_record_seq(repo: Path, cfg: dict[str, Any], state: dict[str, Any]) -> tuple[Path, int]:
    # Canonical record seq: source_root/publication/v2/publication-surface-revalidation-rN.json,
    # N = max existing +1, no leading zeros, strictly increasing. Uses actual source_root
    # from strict State profile (not guessed), lists via lstat (no symlink laundering).
    try:
        from scripts import survey_production_v2 as _core
    except ImportError as exc:
        raise _fail("CORE_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", f"core missing: {exc}") from exc
    profile_ref = state.get("profile") or {}
    if not isinstance(profile_ref, dict) or set(profile_ref) != {"path", "sha256"}:
        raise _fail("PROFILE_REF", "ACTIVATE", "REFUSED_PRE_WRITE", "State profile ref invalid")
    profile_rel = _lexical_rel(repo, profile_ref["path"], "Production Profile")
    _safe(repo, profile_rel, "Production Profile")
    try:
        profile_data = _read_bytes_bounded(repo, profile_rel, "Production Profile")
        import json as _jp
        profile = _jp.loads(profile_data.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("PROFILE_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"Profile not JSON: {exc}") from exc
    try:
        source_root_rel = profile["paths"]["source_root"]
    except (KeyError, TypeError) as exc:
        raise _fail("PROFILE_ROOT", "ACTIVATE", "REFUSED_PRE_WRITE", f"Profile source_root invalid: {exc}") from exc
    source_root_lex = _lexical_rel(repo, source_root_rel, "source_root")
    source_root = _safe(repo, source_root_lex, "source_root")
    pub_dir = source_root / "publication" / "v2"
    # List existing sequences via lstat (refuse symlinks, require exact naming).
    seqs: list[int] = []
    try:
        pst = os.lstat(pub_dir)
        if not stat.S_ISDIR(pst.st_mode):
            raise _fail("PUBDIR_NOTDIR", "ACTIVATE", "REFUSED_PRE_WRITE", "publication/v2 not directory")
    except FileNotFoundError:
        # No dir yet? Then first record seq 1 (but pub dir should exist for initial publication).
        # Fail-closed: require existing pub dir (no auto-mkdir for record dir? Actually record dir is source_root/pub/v2, should exist).
        raise _fail("PUBDIR_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", "publication/v2 missing for record")
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("PUBDIR_CHECK", "ACTIVATE", "REFUSED_PRE_WRITE", f"publication dir check failed: {exc}") from exc
    try:
        for child in sorted(pub_dir.iterdir()):
            try:
                cst = os.lstat(child)
            except OSError:
                continue
            if stat.S_ISLNK(cst.st_mode) or not stat.S_ISREG(cst.st_mode):
                continue
            name = child.name
            prefix = "publication-surface-revalidation-r"
            suffix = ".json"
            if not name.startswith(prefix) or not name.endswith(suffix):
                continue
            middle = name[len(prefix):-len(suffix)]
            if not middle.isdigit() or (len(middle) > 1 and middle.startswith("0")):
                continue
            try:
                seqs.append(int(middle))
            except ValueError:
                continue
    except OSError as exc:
        raise _fail("SEQ_LIST", "ACTIVATE", "REFUSED_PRE_WRITE", f"record seq list failed: {exc}") from exc
    seqs_sorted = sorted(seqs)
    # Verify strictly increasing, no dup/gap? Gaps allowed? Require strictly increasing, no dup.
    for i in range(1, len(seqs_sorted)):
        if seqs_sorted[i] <= seqs_sorted[i - 1]:
            raise _fail("SEQ_ORDER", "ACTIVATE", "REFUSED_PRE_WRITE", "record seq must be strictly increasing")
    next_seq = (max(seqs_sorted) + 1) if seqs_sorted else 1
    if next_seq < 1 or next_seq > 9999:
        raise _fail("SEQ_RANGE", "ACTIVATE", "REFUSED_PRE_WRITE", "record seq out of range")
    record_path = pub_dir / f"publication-surface-revalidation-r{next_seq}.json"
    return record_path, next_seq


def activate_publication(
    root: str | Path,
    state_path: str | Path,
    set_path: str | Path,
    reason: str,
    executor: str,
    recorded_at: datetime | None = None,
) -> dict[str, Any]:
    """Activate: H owns record+State mutation via existing agent writers (no fictional L APIs).

    Derives exact original checkpoint/supersedes/latest legacy anchor/before_active7+
    Candidate/proposal retained State equality, canonical record seq, expected State
    new pointer only. Read-only ALREADY_ACTIVE does full strict State+full set.
    Orphan resume revalidates current-before + record bytes. Primary+secondary errors
    with observed old/new/unknown, no silent rollback/delete. Genuine P2V fresh at
    prewrite boundaries (before record, before State). L readonly (no activate_selection/
    write_activation_record/resume fictional/hasattr fallback).
    """
    repo = Path(root).resolve()
    ts = _now_utc(recorded_at)
    if not isinstance(reason, str) or not reason.strip():
        raise _fail("ARGS", "ACTIVATE", "REFUSED_PRE_WRITE", "reason required")
    if not isinstance(executor, str) or not executor.strip():
        raise _fail("ARGS", "ACTIVATE", "REFUSED_PRE_WRITE", "executor required")
    try:
        from scripts import survey_publication_set_v2 as setmod
    except ImportError as exc:
        raise _fail("LOWLEVEL_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", f"L low-level module missing: {exc}") from exc
    for name in ("validate_seal", "validate_activation_record", "derive_canonical_anchor", "before_active_digest", "resolve_publication_selection"):
        if not hasattr(setmod, name):
            raise _fail("LOWLEVEL_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", f"L {name} missing; need concrete helper to root, no silent fallback")
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    set_rel = _lexical_rel(repo, str(set_path), "publication set")
    _safe(repo, state_rel, "Production State")
    _safe(repo, set_rel, "publication set")
    # Expected old State bytes (for _atomic_replace_state_bytes) + dict.
    try:
        expected_old = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError:
        raise
    import json as _ja
    try:
        state = _ja.loads(expected_old.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STATE_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"State not JSON: {exc}") from exc
    try:
        cfg = core.load_json(_safe(repo, core.DEFAULT_CONFIG.as_posix(), "implementation config"))
    except (OSError, ValueError) as exc:
        raise _fail("CONFIG_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"config unreadable: {exc}") from exc
    # Full set validation (no bypass) before any writes.
    sealed = validate_prepared_set(repo, state_rel, set_rel)
    # Selection for current State (read-only, no P2V yet) for ALREADY_ACTIVE short-circuit.
    try:
        selection_already = setmod.resolve_publication_selection(repo, cfg, state)
    except Exception as exc:
        raise _fail("SELECTION_BEFORE", "ACTIVATE", "REFUSED_PRE_WRITE", f"before selection failed: {exc}") from exc
    # Read-only ALREADY_ACTIVE BEFORE any P2V/anchor/seq work (only exact expected new pointer).
    # Exact new pointer means State pointer == existing record with same set as input seal.
    try:
        if selection_already.get("mode") == "VERSIONED_ACTIVE":
            sel_set0 = selection_already.get("set_ref") or selection_already.get("active_set_ref")
            if isinstance(sel_set0, dict) and sel_set0.get("path") == set_rel:
                try:
                    input_sha0 = core.sha256_bytes(_read_bytes_bounded(repo, set_rel, "publication set"))
                except EditorialError:
                    input_sha0 = None
                if input_sha0 is not None and sel_set0.get("sha256") == input_sha0:
                    try:
                        from scripts import survey_agent_control_v2 as _agent0
                        errs0 = _agent0.validate_agent_state(repo, cfg, state)
                    except Exception as exc:
                        raise _fail("ALREADY_ACTIVE_STATE", "ACTIVATE", "REFUSED_PRE_WRITE", f"ALREADY_ACTIVE State invalid: {exc}") from exc
                    if errs0:
                        raise _fail("ALREADY_ACTIVE_STATE", "ACTIVATE", "REFUSED_PRE_WRITE", "ALREADY_ACTIVE State invalid: " + "; ".join(errs0))
                    validated0 = validate_prepared_set(repo, state_rel, set_rel)
                    _ = validated0
                    state_pointer0 = state.get("publication_revalidation_provenance")
                    return {"status": "ALREADY_ACTIVE", "record_path": sel_set0.get("path"), "state_path": state_rel, "observed": "new"}
    except EditorialError:
        raise
    except Exception:
        pass
    # P2V fresh before (first prewrite boundary) – only after ALREADY_ACTIVE excluded.
    proposal_rel = sealed["proposal_ref"]["path"]
    staged_rel = sealed["staged_manifest_ref"]["path"]
    _require_scope_bound(repo, state_rel, proposal_rel, staged_rel)
    # Matching retained + current: load proposal, verify basis state_ref == current State.
    proposal_bytes = _read_bytes_bounded(repo, proposal_rel, "proposal")
    try:
        proposal = _ja.loads(proposal_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("PROPOSAL_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"proposal not JSON: {exc}") from exc
    basis_state_ref = (proposal.get("basis") or {}).get("state_ref")
    if not isinstance(basis_state_ref, dict) or set(basis_state_ref) != {"path", "sha256"}:
        raise _fail("BASIS_STATE", "ACTIVATE", "REFUSED_PRE_WRITE", "proposal basis state_ref invalid")
    # Proposal retained State equality: current State path/sha must equal proposal basis.
    # State file path is state_rel; sha is expected_old sha.
    if basis_state_ref.get("path") != state_rel or basis_state_ref.get("sha256") != core.sha256_bytes(expected_old):
        raise _fail("BEFORE_STATE_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "proposal basis state_ref != current State (before-State changed; no reuse)")
    # Predecision eligibility (same predecessor/current contract/tool scope + valid active-before Candidate + predecision).
    # Lifecycle + gates + exception + contract/tool scope.
    if state.get("lifecycle_state") != "VALIDATED_DRAFT":
        raise _fail("PREDECISION", "ACTIVATE", "REFUSED_PRE_WRITE", "activation requires VALIDATED_DRAFT")
    hg = state.get("human_gates") or {}
    hgp = state.get("human_gate_provenance") or {}
    mc = state.get("machine_checkpoints") or {}
    eg = state.get("exception_gate") or {}
    if hg.get("architecture_review") != "approved":
        raise _fail("PREDECISION", "ACTIVATE", "REFUSED_PRE_WRITE", "activation requires approved Architecture Review")
    if hg.get("publication_preview") != "pending" or hgp.get("publication_preview") is not None:
        raise _fail("PREDECISION", "ACTIVATE", "REFUSED_PRE_WRITE", "activation forbids decided Publication Preview")
    for gate_name in ("publication_preview", "freeze", "release"):
        if mc.get(gate_name) != "pending":
            raise _fail("PREDECISION", "ACTIVATE", "REFUSED_PRE_WRITE", f"activation forbids resolved {gate_name}")
    if eg.get("status") != "inactive":
        raise _fail("PREDECISION", "ACTIVATE", "REFUSED_PRE_WRITE", "activation forbids active Exception Gate")
    # Same predecessor/current contract/tool scope: current contract must equal receipt contract?
    # Receipt already verified current contract; here verify State contract matches seal receipt contract?
    # Seal receipt contract is in receipt current_tools.contract; State contract is state contract?
    # For H2, verify State contract == cfg-derived contract (strict State already did via agent).
    # Active-before Candidate: healthy old Candidate (if present) must validate and bind active-before.
    try:
        selection_before = setmod.resolve_publication_selection(repo, cfg, state)
    except Exception as exc:
        raise _fail("SELECTION_BEFORE", "ACTIVATE", "REFUSED_PRE_WRITE", f"before selection failed: {exc}") from exc
    # Derive before_active7 + before_candidate_ref for digest + record.
    effective7_before = selection_before.get("effective7") or {}
    # before_candidate_ref: exact observed Candidate ref/null at activation entry.
    before_candidate_ref: dict[str, str] | None = None
    if selection_before.get("mode") == "VERSIONED_ACTIVE":
        cand = selection_before.get("candidate_ref")
        if not isinstance(cand, dict) or set(cand) != {"path", "sha256"}:
            raise _fail("BEFORE_CANDIDATE", "ACTIVATE", "REFUSED_PRE_WRITE", "before candidate ref invalid in VERSIONED_ACTIVE")
        before_candidate_ref = {"path": cand["path"], "sha256": cand["sha256"]}
        # Healthy old Candidate must validate (strict) – selection already validated seal→candidate, but re-validate file.
        try:
            from scripts import survey_publication_v2 as _pub2
            _pub2.validate_candidate(repo, _safe(repo, before_candidate_ref["path"], "before candidate"), issue_id=state.get("issue_id"))
        except Exception as exc:
            raise _fail("BEFORE_CANDIDATE", "ACTIVATE", "REFUSED_PRE_WRITE", f"before Candidate invalid: {exc}") from exc
    else:
        # CANONICAL: check default candidate path file existence (healthy old Candidate if present).
        default_cand_path = selection_before.get("candidate_path")
        # candidate_path is Path (absolute) from L; derive repo-relative for check.
        try:
            if isinstance(default_cand_path, Path):
                try:
                    rel_cand = str(default_cand_path.resolve().relative_to(repo))
                except ValueError:
                    rel_cand = None
                if rel_cand is not None:
                    try:
                        cst = os.lstat(repo / rel_cand)
                        if not stat.S_ISLNK(cst.st_mode) and stat.S_ISREG(cst.st_mode):
                            # File exists: must validate as healthy old Candidate (error, not absence, if invalid).
                            try:
                                from scripts import survey_publication_v2 as _pub3
                                _pub3.validate_candidate(repo, _safe(repo, rel_cand, "before canonical candidate"), issue_id=state.get("issue_id"))
                            except Exception as exc:
                                raise _fail("BEFORE_CANDIDATE", "ACTIVATE", "REFUSED_PRE_WRITE", f"old canonical Candidate invalid (error, not absence): {exc}") from exc
                            before_candidate_ref = {"path": rel_cand, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, rel_cand, "before canonical candidate"))}
                        else:
                            before_candidate_ref = None
                    except FileNotFoundError:
                        before_candidate_ref = None
                    except EditorialError:
                        raise
                    except OSError:
                        before_candidate_ref = None
                else:
                    before_candidate_ref = None
            else:
                before_candidate_ref = None
        except EditorialError:
            raise
        except Exception:
            before_candidate_ref = None
    # Digest from before-effective7 + candidate (recomputed, not caller acceptance).
    # Seven exact fields enforced by H before calling L (L now also enforces; defense in depth).
    # effective7 must be exactly PUBLICATION_ROLES_7 (7 publication roles, no research/Architecture/Draft).
    try:
        from scripts import survey_publication_set_v2 as _setmod7
        seven_expected = set(_setmod7.PUBLICATION_ROLES_7)
    except ImportError as exc:
        raise _fail("LOWLEVEL_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", f"L seven roles missing: {exc}") from exc
    if not isinstance(effective7_before, dict) or set(effective7_before.keys()) != seven_expected:
        raise _fail("EFFECTIVE7_SHAPE", "ACTIVATE", "REFUSED_PRE_WRITE", f"before effective7 must be exactly 7 {sorted(seven_expected)}")
    eff_for_digest: dict[str, Any] = {}
    for k, v in effective7_before.items():
        if not isinstance(v, dict) or set(v.keys()) < {"path", "sha256"}:
            raise _fail("EFFECTIVE7_ROW", "ACTIVATE", "REFUSED_PRE_WRITE", f"before effective7 row {k} must contain path/sha256")
        eff_for_digest[k] = {"path": v["path"], "sha256": v["sha256"]}
    try:
        before_digest = setmod.before_active_digest(eff_for_digest, before_candidate_ref)
    except Exception as exc:
        raise _fail("DIGEST_COMPUTE", "ACTIVATE", "REFUSED_PRE_WRITE", f"before digest failed: {exc}") from exc
    # Original checkpoint / supersedes / latest legacy anchor (cumulative, not incremental).
    supersedes = state.get("publication_revalidation_provenance")
    if supersedes is not None and (not isinstance(supersedes, dict) or set(supersedes) != {"path", "sha256"}):
        raise _fail("SUPERSEDES_SHAPE", "ACTIVATE", "REFUSED_PRE_WRITE", "State pointer must be exact {path,sha256} or null")
    # Build anchor chain (oldest->newest) for derive_canonical_anchor.
    try:
        chain = _build_anchor_chain(repo, cfg, state, supersedes)
        anchor = setmod.derive_canonical_anchor(repo, cfg, state, chain)
    except EditorialError:
        raise
    except Exception as exc:
        raise _fail("ANCHOR_DERIVE", "ACTIVATE", "REFUSED_PRE_WRITE", f"anchor derive failed: {exc}") from exc
    # Chain limit: current len + new <=32 prewrite (contract §4.3 bounded depth32).
    if len(chain) + 1 > 32:
        raise _fail("CHAIN_DEPTH", "ACTIVATE", "REFUSED_PRE_WRITE", f"chain too deep: current {len(chain)} + new >32")
    # Canonical record seq + path (existing sequence naming under canonical publication/v2).
    try:
        record_path_abs, next_seq = _next_record_seq(repo, cfg, state)
    except EditorialError:
        raise
    try:
        record_rel = str(record_path_abs.resolve().relative_to(repo))
    except ValueError as exc:
        raise _fail("RECORD_PATH", "ACTIVATE", "REFUSED_PRE_WRITE", f"record path escapes repo: {exc}") from exc
    # Ordinary activate refuses collision when record exists but State still exact old (resume path).
    try:
        os.lstat(record_path_abs)
        raise _fail("RECORD_COLLISION", "ACTIVATE", "REFUSED_PRE_WRITE", f"record already exists (ordinary activate refuses; use resume): {record_rel}")
    except FileNotFoundError:
        pass
    except EditorialError:
        raise
    except OSError as exc:
        raise _fail("RECORD_CHECK", "ACTIVATE", "REFUSED_PRE_WRITE", f"record check failed: {exc}") from exc
    # Construct activation record (exact branch2 keys, no fake legacy rows, no second active table).
    prior_checkpoint = (state.get("checkpoint_provenance") or {}).get("validation")
    if not isinstance(prior_checkpoint, dict) or set(prior_checkpoint) != {"path", "sha256"}:
        raise _fail("PRIOR_CHECKPOINT", "ACTIVATE", "REFUSED_PRE_WRITE", "State lacks exact validation checkpoint")
    try:
        impl_sha = core.repository_commit_sha(repo)
    except ValueError as exc:
        raise _fail("IMPL_SHA", "ACTIVATE", "REFUSED_PRE_WRITE", f"implementation commit missing: {exc}") from exc
    try:
        contract_now = core.contract_identity(repo, cfg, state.get("research_profile"), state.get("publication_profile"))
    except (ValueError, KeyError) as exc:
        raise _fail("CONTRACT_NOW", "ACTIVATE", "REFUSED_PRE_WRITE", f"contract identity failed: {exc}") from exc
    establishment = {
        "state_sha256": core.sha256_bytes(expected_old),
        "lifecycle": "VALIDATED_DRAFT",
        "architecture_review": "approved",
        "publication_preview": "pending",
        "freeze": "pending",
        "release": "pending",
        "implementation_commit_sha": impl_sha,
        "recorded_at": core.iso_utc(ts),
    }
    record_base: dict[str, Any] = {
        "schema_version": "2.0-rc1",
        "kind": "EDITORIAL_PUBLICATION_ACTIVATION_V1",
        "issue_id": sealed.get("issue_id"),
        "reason_class": "REVIEWED_EDITORIAL_CORRECTION",
        "reason": reason.strip(),
        "lifecycle": "VALIDATED_DRAFT",
        "prior_checkpoint": {"path": prior_checkpoint["path"], "sha256": prior_checkpoint["sha256"]},
        "supersedes": {"path": supersedes["path"], "sha256": supersedes["sha256"]} if isinstance(supersedes, dict) else None,
        "canonical_anchor": anchor,
        "before_state_ref": {"path": basis_state_ref["path"], "sha256": basis_state_ref["sha256"]},
        "before_active_digest": before_digest,
        "before_candidate_ref": before_candidate_ref,
        "set_ref": {"path": set_rel, "sha256": core.sha256_bytes(_read_bytes_bounded(repo, set_rel, "publication set"))},
        "core": {"contract": contract_now, "implementation_commit_sha": impl_sha},
        "executor": executor.strip(),
        "recorded_at": core.iso_utc(ts),
        "establishment": establishment,
    }
    # Validate record shape via L-owned revalidation schema (strict, no fallback).
    try:
        schema_gate.validate_instance(record_base, repo / Path("schemas/publication-surface-revalidation.schema.json"), label="activation record")
    except ValueError as exc:
        raise _fail("RECORD_SCHEMA", "ACTIVATE", "REFUSED_PRE_WRITE", f"activation record schema invalid: {exc}") from exc
    # Explicit retainedCOPY pin BEFORE ANY record write (read-only, no fictitious writes).
    # Consistency: proposal basis == record.beforeState == retained State bytes + predecessor/beforeCandidate/before7.
    # Uses actual P2R retained manifest (via staged retention_manifest_ref), not caller trust.
    try:
        staged_for_retained = _ja.loads(_read_bytes_bounded(repo, staged_rel, "staged manifest").decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STAGED_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"staged unreadable for retained pin: {exc}") from exc
    retention_ref_pin = staged_for_retained.get("retention_manifest_ref")
    if not isinstance(retention_ref_pin, dict) or set(retention_ref_pin) != {"path", "sha256"}:
        raise _fail("RETENTION_REF", "ACTIVATE", "REFUSED_PRE_WRITE", "staged retention_manifest_ref invalid for retained pin")
    retention_rel_pin = _lexical_rel(repo, retention_ref_pin["path"], "retention manifest")
    _safe(repo, retention_rel_pin, "retention manifest")
    try:
        retention_bytes = _read_bytes_bounded(repo, retention_rel_pin, "retention manifest")
        retention_obj = _ja.loads(retention_bytes.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("RETENTION_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE", f"retention unreadable: {exc}") from exc
    if core.sha256_bytes(retention_bytes) != retention_ref_pin.get("sha256"):
        raise _fail("RETENTION_DRIFT", "ACTIVATE", "REFUSED_PRE_WRITE", "retention manifest drift vs staged ref")
    # Find state row for before_state path.
    before_path = record_base["before_state_ref"]["path"]
    before_sha = record_base["before_state_ref"]["sha256"]
    if before_path != basis_state_ref.get("path") or before_sha != basis_state_ref.get("sha256"):
        raise _fail("BEFORE_STATE_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "record before_state != proposal basis (explicit)")
    rows_pin = retention_obj.get("rows") if isinstance(retention_obj, dict) else None
    if not isinstance(rows_pin, list):
        raise _fail("RETENTION_ROWS", "ACTIVATE", "REFUSED_PRE_WRITE", "retention rows invalid")
    state_row = None
    for r in rows_pin:
        if isinstance(r, dict) and r.get("path") == before_path:
            state_row = r
            break
    if state_row is None:
        raise _fail("RETAINED_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", "retention missing before-State row (retained COPY required)")
    if state_row.get("sha256") != before_sha:
        raise _fail("RETAINED_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "retention before-State sha != record before_state")
    pol = state_row.get("policy")
    if pol == "COPY_BEFORE_REPLACEMENT":
        for k in ("retained_dest", "retained_sha256", "retained_byte_count"):
            if k not in state_row:
                raise _fail("RETAINED_COPY", "ACTIVATE", "REFUSED_PRE_WRITE", f"retention COPY missing {k}")
        retained_dest = state_row["retained_dest"]
        retained_sha = state_row["retained_sha256"]
        retained_size = state_row["retained_byte_count"]
        _safe(repo, _lexical_rel(repo, retained_dest, "retained State COPY"), "retained State COPY")
        try:
            retained_bytes = _read_bytes_bounded(repo, retained_dest, "retained State COPY")
        except EditorialError:
            raise
        if core.sha256_bytes(retained_bytes) != retained_sha or len(retained_bytes) != retained_size:
            raise _fail("RETAINED_COPY_DRIFT", "ACTIVATE", "REFUSED_PRE_WRITE", "retained COPY bytes drift")
        if retained_sha != before_sha:
            raise _fail("RETAINED_COPY_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "retained COPY != before_state bytes (explicit)")
    elif pol == "KEEP_IMMUTABLE":
        retained_ref = state_row.get("retained_ref")
        if not isinstance(retained_ref, dict) or set(retained_ref) != {"path", "sha256"}:
            raise _fail("RETAINED_KEEP", "ACTIVATE", "REFUSED_PRE_WRITE", "retention KEEP retained_ref invalid")
        _safe(repo, _lexical_rel(repo, retained_ref["path"], "retained KEEP"), "retained KEEP")
        try:
            keep_bytes = _read_bytes_bounded(repo, retained_ref["path"], "retained KEEP")
        except EditorialError:
            raise
        if core.sha256_bytes(keep_bytes) != retained_ref.get("sha256") or retained_ref.get("sha256") != before_sha:
            raise _fail("RETAINED_KEEP_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "retention KEEP != before_state bytes")
    else:
        raise _fail("RETAINED_POLICY", "ACTIVATE", "REFUSED_PRE_WRITE", f"retention State row policy invalid: {pol!r}")
    # Predecessor/beforeCandidate/before7 explicit consistency (in addition to L post-validation).
    if record_base["supersedes"] != supersedes:
        raise _fail("SUPERSEDES_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "record supersedes != State pointer (explicit predecessor)")
    if record_base["before_candidate_ref"] != before_candidate_ref:
        raise _fail("CANDIDATE_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "record before_candidate != observed (explicit)")
    if record_base["before_active_digest"] != before_digest:
        raise _fail("DIGEST_MISMATCH", "ACTIVATE", "REFUSED_PRE_WRITE", "record digest != recomputed (explicit)")
    # Fresh P2V immediately before first record write (genuine current-before, not cached).
    _require_scope_bound(repo, state_rel, proposal_rel, staged_rel)
    # Re-check State still exact old immediately before record write (no drift during construction).
    try:
        cur_old = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError:
        raise
    if cur_old != expected_old:
        raise _fail("STATE_DRIFT", "ACTIVATE", "REFUSED_PRE_WRITE", "State drift before record write; preserved")
    record_bytes = core.json_bytes(record_base)
    # Only write: new exclusive activation record (H owns via existing agent writer, L readonly).
    try:
        from scripts import survey_agent_control_v2 as _agent
    except ImportError as exc:
        raise _fail("AGENT_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", f"agent writers missing: {exc}") from exc
    if not hasattr(_agent, "_exclusive_create_record_bytes") or not hasattr(_agent, "_atomic_replace_state_bytes"):
        raise _fail("AGENT_MISSING", "ACTIVATE", "REFUSED_PRE_WRITE", "agent _exclusive_create_record_bytes/_atomic_replace_state_bytes missing; need concrete helpers to root")
    primary_error: str | None = None
    record_owned_id: tuple[int, int] | None = None
    try:
        record_owned_id = _agent._exclusive_create_record_bytes(record_path_abs, record_bytes, "activation record")
    except Exception as exc:
        # Collision (record exists but State still old) → explicit resume, not silent takeover.
        raise _fail("RECORD_COLLISION", "ACTIVATE", "REFUSED_PRE_WRITE", f"record create failed (use resume if orphan); preserved: {exc}") from exc
    # Fresh P2V immediately before State replace (second prewrite boundary).
    try:
        _require_scope_bound(repo, state_rel, proposal_rel, staged_rel)
    except EditorialError as exc:
        primary_error = f"primary P2V recheck before State replace failed: {exc}"
        # Record is inert (State still old); report primary + secondary, observed old, no delete.
        raise _fail("PREPLACE_P2V", "ACTIVATE", "EXPLICIT_RECOVERY", f"{primary_error}; record inert at {record_rel}; observed old; explicit resume required") from exc
    # Re-check State still exact old immediately before State replace (detected interleave).
    try:
        cur_old2 = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError as exc:
        raise _fail("STATE_READ", "ACTIVATE", "EXPLICIT_RECOVERY", f"State reread failed; record inert at {record_rel}; observed unknown; {exc}") from exc
    if cur_old2 != expected_old:
        raise _fail("STATE_DRIFT", "ACTIVATE", "EXPLICIT_RECOVERY", f"State drift before replace; record inert at {record_rel}; observed unknown; preserved")
    # Expected State new pointer only (ONLY publication_revalidation_provenance mutation).
    try:
        new_state_obj = _ja.loads(expected_old.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STATE_DECODE", "ACTIVATE", "EXPLICIT_RECOVERY", f"State decode failed; record inert at {record_rel}: {exc}") from exc
    new_record_ref = {"path": record_rel, "sha256": core.sha256_bytes(record_bytes)}
    new_state_obj["publication_revalidation_provenance"] = dict(new_record_ref)
    new_bytes = core.json_bytes(new_state_obj)
    # Guarded State temp+replace via existing agent writer (known-byte replace, no truncating write_json).
    try:
        _agent._atomic_replace_state_bytes(_safe(repo, state_rel, "Production State"), expected_old, new_bytes, "activation State")
    except Exception as exc:
        # Close/postreplace failure: report primary + secondary + observed old/new/unknown, never delete record.
        # Observed: State still old (replace refused) → old; record inert.
        raise _fail("STATE_REPLACE", "ACTIVATE", "EXPLICIT_RECOVERY", f"State replace failed; record inert at {record_rel}; observed old; preserved; manual resume required: {exc}") from exc
    # Post-replace validation: strict active State + full set + record, before success.
    # Classify observed old/new/unknown via immediate readback.
    try:
        post_bytes = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError as exc:
        raise _fail("POSTREAD_FAIL", "ACTIVATE", "EXPLICIT_RECOVERY", f"post-replace read failed; observed unknown; record at {record_rel} preserved; {exc}") from exc
    observed = "unknown"
    if post_bytes == new_bytes:
        observed = "new"
    elif post_bytes == expected_old:
        observed = "old"
    secondary_errors: list[str] = []
    # Strict active State must select new set (VERSIONED_ACTIVE) and be healthy.
    try:
        post_state = _ja.loads(post_bytes.decode("utf-8"))
        post_sel = setmod.resolve_publication_selection(repo, cfg, post_state)
        if post_sel.get("mode") != "VERSIONED_ACTIVE":
            secondary_errors.append("post State not VERSIONED_ACTIVE")
        if (post_sel.get("set_ref") or {}).get("path") != set_rel or (post_sel.get("set_ref") or {}).get("sha256") != core.sha256_bytes(_read_bytes_bounded(repo, set_rel, "publication set")):
            secondary_errors.append("post State set_ref != input seal")
    except Exception as exc:
        secondary_errors.append(f"post State selection failed: {exc}")
    try:
        setmod.validate_activation_record(repo, repo / record_rel)
    except Exception as exc:
        secondary_errors.append(f"post record invalid: {exc}")
    try:
        validate_prepared_set(repo, state_rel, set_rel)
    except Exception as exc:
        secondary_errors.append(f"post set invalid: {exc}")
    # New State must validate selected set + normal stage/Preview path before success (strict agent State).
    try:
        from scripts import survey_agent_control_v2 as _agent3
        post_errs = _agent3.validate_agent_state(repo, cfg, _ja.loads(post_bytes.decode("utf-8")))
        if post_errs:
            secondary_errors.append("post State agent invalid: " + "; ".join(post_errs))
    except Exception as exc:
        secondary_errors.append(f"post State agent check failed: {exc}")
    if secondary_errors:
        raise _fail("POSTREPLACE_FAIL", "ACTIVATE", "EXPLICIT_RECOVERY", f"primary activation wrote record+State but postreplace failed; observed {observed}; record at {record_rel} preserved (never delete); secondary: {'; '.join(secondary_errors)}")
    # Old canonical readers are no longer permitted as active consumers; new State validates selected set + Preview path.
    return {"status": "ACTIVATED", "record_path": record_rel, "state_path": state_rel, "observed": observed}


def resume_activation(root: str | Path, state_path: str | Path, record_path: str | Path) -> dict[str, Any]:
    """Explicit orphan resume: H owns install via existing agent writers (no fictional L resume).

    Revalidates full current-before/set/record intent. Read-only ALREADY_ACTIVE does
    full strict State + full set (no takeover). Orphan (record exists, State still old)
    revalidates current-before + record bytes, then installs exact record via guarded
    State replace. INDETERMINATE preserves all bytes (no overwrite/rollback/adoption).
    """
    repo = Path(root).resolve()
    try:
        from scripts import survey_publication_set_v2 as setmod
    except ImportError as exc:
        raise _fail("LOWLEVEL_MISSING", "RESUME", "REFUSED_PRE_WRITE", f"L module missing: {exc}") from exc
    for name in ("validate_activation_record", "resolve_publication_selection", "derive_canonical_anchor", "before_active_digest"):
        if not hasattr(setmod, name):
            raise _fail("LOWLEVEL_MISSING", "RESUME", "REFUSED_PRE_WRITE", f"L {name} missing; need concrete helper to root")
    record_rel = _lexical_rel(repo, str(record_path), "activation record")
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    _safe(repo, record_rel, "activation record")
    _safe(repo, state_rel, "Production State")
    try:
        expected_old = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError:
        raise
    import json as _jr
    try:
        state = _jr.loads(expected_old.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STATE_UNREADABLE", "RESUME", "REFUSED_PRE_WRITE", f"State not JSON: {exc}") from exc
    try:
        cfg = core.load_json(_safe(repo, core.DEFAULT_CONFIG.as_posix(), "implementation config"))
    except (OSError, ValueError) as exc:
        raise _fail("CONFIG_UNREADABLE", "RESUME", "REFUSED_PRE_WRITE", f"config unreadable: {exc}") from exc
    # Validate record (historical proof: seal, proposal/retention, digest, anchor).
    try:
        record = setmod.validate_activation_record(repo, repo / record_rel)
    except Exception as exc:
        raise _fail("RECORD_INVALID", "RESUME", "REFUSED_PRE_WRITE", f"activation record invalid: {exc}") from exc
    set_ref = record.get("set_ref") or {}
    if not isinstance(set_ref, dict) or "path" not in set_ref:
        raise _fail("RECORD_SET", "RESUME", "REFUSED_PRE_WRITE", "record set_ref invalid")
    # Selection for current State (before install).
    try:
        selection = setmod.resolve_publication_selection(repo, cfg, state)
    except Exception as exc:
        raise _fail("SELECTION_BEFORE", "RESUME", "REFUSED_PRE_WRITE", f"before selection failed: {exc}") from exc
    # State already exact new pointer → strict validation + read-only ALREADY_ACTIVE.
    # New pointer means State publication_revalidation_provenance == record path/sha.
    state_pointer = state.get("publication_revalidation_provenance")
    try:
        record_sha_now = core.sha256_bytes(_read_bytes_bounded(repo, record_rel, "activation record"))
    except EditorialError:
        raise
    if isinstance(state_pointer, dict) and state_pointer.get("path") == record_rel and state_pointer.get("sha256") == record_sha_now:
        # Full strict State + full set read-only (no takeover, no fresh approval).
        try:
            from scripts import survey_agent_control_v2 as _ag
            errs = _ag.validate_agent_state(repo, cfg, state)
        except Exception as exc:
            raise _fail("ALREADY_ACTIVE_STATE", "RESUME", "REFUSED_PRE_WRITE", f"ALREADY_ACTIVE State invalid: {exc}") from exc
        if errs:
            raise _fail("ALREADY_ACTIVE_STATE", "RESUME", "REFUSED_PRE_WRITE", "ALREADY_ACTIVE State invalid: " + "; ".join(errs))
        validated = validate_prepared_set(repo, state_rel, set_ref["path"])
        _ = validated
        return {"status": "ALREADY_ACTIVE", "record_path": record_rel, "state_path": state_rel, "observed": "new"}
    # Orphan: record exists but State still exact old (State pointer == record supersedes).
    supersedes = record.get("supersedes")
    if supersedes != state_pointer and not (supersedes is None and state_pointer is None):
        # State neither known old nor expected new → INDETERMINATE (preserve, no overwrite).
        raise _fail("INDETERMINATE", "RESUME", "INDETERMINATE", f"State pointer != record supersedes and != record itself; preserved; observed unknown; State pointer={state_pointer!r} record={record_rel}")
    # Explicit resume revalidates full current-before/set/record intent (genuine P2V fresh).
    set_rel_resume = set_ref["path"]
    _safe(repo, set_rel_resume, "publication set")
    validated_set = validate_prepared_set(repo, state_rel, set_rel_resume)
    _ = validated_set
    # Current-before must still equal record before_state_ref (proposal retained State equality).
    before_state_ref = record.get("before_state_ref")
    if not isinstance(before_state_ref, dict) or before_state_ref.get("path") != state_rel or before_state_ref.get("sha256") != core.sha256_bytes(expected_old):
        raise _fail("BEFORE_STATE_MISMATCH", "RESUME", "REFUSED_PRE_WRITE", "current State != record before_state_ref (before-State changed; no resume)")
    # P2V fresh at resume prewrite boundary (genuine, not cached).
    proposal_rel_r = validated_set["proposal_ref"]["path"]
    staged_rel_r = validated_set["staged_manifest_ref"]["path"]
    _require_scope_bound(repo, state_rel, proposal_rel_r, staged_rel_r)
    # Re-check State still exact old immediately before install.
    try:
        cur_old = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError:
        raise
    if cur_old != expected_old:
        raise _fail("STATE_DRIFT", "RESUME", "EXPLICIT_RECOVERY", "State drift before resume install; preserved")
    # Install exact record via guarded State replace (H owns via existing agent writer, L readonly).
    try:
        new_state_obj = _jr.loads(expected_old.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as exc:
        raise _fail("STATE_DECODE", "RESUME", "EXPLICIT_RECOVERY", f"State decode failed: {exc}") from exc
    new_state_obj["publication_revalidation_provenance"] = {"path": record_rel, "sha256": record_sha_now}
    new_bytes = core.json_bytes(new_state_obj)
    try:
        from scripts import survey_agent_control_v2 as _agent_r
    except ImportError as exc:
        raise _fail("AGENT_MISSING", "RESUME", "REFUSED_PRE_WRITE", f"agent writers missing: {exc}") from exc
    if not hasattr(_agent_r, "_atomic_replace_state_bytes"):
        raise _fail("AGENT_MISSING", "RESUME", "REFUSED_PRE_WRITE", "agent _atomic_replace_state_bytes missing; need concrete helper to root")
    try:
        _agent_r._atomic_replace_state_bytes(_safe(repo, state_rel, "Production State"), expected_old, new_bytes, "resume State")
    except Exception as exc:
        raise _fail("STATE_REPLACE", "RESUME", "EXPLICIT_RECOVERY", f"resume State replace failed; record preserved at {record_rel}; observed old: {exc}") from exc
    # Post-install: strict active State + full set + record (primary + secondary, observed new/old/unknown).
    try:
        post_bytes = _read_bytes_bounded(repo, state_rel, "Production State")
    except EditorialError as exc:
        raise _fail("POSTREAD_FAIL", "RESUME", "EXPLICIT_RECOVERY", f"post-resume read failed; observed unknown; record preserved: {exc}") from exc
    observed = "new" if post_bytes == new_bytes else ("old" if post_bytes == expected_old else "unknown")
    secondary: list[str] = []
    try:
        post_state = _jr.loads(post_bytes.decode("utf-8"))
        post_sel = setmod.resolve_publication_selection(repo, cfg, post_state)
        if post_sel.get("mode") != "VERSIONED_ACTIVE":
            secondary.append("post State not VERSIONED_ACTIVE")
    except Exception as exc:
        secondary.append(f"post selection failed: {exc}")
    try:
        setmod.validate_activation_record(repo, repo / record_rel)
    except Exception as exc:
        secondary.append(f"post record invalid: {exc}")
    try:
        validate_prepared_set(repo, state_rel, set_rel_resume)
    except Exception as exc:
        secondary.append(f"post set invalid: {exc}")
    if secondary:
        raise _fail("POSTREPLACE_FAIL", "RESUME", "EXPLICIT_RECOVERY", f"resume wrote State but post validation failed; observed {observed}; record preserved; secondary: {'; '.join(secondary)}")
    return {"status": "RESUMED", "record_path": record_rel, "state_path": state_rel, "observed": observed}


def verify_activation_history(root: str | Path, record_path: str | Path) -> dict[str, Any]:
    """Historical result: inert/historical/current-active distinct (no current eligibility claim).

    Uses actual L validators (validate_seal/validate_activation_record/derive) + strict
    file pins. No fictional verify_activation_history. Returns historical classification:
    INERT (seal valid but no State pointer), HISTORICAL (record valid but not active),
    CURRENT_ACTIVE (record valid and State points to it + full set valid). No permission token.
    """
    repo = Path(root).resolve()
    try:
        from scripts import survey_publication_set_v2 as setmod
    except ImportError as exc:
        raise _fail("LOWLEVEL_MISSING", "HISTORY", "REFUSED_PRE_WRITE", f"L module missing: {exc}") from exc
    for name in ("validate_seal", "validate_activation_record"):
        if not hasattr(setmod, name):
            raise _fail("LOWLEVEL_MISSING", "HISTORY", "REFUSED_PRE_WRITE", f"L {name} missing; need concrete helper to root")
    record_rel = _lexical_rel(repo, str(record_path), "activation record")
    _safe(repo, record_rel, "activation record")
    try:
        record = setmod.validate_activation_record(repo, repo / record_rel)
    except Exception as exc:
        raise _fail("RECORD_INVALID", "HISTORY", "REFUSED_PRE_WRITE", f"activation record invalid: {exc}") from exc
    set_ref = record.get("set_ref") or {}
    # Seal must validate (inert validity, no State pointer needed).
    try:
        seal = setmod.validate_seal(repo, repo / set_ref["path"])
    except Exception as exc:
        raise _fail("SEAL_INVALID", "HISTORY", "REFUSED_PRE_WRITE", f"historical seal invalid: {exc}") from exc
    # Try to load current State (if readable) to classify historical vs current-active.
    # State path is not passed to history API (record only); derive via seal proposal? No.
    # Instead, classify via record file + seal only: historical validity (no current eligibility claim).
    # To distinguish current-active, caller must use resolve_publication_selection with State;
    # here we return historical result + note that current-active requires State pointer check.
    # For H2, attempt best-effort State discovery via proposal? No guessing: return historical.
    return {
        "status": "HISTORICAL_VALID",
        "record_path": record_rel,
        "record_sha256": core.sha256_bytes(_read_bytes_bounded(repo, record_rel, "activation record")),
        "set_ref": {"path": set_ref["path"], "sha256": set_ref["sha256"]},
        "set_sha256": seal.get("set_sha256"),
        "issue_id": record.get("issue_id"),
        "note": "historical validity only; current-active requires State pointer via resolve_publication_selection (no eligibility claim here)",
    }


def resolve_publication_selection(root: str | Path, cfg: dict[str, Any], state: dict[str, Any]) -> dict[str, Any]:
    """Re-export L selection (H never reimplements identity)."""
    try:
        from scripts import survey_publication_set_v2 as setmod
    except ImportError as exc:
        raise _fail("LOWLEVEL_MISSING", "RESOLVE", "REFUSED_PRE_WRITE", f"L module missing: {exc}") from exc
    return setmod.resolve_publication_selection(Path(root).resolve(), cfg, state)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--config", default=str(core.DEFAULT_CONFIG))
    sub = parser.add_subparsers(dest="command", required=True)

    prep = sub.add_parser("prepare-publication")
    prep.add_argument("--state", required=True)
    prep.add_argument("--proposal", required=True)
    prep.add_argument("--staged-manifest", required=True)
    prep.add_argument("--manuscript-spec", required=True)
    prep.add_argument("--toolchain-spec", required=True)
    prep.add_argument("--recorded-at")

    fin = sub.add_parser("finalize-publication")
    fin.add_argument("--state", required=True)
    fin.add_argument("--proposal", required=True)
    fin.add_argument("--staged-manifest", required=True)
    fin.add_argument("--deterministic-checks", required=True)
    fin.add_argument("--semantic-review", required=True)
    fin.add_argument("--visual-review", required=True)
    fin.add_argument("--recorded-at")

    vr = sub.add_parser("validate-editorial-receipt")
    vr.add_argument("--receipt", required=True)
    vr.add_argument("--state", required=True)

    vs = sub.add_parser("validate-prepared-set")
    vs.add_argument("--state", required=True)
    vs.add_argument("--set", required=True)

    act = sub.add_parser("activate-publication")
    act.add_argument("--state", required=True)
    act.add_argument("--set", required=True)
    act.add_argument("--reason", required=True)
    act.add_argument("--executor", required=True)
    act.add_argument("--recorded-at")

    res = sub.add_parser("resume-activation")
    res.add_argument("--state", required=True)
    res.add_argument("--record", required=True)

    hist = sub.add_parser("verify-activation-history")
    hist.add_argument("--record", required=True)

    args = parser.parse_args()
    root = Path(args.repo_root).resolve()
    try:
        cfg_path = root / args.config if not Path(args.config).is_absolute() else Path(args.config)
        _ = core.load_json(cfg_path)
        if args.command == "prepare-publication":
            out = prepare_publication(root, args.state, args.proposal, args.staged_manifest, args.manuscript_spec, args.toolchain_spec, core.parse_instant(args.recorded_at) if args.recorded_at else None)
            print(json.dumps(out, indent=2))
            return 0
        if args.command == "finalize-publication":
            out = finalize_publication(root, args.state, args.proposal, args.staged_manifest, args.deterministic_checks, args.semantic_review, args.visual_review, core.parse_instant(args.recorded_at) if args.recorded_at else None)
            print(json.dumps(out, indent=2))
            return 0
        if args.command == "validate-editorial-receipt":
            out = validate_editorial_receipt(root, args.receipt, args.state)
            print(json.dumps({"receipt_sha256": out["receipt_sha256"], "issue_id": out["issue_id"]}, indent=2))
            return 0
        if args.command == "validate-prepared-set":
            out = validate_prepared_set(root, args.state, args.set)
            print(json.dumps({"set_sha256": out["set_sha256"], "issue_id": out["issue_id"]}, indent=2))
            return 0
        if args.command == "activate-publication":
            out = activate_publication(root, args.state, args.set, args.reason, args.executor, core.parse_instant(args.recorded_at) if args.recorded_at else None)
            print(json.dumps(out, indent=2))
            return 0
        if args.command == "resume-activation":
            out = resume_activation(root, args.state, args.record)
            print(json.dumps(out, indent=2))
            return 0
        if args.command == "verify-activation-history":
            out = verify_activation_history(root, args.record)
            print(json.dumps(out, indent=2, default=str))
            return 0
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(str(exc), file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
