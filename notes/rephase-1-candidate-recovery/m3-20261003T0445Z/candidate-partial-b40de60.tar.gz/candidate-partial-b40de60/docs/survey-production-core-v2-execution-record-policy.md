# Survey Production Core v2 — Edition Execution Record Policy

Status: `EDITION EXECUTION RECORD POLICY`  
Established: 2026-08-23 JST  
Updated: 2026-08-24 JST

## 1. Purpose

Every Weekly/Special production conversation must leave enough repository authority for another session to reconstruct what happened without chat history. Machine lifecycle/state artifacts remain authoritative for machine state; execution records provide concise operational provenance.

Human Gate machine history under `{source_root}/gates/` is exact authority. Markdown under `execution/` summarizes and points to it rather than becoming a second State machine.

## 2. Canonical execution tree

```text
{source_root}/execution/
  index.md
  sessions/<session-id>.md
  reviews/architecture-rN.md
  reviews/publication-rN.md
  defects/<defect-id>.md
```

When connector-safe operator execution is used:

```text
  requests/<request-id>.json
  bridge-runs/<request-id>/...
```

Machine Human-review authority:

```text
{source_root}/gates/reviews/architecture-rN.json
{source_root}/gates/reviews/publication-rN.json
{source_root}/gates/reviews/approvals/architecture-rN.json
{source_root}/gates/reviews/approvals/publication-rN.json
{source_root}/gates/review-index.json
```

The active canonical approval paths remain separate current authority and may later be superseded by dependency-aware revision; immutable rN snapshots preserve historical approval evidence.

## 3. Deterministic helper boundary

`scripts/survey_execution_record_v2.py` owns only structural execution-record initialization/validation.

`scripts/survey_human_gate_v2.py` owns deterministic machine review records for the two normal Human Gates. It may record an already explicit Human `APPROVED` or `REQUEST_CHANGES` decision and apply the Human-selected allowed lifecycle consequence. It must not choose the decision, requested changes, or regeneration boundary.

Before direct-local or bridge-backed Human Gate recording, canonical Core must prove that `reviewed_repository_commit_sha`:

- names a real Git commit;
- remains reachable from the Profile-bound canonical work branch;
- contains exact current reviewed Production State and every Gate-input byte;
- for Publication Preview, contains the exact Candidate-bound PDF.

A dangling commit, uncommitted working tree, missing reviewed path, or same-path/different-byte commit is insufficient provenance.

Connector-safe execution adds the transport proof that the reviewed commit is exactly the immutable request-only commit parent.

## 4. `index.md`

`index.md` is the first human-readable navigation file after `production-state.json`. Maintain run context and navigation, not a second live State summary.

Record:

- issue/Profile identity and canonical work branch/source root, with Profile/State paths;
- start-of-run reviewed baseline, start/requested stop and a pointer to the initial session objective, explicitly historical run context;
- stable paths to machine review index, active approval/checkpoint authority and publication records;
- pointers to each session's execution mode/transport record, and Grok/X task/result disposition when applicable;
- known edition-local deviations/shared-Core defects and their evidence pointers;
- session/review/defect/receipt pointers, including the session that records final disposition.

Read live lifecycle, next action, stop reason, State hash, Gate status and Candidate/PDF identity directly from the named Profile/State and its typed pointers. Resolve the machine review index path from the reviewed Core configuration relative to the Profile source root. It may not exist before the first decision; absence is not approval. Pending Human review targets remain in the required version-bound session/review presentation and State-bound stage artifacts, and are not inferred from an old approval. A machine review index names historical rN records; its newest approval is not automatically active approval. A snapshot display must identify the inspected bytes and separate stored facts, checked direct links and unverified dependencies. It must not infer Human decisions, select a regeneration boundary, or authorize execution.

Update the index when run context or navigation changes, or new handoff/defect information must be discoverable. Do not rewrite it merely because Gate/revision/Candidate/final State changed. Record actions, end state and decisions once in their existing session and machine records. Preserve older edition indexes as historical navigation; do not regenerate frozen/released editions to conform to this layout.

## 5. Session records

Create one concise session log per production conversation or material continuation.

Required sections:

- `Starting authority`
- `Actions actually performed`
- `External handoff`
- `Deterministic execution transport`
- `Deviations / failures`
- `End state`

Record meaningful stages and material decisions, not every tool call or private reasoning.

### Connector-safe deterministic execution provenance

When the bridge is used, retain:

- request id/path;
- request-only commit SHA;
- Profile work branch;
- operator queue Issue `#448` trigger reference/comment if useful;
- trusted default-branch operator workflow run;
- bridge receipt/result path;
- resulting State/lifecycle edge;
- Human Gate review record/index when applicable;
- bot output commit.

Keep these identities distinct:

```text
reviewed main baseline
Human-reviewed durable work-branch commit
request-only work-branch commit
Issue #448 trigger comment
trusted default-branch executor run
bot output commit
```

Issue #448 is transport only, not a Human Gate or editorial record.

## 6. Human Gate review Markdown

Every Human Gate review gets a short `execution/reviews/*-rN.md` even when detailed feedback lives in GitHub.

Required headings:

- `Reviewed authority`
- `Human decision`
- `Requested changes`
- `Regeneration boundary`
- `Shared-Core implication`

Point to the exact machine rN record/index; do not duplicate full Human feedback.

Decision vocabulary for normal gates is only:

- `APPROVED`
- `REQUEST_CHANGES`

A genuine Owner Exception is recorded separately.

## 7. Revision history and cross-gate reopening

Review revisions are contiguous independently per Gate.

After `REQUEST_CHANGES`, old canonical artifact paths may later hold regenerated bytes. Historical review identity remains exact through recorded SHA-256 values, durable reviewed repository commit, machine rN record, and immutable approval snapshot when the revision was approved.

Publication-local revision preserves valid active Architecture approval.

When Publication Preview explicitly returns to a boundary before `ARCHITECTURE_ESTABLISHED`, prior Architecture APPROVED evidence remains in its immutable rN record/snapshot while the active canonical Architecture approval is superseded and Architecture Review becomes pending for rN+1.

Current State/checkpoint/gate provenance determines current authority; old rN records remain historical evidence only.

## 8. Shared-Core defects

A production session observes but does not repair shared Core.

Record under `execution/defects/`:

- observation;
- reproduction boundary;
- impact;
- safe edition-local workaround, if any;
- Core-maintenance pointer;
- production disposition.

A formal production-validation run that exposes a shared-Core defect is failed evidence even if a local workaround exists.

## 9. Session bootstrap / close

At resume, read:

1. current reviewed main/bootstrap;
2. canonical Production State;
3. execution index;
4. machine Human-review index and its named records if applicable; active approval comes from State provenance, not latest-record selection;
5. referenced session/review/defect/bridge receipt needed to continue.

Before normal session close:

1. update session log;
2. update execution index if navigation changed;
3. ensure Gate/review/defect/transport pointers exist;
4. record exact end-state bytes/reference and next action/stop reason in the session log as historical provenance, without duplicating live values in the navigation index;
5. validate execution-record structure;
6. commit the record on the edition work branch.

This logging is internal production work and never requires routine approval.

## 10. Compatibility

Existing W33/SP001 pre-policy logs remain historical evidence and are not rewritten merely to match this layout. Clean post-integration validation creates canonical execution records after Profile/State initialization.
