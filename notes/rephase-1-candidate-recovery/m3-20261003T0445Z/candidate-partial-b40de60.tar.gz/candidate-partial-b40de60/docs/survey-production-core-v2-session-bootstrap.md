# Survey Production Core v2 — agent session bootstrap

Status: `CANONICAL POST-INTEGRATION AGENT-FIRST SESSION BOOTSTRAP / SOL-LUNA REVIEW GOVERNANCE INTEGRATED`
Applies to: Weekly, Retrospective Period, standalone Thematic, and guided Special series work  
Primary operator: **ChatGPT**

## 1. Minimal user contract

A user may start or resume production with only a target and desired stopping Human Gate, for example:

```text
2026-W35をArchitecture Reviewまで編纂してください
Generative AI Foundationsの次巻をArchitecture Reviewまで進めてください
2025-H2をPublication Previewまで進めてください
```

That is sufficient. ChatGPT reconstructs mechanics from current reviewed repository authority and continues without routine confirmation.

Normal pauses are limited to:

1. `ARCHITECTURE_REVIEW`;
2. exact-byte `PUBLICATION_PREVIEW`;
3. genuine Owner-level Exception Gate;
4. permitted Human-mediated Grok Drive task-file path handoff;
5. recorded blocking shared-Core defect.

Routine search refinement, Source Intake, Screening, Evidence, Selection, drafting, QA, layout repair, transient tool/CI retry, and normal `REQUEST_CHANGES` are not extra Human Gates. Mandatory internal Sol supervisory reviews are also not Human Gates; they are required quality controls and may cause autonomous research/gap-fill before the requested Gate is presented.

## 2. Session-start authority

Read current reviewed `main`, then at minimum:

1. `AGENTS.md`;
2. Core authority/redesign authority and any current narrow amendment;
3. this bootstrap;
4. `docs/survey-production-core-v2-sol-luna-review-governance.md`;
5. issue-prevention checklist;
6. X/Grok intake policy;
7. execution-record policy;
8. applicable Profile/period/thematic/series guide;
9. canonical Profile/State and typed checkpoint/active-approval pointers, the machine review index, and the execution navigation index if resuming.

The Sol/Luna governance document is mandatory for every Weekly/Special start or resume. Do not treat it as optional background reading.

Repository state outranks chat history. Read lifecycle/next action, active approvals and Candidate pointers from the named snapshot's machine records; do not maintain duplicate live values in the authority index or execution navigation index. Continue required version-bound session/review records and Human review presentations; repair a misleading handoff before using it. An execution index supplies run context and navigation, not current machine facts. Its historical session summaries remain tied to their recorded State/commit.

The authority index, redesign constraints, governance and applicable detailed policies above remain required. This change does not retire their substantive reading obligations or the independent reviews. A snapshot display is not a full State/contract/reviewed-commit validation or permission to execute.

## 3. Production/Core boundary

Production repairs the edition, not shared Core. Shared roots are read-only during edition production:

```text
AGENTS.md
config/
schemas/
scripts/
.github/workflows/
docs/survey-production-core-v2-*.md
```

A shared-Core defect is recorded under the edition execution tree and repaired separately. A formal production-validation run that hits a shared-Core defect is failed evidence and must be rerun cleanly after reviewed Core repair.

## 4. Target resolution

### Weekly

Use configured Weekly cutoff logic and generic `WEEKLY + WEEKLY_MAGAZINE`. Weekly X/Grok is required.

### Retrospective Period

Configured monthly/half-year/annual Specials use the single pre-existing `scripts/survey_period_v2.py` path. Custom bounded periods remain generic. Do not create cadence-specific engines.

### Thematic

Resolve topic scope from canonical planning authority. Materializing a machine-readable `thematic-scope-spec-v2` scope is internal work, not a Human Gate. Connector initialization revalidates that planning authority, takes explicit temporal mode from the immutable request, and derives `as_of` from request `recorded_at` before using generic `core.thematic_profile()`.

### Generative AI Foundations

Use the living series memo as outer authority and materialize each volume as Thematic/LONGFORM work. Do not create a parallel machine series engine.

## 5. Deterministic execution mode

Use exact local CLI when available.

When connector-only ChatGPT cannot execute local Core, use the single default-branch operator workflow through one supported bounded transport:

```text
ChatGPT adds one immutable request-only commit
-> push it as the exact current Profile-bound work-branch head
-> activate transport A or B

A. persistent Issue queue
   comment on GitHub Issue #448:
     /survey-core-execute <exact-request-commit-sha>

B. connector-native PR transport
   open same-repository PR targeting main
   title begins: Survey Core operator transport:
   PR head branch == immutable request work_branch

-> default-branch survey-production-v2-operator-bridge.yml
   issue_comment or pull_request_target activation only
-> common read-only trusted preflight
-> write-capable deterministic executor exists only after preflight PASS
```

Prefer Issue #448 when the active environment produces an observable workflow run. If connector-created Issue comments do not activate Actions, use the connector-native PR path. A transport PR is execution transport only and must not be merged as production/integration authority; close it after successful writeback or after the failed attempt is recorded.

The PR path is valid only for a same-repository PR targeting `main`, an authorized repository association, the reserved title prefix, and exact PR-head/request-`work_branch` equality. Forks, branch mismatch, malformed request commits, or unauthorized actors fail closed.

The work branch supplies request data only; it does not supply the trust-deciding workflow. `pipeline-contract-tests.yml` remains CI-only. Both transports are transport, not Human Gates, and the workflow set remains exactly seven.

Before activating either transport, the request-only commit must be the current canonical work-branch head. If the branch moves during admission/execution, the workflow fails closed rather than overwriting newer work. Pre-admission parsing is isolated from repository-local imports; the write-capable executor runs Core from reviewed-main runtime bytes, not the admitted worktree import root.

The bridge request surface remains exactly:

- `INITIALIZE_WEEKLY`
- `INITIALIZE_RETROSPECTIVE`
- `INITIALIZE_THEMATIC`
- `ADVANCE_STAGE`
- `RECORD_ARCHITECTURE_APPROVAL`
- `REQUEST_ARCHITECTURE_REVISION`
- `RECORD_PUBLICATION_PREVIEW_APPROVAL`
- `REQUEST_PUBLICATION_PREVIEW_REVISION`

Human Gate operations only record already explicit Human input.

## 6. Human review surface preparation

Before presenting either normal Human Gate:

1. finish all current Gate inputs and every mandatory internal review that applies;
2. commit exact current Production State + configured Gate inputs;
3. **push/retain that commit on the Profile-bound canonical work branch**;
4. record that exact commit as `reviewed_repository_commit_sha`;
5. present exactly those committed bytes to the Human.

Canonical Human Gate Core rejects a decision unless the named commit:

- exists;
- is reachable from canonical work branch;
- contains exact current reviewed State/Gate-input bytes;
- for Publication Preview, contains exact Candidate-bound PDF.

When Architecture Review is still pending, its surface has not been presented, and no Human review record or provenance exists, Core also supports an explicit operator-side pending-Gate invalidation. It uses only configured safe regeneration boundaries, records immutable non-Human provenance, rewinds State/checkpoints through Core, and does not create `REQUEST_CHANGES`, `APPROVED`, a Human revision, `reviewed_by`, or `reviewed_at`. Publication Preview cannot use this operation to cross an active Architecture approval.

Connector-safe execution additionally binds the same reviewed commit to the immutable request-only commit parent. Do not substitute the later request/event commit.

## 7. Research → Architecture loop

Normal autonomous progression includes explicit Sol supervisory checkpoints:

```text
Profile/State
-> Source Intake + research expansion
-> Discovery materialization
-> Sol Discovery completeness review
-> Screening
-> Evidence verification + iterative authority gap fill
-> SOL_EVIDENCE_REVIEW_READY
-> Sol authority-consumption review
-> additional Evidence gap fill when required
-> Sol materiality / Selection review
-> Architecture preparation under Sol-owned semantics
-> Sol Architecture review + Human-facing dossier
-> exact stage validation/checkpoint
-> ARCHITECTURE_REVIEW
```

Luna/Work may execute the bulk retrieval, normalization, Evidence tasks, gap-fill retrieval, and deterministic regeneration. It must not substitute its own completion judgment for the Sol supervisory checkpoints defined in `docs/survey-production-core-v2-sol-luna-review-governance.md`.

If a post-Screening authority gap is found before that first Human presentation, retain exact Raw bytes and retrieval provenance in an edition-local Evidence Authority Supplement. The supplement preserves the accepted Screening decision and binds only explicitly named sources to the corresponding Evidence Task/Card.

Binding a primary source into a Supplement or Evidence Card is not proof that its substantive content was consumed. Before Selection/Architecture, Sol must distinguish authority not found, retrieval failed, captured-but-unconsumed, and consumed authority.

## 8. Architecture Review

At pending Architecture Review, present the exact committed Architecture surface **and** the mandatory Human-facing dossier defined in `docs/survey-production-core-v2-sol-luna-review-governance.md`.

The first presentation of each Architecture revision must include, at minimum:

- exact reviewed commit/revision/state;
- research coverage and independent Discovery-completeness findings;
- Evidence status and authority-consumption findings;
- major candidate/disposition map, including important unselected candidates;
- negative-space/omission review;
- editorial thesis and package order;
- page/section allocation;
- materially plausible alternative Architecture(s) considered;
- known limitations/risks;
- Sol blocking/non-blocking findings and recommendation.

Do **not** request Human approval from a short `READY_FOR_ARCHITECTURE_REVIEW` status summary. Machine readiness and deterministic validation do not establish research sufficiency.

If `SELECTED <= 1` while `non-DROP >= 20` or `VERIFIED >= 10`, a documented Sol compression audit is mandatory before approval can be recommended.

### APPROVED

Record Human approval against the durable reviewed commit. Core writes:

- current canonical Architecture approval;
- immutable `gates/reviews/approvals/architecture-rN.json` snapshot;
- `gates/reviews/architecture-rN.json` review record;
- review-index update.

Then continue to drafting.

### REQUEST_CHANGES

Require explicit requested changes and allowed pre-Architecture regeneration boundary. Core records rN, invalidates only affected downstream authority, and returns to the selected boundary. ChatGPT repairs and returns to Architecture Review rN+1.

If the requested change concerns research completeness or authority consumption, prefer a bounded stop at a fresh Sol Evidence Review before allowing Selection/Architecture to be trusted again.

## 9. Reader-facing authorship and QA

After active Architecture approval, ChatGPT authors canonical reader-facing source. Internal Evidence/Selection/Architecture/Draft artifacts are not legal fallback publication prose.

For one exact source/PDF revision complete:

1. deterministic QA;
2. ChatGPT semantic/editorial QA;
3. ChatGPT visual QA of exact rendered PDF.

Only then assemble Publication Candidate.

## 10. Publication Preview

Commit and push/retain exact current State, Candidate, and Candidate-bound PDF before presenting the Gate.

### APPROVED

Record approval against the durable reviewed commit, including immutable `publication-rN` approval snapshot, then continue to Freeze.

### REQUEST_CHANGES — publication-local

If Human selects `ARCHITECTURE_ESTABLISHED`, `DRAFT_COMPLETE`, or `VALIDATED_DRAFT`, preserve valid active Architecture approval, invalidate affected publication authority, repair/rebuild/review, and return to Publication Preview rN+1.

### REQUEST_CHANGES — upstream / cross-gate

If Publication review reveals an Evidence/Selection/Architecture defect, the Human may select an allowed boundary before `ARCHITECTURE_ESTABLISHED`.

Core then:

1. records Publication `REQUEST_CHANGES` rN against exact reviewed Candidate/PDF;
2. preserves old Architecture rN review + immutable approval snapshot;
3. verifies current active canonical Architecture approval matches State provenance;
4. supersedes/removes that active canonical Architecture approval;
5. clears active Architecture provenance and marks Architecture Review pending;
6. invalidates downstream checkpoints from selected boundary;
7. resumes research/Selection/Architecture work, including mandatory Sol supervisory reviews;
8. stops at Architecture Review rN+1 before new drafting/publication can continue.

This is normal dependency-aware revision, not an Exception Gate.

## 11. Freeze / Release

After Publication approval:

```text
approved exact Candidate/PDF
-> Freeze Record / Release Manifest
-> FROZEN
-> reviewed merge to main
-> dedicated exact-byte Release workflow
-> merge/release verification
-> RELEASED
```

Do not add a second post-approval semantic/visual Human Gate.

## 12. X/Grok handoff

Weekly requires X/Grok. Retrospective/Thematic choose REQUIRED/NOT_REQUIRED with rationale. Foundations uses its dedicated Drive category when material.

Prepare one self-contained Drive task file and give the Human only the exact task-file path/reference. Returned bytes are imported exactly and dispositioned before continuing. Do not search for a Grok connector merely because intake is required.

## 13. Execution continuity

Maintain `{source_root}/execution/index.md` as a run-context/navigation file under execution-record policy section 4. Do not copy live lifecycle, State hash, Gate status, Candidate/PDF hashes or next action into it. Maintain concise session records, review summaries, defect records, request/receipt pointers when bridge transport is used, and canonical Human-review rN authority. New navigation or a changed operational fact still requires a record; a State-only transition does not require rewriting the navigation index.

Keep distinct:

- reviewed main baseline;
- Human-reviewed edition commit;
- request-only commit;
- operator transport event (Issue comment or transport PR);
- trusted default-branch operator workflow run;
- bot output commit.

For Evidence and Edition Views, resolve the active accepted pair only as `Production State -> passed Evidence Stage Checkpoint -> exact named artifact -> exact path/SHA validation`; historical accepted directories are immutable storage, not an authority selector.

Sol supervisory review records must identify the exact active Evidence/View authority they reviewed. A later regenerated Evidence run invalidates any semantic conclusion that depended on the previous active pair.

## 14. Core candidate audit rule

Core maintenance follows:

```text
finish all candidate changes
-> exact-head diagnostic CI
-> synchronize authority
-> pre-freeze cross-check
-> freeze one SHA
-> fresh seven-point audit from Point 1
-> no tree changes during audit
-> only 7/7 PASS -> Human full-candidate review
```

Point 7 explicitly includes dual default-branch operator transport trust bootstrap, durable work-branch review commits, isolated reviewed-main execution, immutable approval history, canonical Thematic materialization, and Publication→Architecture cross-gate reopen.

Any mutation after freeze invalidates the whole audit.
