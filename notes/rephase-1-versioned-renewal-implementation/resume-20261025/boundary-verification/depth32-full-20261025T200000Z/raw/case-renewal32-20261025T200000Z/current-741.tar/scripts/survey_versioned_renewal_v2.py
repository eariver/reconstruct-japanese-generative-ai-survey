#!/usr/bin/env python3
"""Versioned same-reader Core renewal HIGH operation + CLI (current invocation authority).

Selected contract 478f0051 including S11, mandatory root gate 7d7d5a45 including S6,
integrated R3 with R4/R5/R6 deltas as overridden by ROOT. This module owns current
invocation authority, exclusive capture/prepare, build transfer, finalize, activation
and resume. It calls the lower historian/source-proof modules and ordinary content
validators with explicit reloaded proof bindings. Current State authority is checked
here, outside the source-proof leaf.

Public API (fixed names/signatures per contract S11):
  prepare_renewal(root, state_path, renewal_id, intent, manuscript_spec_path,
                  toolchain_spec_path, executor, recorded_at)
  finalize_renewal(root, state_path, basis_path, checks_path, semantic_review_path,
                   visual_review_path, executor, recorded_at)
  validate_renewal_receipt(root, receipt_path)
  validate_prepared_renewal_set(root, state_path, set_path)
  activate_renewal(root, state_path, set_path, reason, executor, recorded_at)
  resume_renewal_activation(root, state_path, record_path)
  verify_renewal_history(root, record_path)
  verify_renewal_rerender_equality(root, basis_path, proof_path)
  observe_renewal_authority(root, state_path, basis_path)

Entry procedure (binding, root S2): strict no-follow pinned State/config bytes,
State validated against agent.STATE_SCHEMA before indexing, canonical State path
derived from exact Profile ref + cfg.state_authority.authoritative_filename (same
source-root rule as P1 1575-1583; no basename inference), Profile through
agent._profile_and_source (live-live binding only), pure prePreview/Exception
window (exact P1 414-429 predicates), then PUBLIC agent.validate_agent_state on
the same LIVE bytes with no pending argument; pinned bytes rechecked after the
call. The sole State pointer must select a nonnull versioned record/set/Candidate.
production.verify_state_basis is NEVER called on renewal history/source/high
paths (it is a different globally current-pinned API, not a substitute). No
caller policy enum, no reusable permission result, no synthetic State, no
verified-dict token, no pending flags.

DAG: prior history + fresh before-State/selection + unchanged accepted inputs
-> _observe_renewal_entry -> exclusive COPY claim + inventory -> basis LAST +
pin recheck -> observe_renewal_authority -> Layer-A accepted content (SOURCE
module) -> proof -> Layer-B post-proof node (SOURCE module, still NO State)
-> C trio FILES (C only) -> C manuscript + real disposable build/transfer
(C only, after proof, both before external review) -> build record
(REUSED vs EXECUTED) -> receipt (AFTER build-record) -> fresh QA + postrender
reviews -> QA/Gate/Candidate (SAME proof ref) -> seal LAST -> validate ->
activate -> normal active Candidate -> direct stage -> Preview/Freeze/Release.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

RENEWAL_ID_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")
INTENTS = ("REUSE_TARGETS", "RENDER_TARGETS")
MAX_FILE_BYTES = 20 * 1024 * 1024
MAX_JSON_BYTES = 8 * 1024 * 1024
CHAIN_LIMIT = 32

RENEWAL_BASIS_SCHEMA = "schemas/versioned-renewal-basis-v2.schema.json"
RENEWAL_PROOF_SCHEMA = "schemas/versioned-renewal-source-proof-v2.schema.json"
RENEWAL_RECEIPT_SCHEMA = "schemas/versioned-renewal-source-manifest-v2.schema.json"
RENEWAL_SET_SCHEMA = "schemas/versioned-renewal-publication-set-v2.schema.json"

WEEKLY_ROUTE = "WEEKLY_GENERATED_V2"
LONGFORM_ROUTE = "LONGFORM_GENERATED_V1"
ROUTE_FOR_PUBLICATION_PROFILE = {
    "WEEKLY_MAGAZINE": WEEKLY_ROUTE,
    "LONGFORM_SPECIAL": LONGFORM_ROUTE,
}


class RenewalHighError(ValueError):
    def __init__(self, code: str, detail: str, *, phase: str = "HIGH",
                 disposition: str = "REFUSED_PRE_WRITE"):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail
        self.phase = phase
        self.disposition = disposition


def _fail(code: str, phase: str, disposition: str, detail: str) -> RenewalHighError:
    return RenewalHighError(code, detail, phase=phase, disposition=disposition)


def _copy_hist_anchor(history: dict[str, Any], validation_ref: dict[str, Any]) -> dict[str, Any]:
    """Copy chain-derived canonical_anchor verbatim from HIST (no default).

    HIST verify_versioned_history returns complete independently derived
    {kind,ref} from the verified actual chain (latest legacy before FIRST
    versioned, no rolling). HIGH basis must copy it verbatim; it must NOT
    synthesize kind from history.anchor_kind + original validation default
    (the exact r4 defect: LEGACY kind with DRAFT_COMPLETE ref vs expected r2).
    No fallback to originalPath when kind is LEGACY: a LEGACY anchor whose
    ref equals the original validation checkpoint refuses here.
    """
    anchor = history.get("canonical_anchor")
    if not isinstance(anchor, dict) or set(anchor) != {"kind", "ref"}:
        raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                    "historian canonical_anchor missing (chain-derived identity required)")
    kind = anchor.get("kind")
    ref = anchor.get("ref")
    if kind not in ("VALIDATION_CHECKPOINT", "LEGACY_REVALIDATION"):
        raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                    "historian canonical_anchor kind invalid")
    if not isinstance(ref, dict) or set(ref) != {"path", "sha256"}:
        raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                    "historian canonical_anchor ref fields invalid")
    if not isinstance(ref.get("path"), str) or not ref.get("path"):
        raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                    "historian canonical_anchor ref path invalid")
    sha = ref.get("sha256")
    if not isinstance(sha, str) or len(sha) != 64 or any(c not in "0123456789abcdef" for c in sha):
        raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                    "historian canonical_anchor ref sha invalid")
    if kind == "LEGACY_REVALIDATION":
        vr = validation_ref if isinstance(validation_ref, dict) else {}
        if ref.get("path") == vr.get("path") and ref.get("sha256") == vr.get("sha256"):
            raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                        "historian LEGACY anchor must not fallback to originalPath (expected legacy record, not DRAFT_COMPLETE)")
    else:
        vr = validation_ref if isinstance(validation_ref, dict) else {}
        if ref.get("path") != vr.get("path") or ref.get("sha256") != vr.get("sha256"):
            raise _fail("HISTORY_ANCESTOR", "PREPARE", "PRESERVED_INCOMPLETE",
                        "historian VALIDATION anchor must equal original validation checkpoint")
    return {"kind": str(kind), "ref": {"path": str(ref["path"]), "sha256": str(ref["sha256"])}}


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _sha_object(value: Any) -> str:
    return _sha_bytes(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                 separators=(",", ":")).encode("utf-8"))


def _no_duplicate_object(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for k, v in pairs:
        if k in out:
            raise RenewalHighError("HIGH_DIGEST_MISMATCH", f"duplicate JSON key: {k}",
                                   phase="LOAD", disposition="REFUSED_PRE_WRITE")
        out[k] = v
    return out


def _parse_instant_str(value: str) -> datetime:
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise _fail("ARGS", "TIME", "REFUSED_PRE_WRITE",
                    f"instant invalid: {exc}") from exc
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc)


def _now_utc(recorded_at: datetime | str | None = None) -> str:
    if isinstance(recorded_at, datetime):
        dt = recorded_at
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    if isinstance(recorded_at, str):
        if not recorded_at:
            raise _fail("ARGS", "TIME", "REFUSED_PRE_WRITE", "recorded_at empty")
        try:
            dt = datetime.fromisoformat(recorded_at.replace("Z", "+00:00"))
        except ValueError as exc:
            raise _fail("ARGS", "TIME", "REFUSED_PRE_WRITE",
                        f"recorded_at invalid: {exc}") from exc
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _lexical_rel(repo: Path, raw: str | Path, label: str) -> str:
    s = str(raw)
    if Path(s).is_absolute():
        try:
            return Path(s).relative_to(repo.resolve()).as_posix()
        except ValueError as exc:
            raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} escapes repository root: {raw}") from exc
    if not s or "\\" in s or s.startswith("/"):
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE", f"{label} path invalid: {raw}")
    parts = Path(s).parts
    if any(p in ("..", ".", "") for p in parts):
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} unsafe component: {raw}")
    if len(s) > 1024 or len(parts) > 64:
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE", f"{label} path too long: {raw}")
    return s


def _lexical_parts(rel: str, label: str) -> tuple[str, ...]:
    if not isinstance(rel, str) or not rel or "\\" in rel:
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} must be repository-relative without traversal: {rel!r}")
    if len(rel) > 1024:
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} path too long: {len(rel)}")
    if rel.startswith("/") or rel == "." or rel.startswith("./"):
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} must be repository-relative: {rel!r}")
    parts = tuple(rel.split("/"))
    if len(parts) > 64:
        raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} path too deep: {len(parts)}")
    for part in parts:
        if part in ("", ".", ".."):
            raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} has unsafe path component: {rel!r}")
        if len(part) > 255:
            raise _fail("HIGH_PATH", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} path component too long: {part!r}")
    return parts


def _walk_existing_ancestors(repo: Path, parts: tuple[str, ...], label: str) -> None:
    root = repo.resolve()
    try:
        lst = os.lstat(root)
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} cannot lstat repo root: {exc}") from exc
    if stat.S_ISLNK(lst.st_mode):
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} repo root is symlink")
    if not stat.S_ISDIR(lst.st_mode):
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} repo root is not a directory")
    current = root
    for part in parts[:-1]:
        current = current / part
        try:
            st = os.lstat(current)
        except FileNotFoundError:
            return
        except OSError as exc:
            raise _fail("HIGH_UNREADABLE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} ancestor check failed: {current}: {exc}") from exc
        if stat.S_ISLNK(st.st_mode):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} has symlinked ancestor component: {current}")
        if not stat.S_ISDIR(st.st_mode):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} has non-directory ancestor component: {current}")


def _fd_safe_read(repo: Path, rel: str, label: str) -> bytes:
    root_resolved = repo.resolve()
    try:
        lst = os.lstat(root_resolved)
    except OSError as exc:
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} cannot lstat repo root: {exc}") from exc
    if stat.S_ISLNK(lst.st_mode):
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} repo root is symlink")
    if not stat.S_ISDIR(lst.st_mode):
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} repo root is not a directory")
    parts = _lexical_parts(rel, label)
    dir_parts, leaf = parts[:-1], parts[-1]
    held: list[int] = []
    try:
        try:
            root_fd = os.open(root_resolved, os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0))
        except OSError as exc:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} cannot open repo root no-follow: {exc}") from exc
        held.append(root_fd)
        try:
            rst = os.fstat(root_fd)
        except OSError as exc:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} root fstat failed: {exc}") from exc
        if not stat.S_ISDIR(rst.st_mode):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} root is not a directory after open")
        if (lst.st_dev, lst.st_ino) != (rst.st_dev, rst.st_ino):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} repo root replaced between lstat and open")
        parent = root_fd
        cur: list[str] = []
        for part in dir_parts:
            cur.append(part)
            try:
                fd = os.open(part, os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0), dir_fd=parent)
            except FileNotFoundError as exc:
                raise _fail("HIGH_MISSING", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor missing: {'/'.join(cur)}: {exc}") from exc
            except OSError as exc:
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor not openable as dir (symlink?): {'/'.join(cur)}: {exc}") from exc
            held.append(fd)
            try:
                st = os.fstat(fd)
            except OSError as exc:
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor fstat failed: {'/'.join(cur)}: {exc}") from exc
            if not stat.S_ISDIR(st.st_mode):
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor not a directory: {'/'.join(cur)}")
            try:
                est = os.stat(part, dir_fd=parent, follow_symlinks=False)
            except OSError as exc:
                raise _fail("HIGH_UNREADABLE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor entry unreadable: {'/'.join(cur)}: {exc}") from exc
            if stat.S_ISLNK(est.st_mode):
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor is symlink: {'/'.join(cur)}")
            if (est.st_dev, est.st_ino) != (st.st_dev, st.st_ino):
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} ancestor replaced during open: {'/'.join(cur)}")
            parent = fd
        try:
            ent = os.stat(leaf, dir_fd=parent, follow_symlinks=False)
        except FileNotFoundError as exc:
            raise _fail("HIGH_MISSING", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} missing: {rel}: {exc}") from exc
        except OSError as exc:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} leaf entry unreadable: {rel}: {exc}") from exc
        if stat.S_ISLNK(ent.st_mode):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} is a symlink/refusal: {rel}")
        if not stat.S_ISREG(ent.st_mode):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} is not a regular file (FIFO/socket/device/dir refused): {rel}")
        try:
            fd = os.open(leaf, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0), dir_fd=parent)
        except OSError as exc:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} open refused (symlink/unsafe): {rel}: {exc}") from exc
        held.append(fd)
        try:
            fst = os.fstat(fd)
        except OSError as exc:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} fstat failed: {rel}: {exc}") from exc
        if not stat.S_ISREG(fst.st_mode):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} is not a regular file after open: {rel}")
        if (fst.st_dev, fst.st_ino) != (ent.st_dev, ent.st_ino):
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} replaced between entry check and open: {rel}")
        chunks: list[bytes] = []
        total = 0
        while True:
            try:
                chunk = os.read(fd, 65536)
            except OSError as exc:
                raise _fail("HIGH_UNREADABLE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} read failed: {rel}: {exc}") from exc
            if not chunk:
                break
            total += len(chunk)
            if total > MAX_FILE_BYTES:
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} file too large (limit {MAX_FILE_BYTES}): {rel}")
            chunks.append(chunk)
        data = b"".join(chunks)
        try:
            os.close(fd)
        except OSError as exc:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} close after read failed: {rel}: {exc}") from exc
        finally:
            if fd in held:
                try:
                    held.remove(fd)
                except ValueError:
                    pass
        if len(data) < 1:
            raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                        f"{label} size out of bounds: {rel} (0)")
        return data
    finally:
        for hfd in reversed(list(held)):
            try:
                os.close(hfd)
            except OSError as exc:
                raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                            f"{label} descriptor close failed: {exc}") from exc


def _safe_path(repo: Path, rel: str, label: str) -> Path:
    parts = _lexical_parts(rel, label)
    _walk_existing_ancestors(repo, parts, label)
    target = repo.resolve().joinpath(*parts)
    try:
        st = os.lstat(target)
    except FileNotFoundError as exc:
        raise _fail("HIGH_MISSING", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} not a regular file: {rel}") from exc
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} unreadable: {rel}: {exc}") from exc
    if stat.S_ISLNK(st.st_mode):
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} symlink refused: {rel}")
    if not stat.S_ISREG(st.st_mode):
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} not a regular file: {rel}")
    return target


def _read_bytes_bounded(repo: Path, rel: str, label: str) -> bytes:
    return _fd_safe_read(repo, rel, label)


def _strict_json_from_bytes(data: bytes, label: str) -> Any:
    if len(data) > MAX_JSON_BYTES:
        raise _fail("HIGH_MODE", "LOAD", "REFUSED_PRE_WRITE", f"{label} JSON too large")
    try:
        return json.loads(data.decode("utf-8"), object_pairs_hook=_no_duplicate_object)
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise _fail("HIGH_DIGEST_MISMATCH", "LOAD", "REFUSED_PRE_WRITE",
                    f"{label} strict JSON invalid: {exc}") from exc


def _is_hex64(value: Any) -> bool:
    return (isinstance(value, str) and len(value) == 64
            and all(c in "0123456789abcdef" for c in value))


def _is_gitsha(value: Any) -> bool:
    return (isinstance(value, str) and len(value) == 40
            and all(c in "0123456789abcdef" for c in value))


def _git(repo: Path, *args: str, label: str) -> str:
    try:
        proc = subprocess.run(
            ["git", "--no-optional-locks", *args],
            cwd=str(repo), capture_output=True, text=True, timeout=120,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise _fail("HISTORY_BLOB_MISSING", "GIT", "REFUSED_PRE_WRITE",
                    f"{label} git invocation failed: {exc}") from exc
    if proc.returncode != 0:
        raise _fail("HISTORY_BLOB_MISSING", "GIT", "REFUSED_PRE_WRITE",
                    f"{label} git failed ({proc.returncode}): {proc.stderr.strip()[:300]}")
    return proc.stdout


def _current_commit(repo: Path) -> str:
    out = _git(repo, "rev-parse", "HEAD", label="current tool epoch").strip()
    if not _is_gitsha(out):
        raise _fail("BASIS_CURRENT_TOOL_DRIFT", "EPOCH", "REFUSED_PRE_WRITE",
                    "current HEAD is not a 40-hex commit")
    return out


def _atomic_write_new(repo: Path, rel: str, data: bytes, label: str) -> dict[str, Any]:
    """Exclusive new-file claim: O_CREAT|O_EXCL|O_NOFOLLOW, fsync, post-read verify.

    Refuses when the target already exists (no same-byte takeover, no cleanup of
    foreign/unknown residue). Returns observed file identity (dev/ino/size/sha).
    Primary + secondary errors are both preserved; referenced records are never
    deleted.
    """
    _lexical_rel(repo, rel, label)
    _walk_existing_ancestors(repo, _lexical_parts(rel, label), label)
    directory = (repo / rel).parent
    try:
        directory.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        raise _fail("RECORD_COLLISION", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} parent unavailable: {rel}: {exc}") from exc
    _walk_existing_ancestors(repo, _lexical_parts(rel, label), label)
    target = repo.resolve().joinpath(*rel.split("/"))
    try:
        fd = os.open(str(target), os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    except FileExistsError as exc:
        raise _fail("RECORD_COLLISION", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} target already claimed (fresh id required, no takeover): "
                    f"{rel}") from exc
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} exclusive claim failed: {rel}: {exc}") from exc
    primary: Exception | None = None
    try:
        os.write(fd, data)
        os.fsync(fd)
    except OSError as exc:
        primary = exc
    try:
        created_st = os.fstat(fd)
    except OSError as exc:
        if primary is None:
            primary = exc
    try:
        os.close(fd)
    except OSError as exc:
        if primary is None:
            primary = exc
        else:
            raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                        f"{label} write failed: {exc}; close also failed: {primary}") from exc
    if primary is not None:
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} write failed: {primary}") from primary
    try:
        lst = os.lstat(target)
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} post-write lstat failed: {rel}: {exc}") from exc
    if stat.S_ISLNK(lst.st_mode):
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} post-write target is symlink: {rel}")
    if (lst.st_dev, lst.st_ino) != (created_st.st_dev, created_st.st_ino):
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} post-write target replaced (dev/ino changed): {rel}")
    if lst.st_nlink != 1:
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} hardlink sharing refused: {rel}")
    observed = _fd_safe_read(repo, rel, f"{label} post-write")
    if observed != data:
        raise _fail("HIGH_UNREADABLE", "WRITE", "PRESERVED_INCOMPLETE",
                    f"{label} post-write bytes differ: {rel}")
    return {"path": rel, "sha256": _sha_bytes(observed), "byte_count": len(observed),
            "st_dev": lst.st_dev, "st_ino": lst.st_ino}


def _write_json_bound(repo: Path, rel: str, doc: dict[str, Any], digest_key: str,
                      label: str, phase: str, code: str) -> bytes:
    """Exclusive JSON write with self-digest binding on reparse.

    File-ref SHA is the full serialized bytes, distinct from the object
    self-digest by design (indent=2 file bytes vs compact sorted digest).
    The self-digest binds when the written bytes reparse to the same digest;
    that reparse check happens here, before any schema validation or use.
    """
    from scripts import survey_production_v2 as core
    data = core.json_bytes(doc)
    _atomic_write_new(repo, rel, data, label)
    reparsed = _strict_json_from_bytes(
        _read_bytes_bounded(repo, rel, f"{label} reparse"), f"{label} reparse")
    if not isinstance(reparsed, dict) or core.sha256_object(
            {k: v for k, v in reparsed.items() if k != digest_key}) != doc.get(digest_key):
        raise _fail(code, phase, "REFUSED_PRE_WRITE",
                    f"{label} written bytes do not reparse to the declared self-digest")
    return data


def _require_renewal_entry_window(state: dict[str, Any]) -> None:
    """Pure named operation eligibility check on just-pinned State bytes.

    Exact predicates of P1 _eligibility (lifecycle VALIDATED_DRAFT, Architecture
    approved, Preview pending with no Preview Human provenance, downstream
    publication_preview/freeze/release machine checkpoints all pending, Exception
    inactive). Examines the pinned State only; never synthesizes State. This is
    a named check, not a caller flag and not a replacement State validator.
    """
    problems: list[str] = []
    if state.get("lifecycle_state") != "VALIDATED_DRAFT":
        problems.append("requires healthy VALIDATED_DRAFT")
    gates = state.get("human_gates", {})
    if not isinstance(gates, dict) or gates.get("architecture_review") != "approved":
        problems.append("requires approved Architecture Review")
    if gates.get("publication_preview") != "pending":
        problems.append("forbids decided Publication Preview")
    prov = state.get("human_gate_provenance", {})
    if isinstance(prov, dict) and prov.get("publication_preview") is not None:
        problems.append("forbids Publication Preview Human provenance")
    checkpoints = state.get("machine_checkpoints", {})
    if not isinstance(checkpoints, dict) or any(
            checkpoints.get(n) != "pending"
            for n in ("publication_preview", "freeze", "release")):
        problems.append("forbids resolved downstream checkpoint")
    exc_gate = state.get("exception_gate", {})
    if not isinstance(exc_gate, dict) or exc_gate.get("status") != "inactive":
        problems.append("forbids active Exception Gate")
    if problems:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "; ".join(problems))


def _observe_renewal_entry(root: str | Path, state_path: str | Path) -> dict[str, Any]:
    """HIGH private entry observation before capture (no basis yet).

    Reloads LIVE canonical State + config through strict no-follow pinned bytes,
    validates State against agent.STATE_SCHEMA before indexing, derives the sole
    canonical State path from the exact Profile ref + cfg source-root rule (same
    rule as P1 1575-1583; supplied history/copy/alias paths refuse; no basename
    inference), applies the pure prePreview/Exception window, then calls PUBLIC
    agent.validate_agent_state on those same LIVE bytes with no pending argument
    and rechecks pinned bytes after the call. Resolves the prior versioned
    history via the typed historian and records current tool predicates as
    INFO pins only (never compared to state.contract here; that equality lives
    in the forbidden production.verify_state_basis). Returns invocation-local
    pins only; no public verified-object parameter. NEVER calls
    production.verify_state_basis, checkpoint resolvers, screening/evidence
    State branches, Reader/Gate/Candidate/seal/full receipt/P1/P2R/P3S.
    """
    from scripts import survey_agent_control_v2 as agent
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_publication_set_v2 as setmod
    from scripts import survey_versioned_renewal_history_v2 as hist
    repo = Path(root).resolve()
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    state_bytes = _read_bytes_bounded(repo, state_rel, "Production State")
    state_sha = _sha_bytes(state_bytes)
    try:
        cfg_rel = core.DEFAULT_CONFIG.as_posix()
    except AttributeError as exc:
        raise _fail("CONFIG_UNREADABLE", "ENTRY", "REFUSED_PRE_WRITE",
                    f"production DEFAULT_CONFIG missing: {exc}") from exc
    cfg_bytes = _read_bytes_bounded(repo, _lexical_rel(repo, cfg_rel, "implementation config"),
                                    "implementation config")
    cfg = _strict_json_from_bytes(cfg_bytes, "implementation config")
    if not isinstance(cfg, dict):
        raise _fail("CONFIG_UNREADABLE", "ENTRY", "REFUSED_PRE_WRITE", "config must be an object")
    state = _strict_json_from_bytes(state_bytes, "Production State")
    if not isinstance(state, dict):
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "Production State must be an object")
    try:
        _validate_pinned_instance(repo, state, state_rel, state_sha,
                                  agent.STATE_SCHEMA.as_posix(),
                                  "Production State", "ENTRY",
                                  fail_code="BASIS_ENTRY_INELIGIBLE")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    f"Production State strict schema invalid: {exc}") from exc
    try:
        _profile_path, profile, source_root = agent._profile_and_source(repo, cfg, state)
    except (OSError, ValueError, KeyError) as exc:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    f"live Profile binding invalid: {exc}") from exc
    try:
        src_root_raw = profile["paths"]["source_root"]
        filename_raw = cfg["state_authority"]["authoritative_filename"]
    except (KeyError, TypeError) as exc:
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    f"cannot derive canonical State path: {exc}") from exc
    if not isinstance(src_root_raw, str) or not isinstance(filename_raw, str):
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    "cannot derive canonical State path: source_root/filename must be strings")
    if "/" in filename_raw or "\\" in filename_raw or filename_raw in ("", ".", ".."):
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    f"authoritative filename must be a plain basename: {filename_raw!r}")
    _lexical_parts(src_root_raw, "paths.source_root")
    if len(filename_raw) > 255:
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    "authoritative filename too long")
    expected_state_rel = f"{src_root_raw}/{filename_raw}"
    if state_rel != expected_state_rel:
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    "Production State path is not the canonical authoritative State "
                    f"(exact spelling required: {expected_state_rel!r} vs {state_rel!r}; "
                    "history/copy/alias paths refuse; no basename inference; "
                    "no .resolve alias acceptance)")
    try:
        src_root_for_state = core.repo_local_path(repo, profile["paths"]["source_root"],
                                                  "paths.source_root")
        canonical_state = (src_root_for_state / cfg["state_authority"]["authoritative_filename"]).resolve()
    except (KeyError, TypeError, ValueError) as exc:
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    f"cannot derive canonical State path: {exc}") from exc
    if (repo / state_rel).resolve() != canonical_state:
        raise _fail("BASIS_STATE_PATH_IDENTITY", "ENTRY", "REFUSED_PRE_WRITE",
                    "Production State path is not the canonical authoritative State "
                    "(history/copy/alias paths refuse; no basename inference)")
    try:
        profile_ref = state.get("profile")
        if not isinstance(profile_ref, dict) or not isinstance(profile_ref.get("path"), str):
            raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                        "State profile ref invalid")
        profile_rel = _lexical_rel(repo, str(profile_ref["path"]), "Production Profile")
        profile_bytes = _read_bytes_bounded(repo, profile_rel, "Production Profile")
    except RenewalHighError:
        raise
    except Exception as exc:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    f"live Profile pin unreadable: {exc}") from exc
    if _sha_bytes(profile_bytes) != profile_ref.get("sha256"):
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "Production Profile bytes differ from State authority")
    _require_renewal_entry_window(state)
    try:
        errors = agent.validate_agent_state(repo, cfg, state)
    except Exception as exc:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    f"public State validation raised: {exc}") from exc
    if errors:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "public State validation refuses LIVE bytes: " + "; ".join(errors))
    if _sha_bytes(_read_bytes_bounded(repo, state_rel, "Production State recheck")) != state_sha:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "LIVE State bytes moved during entry validation")
    if _sha_bytes(_read_bytes_bounded(repo, _lexical_rel(repo, cfg_rel, "implementation config"),
                                      "implementation config recheck")) != _sha_bytes(cfg_bytes):
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "implementation config bytes moved during entry validation "
                    "(selected zero-delta pins; cfg drift refuses)")
    if _sha_bytes(_read_bytes_bounded(repo, profile_rel, "Production Profile recheck")) != _sha_bytes(profile_bytes):
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "Production Profile bytes moved during entry validation "
                    "(selected zero-delta pins; Profile drift refuses)")
    try:
        selection = setmod.resolve_publication_selection(repo, cfg, state)
    except Exception as exc:
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    f"State selection failed: {exc}") from exc
    if not isinstance(selection, dict) or selection.get("mode") != "VERSIONED_ACTIVE":
        raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                    "State pointer must select a nonnull versioned active set "
                    "(canonical-only/foreign/ambiguous authority refuses)")
    record_ref = selection.get("activation_record_ref") or selection.get("record_ref")
    set_ref = selection.get("active_set_ref") or selection.get("set_ref")
    candidate_ref = selection.get("candidate_ref")
    for name, ref in (("record", record_ref), ("set", set_ref), ("candidate", candidate_ref)):
        if not isinstance(ref, dict) or not isinstance(ref.get("path"), str) \
                or not _is_hex64(ref.get("sha256")):
            raise _fail("BASIS_ENTRY_INELIGIBLE", "ENTRY", "REFUSED_PRE_WRITE",
                        f"State-selected prior {name} ref must be exact nonnull {{path,sha256}}")
    try:
        prior_history = hist.verify_versioned_history(repo, str(record_ref["path"]))
    except Exception as exc:
        code = getattr(exc, "code", None) or "HISTORY_DIGEST_MISMATCH"
        raise _fail(str(code), "ENTRY", "REFUSED_PRE_WRITE",
                    f"prior history invalid: {exc}") from exc
    if not isinstance(prior_history, dict) or not prior_history.get("HISTORICAL_IDENTITY_VERIFIED"):
        raise _fail("HISTORY_DIGEST_MISMATCH", "ENTRY", "REFUSED_PRE_WRITE",
                    "prior history verdict missing")
    research_profile = profile.get("research_profile")
    publication_profile = profile.get("publication_profile")
    route = ROUTE_FOR_PUBLICATION_PROFILE.get(str(publication_profile))
    if research_profile not in ("WEEKLY", "THEMATIC") or route is None:
        raise _fail("UNSUPPORTED_MIGRATION", "ENTRY", "REFUSED_PRE_WRITE",
                    "Profile route family unsupported for same-reader renewal")
    try:
        current_commit = _current_commit(repo)
        current_contract = core.contract_identity(repo, cfg, str(research_profile),
                                                  str(publication_profile))
    except (ValueError, OSError) as exc:
        raise _fail("BASIS_CURRENT_TOOL_DRIFT", "ENTRY", "REFUSED_PRE_WRITE",
                    f"current tool predicates unreadable: {exc}") from exc
    try:
        recipe_text = _read_bytes_bounded(repo, ".latexmkrc", "build recipe").decode("utf-8")
    except RenewalHighError as exc:
        raise _fail(exc.code, "ENTRY", "REFUSED_PRE_WRITE",
                    f"recipe unavailable: {exc.detail}") from exc
    for marker in ("$pdf_mode", "$lualatex", "$biber", "$max_repeat"):
        if marker not in recipe_text:
            raise _fail("RECIPE_INCONSISTENT", "ENTRY", "REFUSED_PRE_WRITE",
                        f"build recipe missing required marker: {marker}")
    return {"state": state, "state_rel": state_rel, "state_sha": state_sha,
            "state_bytes": state_bytes, "cfg": cfg, "cfg_rel": _lexical_rel(repo, cfg_rel, "implementation config"),
            "cfg_sha": _sha_bytes(cfg_bytes), "cfg_bytes": cfg_bytes,
            "profile": profile, "profile_rel": profile_rel, "profile_sha": _sha_bytes(profile_bytes),
            "profile_bytes": profile_bytes, "expected_state_rel": expected_state_rel,
            "source_root": source_root, "selection": selection,
            "prior_record_ref": {"path": str(record_ref["path"]), "sha256": str(record_ref["sha256"])},
            "prior_set_ref": {"path": str(set_ref["path"]), "sha256": str(set_ref["sha256"])},
            "prior_candidate_ref": {"path": str(candidate_ref["path"]),
                                    "sha256": str(candidate_ref["sha256"])},
            "prior_history": prior_history, "research_profile": research_profile,
            "publication_profile": publication_profile, "generator_route": route,
            "current_commit": current_commit, "current_contract": current_contract}


def _recheck_entry_pins(repo: Path, entry: dict[str, Any], phase: str) -> None:
    if _sha_bytes(_read_bytes_bounded(repo, entry["state_rel"], f"{phase} State pin")) != entry["state_sha"]:
        raise _fail("BASIS_ENTRY_INELIGIBLE", phase, "REFUSED_PRE_WRITE",
                    "State bytes moved before write (selected zero-delta pins)")
    if _sha_bytes(_read_bytes_bounded(repo, entry["cfg_rel"], f"{phase} config pin")) != entry["cfg_sha"]:
        raise _fail("BASIS_ENTRY_INELIGIBLE", phase, "REFUSED_PRE_WRITE",
                    "implementation config bytes moved before write "
                    "(selected zero-delta pins; cfg drift refuses)")
    if _sha_bytes(_read_bytes_bounded(repo, entry["profile_rel"], f"{phase} Profile pin")) != entry["profile_sha"]:
        raise _fail("BASIS_ENTRY_INELIGIBLE", phase, "REFUSED_PRE_WRITE",
                    "Production Profile bytes moved before write "
                    "(selected zero-delta pins; Profile drift refuses)")


def _validate_pinned_instance(repo: Path, obj: Any, obj_rel: str, obj_expected_sha: str,
                              schema_rel: str, label: str, phase: str,
                              fail_code: str = "RENEWAL_PROOF_DIGEST") -> None:
    from scripts import survey_schema_v2 as schema_gate
    schema_bytes = _read_bytes_bounded(repo, schema_rel, f"{label} schema")
    _strict_json_from_bytes(schema_bytes, f"{label} schema")
    try:
        schema_gate.validate_instance(obj, repo / schema_rel, label=label)
    except (ValueError, OSError) as exc:
        raise _fail(fail_code, phase, "REFUSED_PRE_WRITE",
                    f"{label} schema invalid: {exc}") from exc
    if _sha_bytes(_read_bytes_bounded(repo, obj_rel, f"{label} recheck")) != obj_expected_sha:
        raise _fail(fail_code, phase, "REFUSED_PRE_WRITE",
                    f"{label} bytes moved during schema validation")
    if _sha_bytes(_read_bytes_bounded(repo, schema_rel, f"{label} schema recheck")) != _sha_bytes(schema_bytes):
        raise _fail(fail_code, phase, "REFUSED_PRE_WRITE",
                    f"{label} schema bytes moved during validation")


def _file_identity(repo: Path, rel: str, label: str) -> tuple[int, int]:
    _lexical_rel(repo, rel, label)
    _walk_existing_ancestors(repo, _lexical_parts(rel, label), label)
    target = repo.resolve().joinpath(*rel.split("/"))
    try:
        st = os.stat(target)
    except FileNotFoundError as exc:
        raise _fail("HIGH_MISSING", "ALIAS", "REFUSED_PRE_WRITE",
                    f"{label} missing for identity: {rel}: {exc}") from exc
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "ALIAS", "REFUSED_PRE_WRITE",
                    f"{label} identity unreadable: {rel}: {exc}") from exc
    return (st.st_dev, st.st_ino)


def _refuse_alias_unless_exact(repo: Path, supplied_rel: str, expected_rel: str,
                               supplied_sha: str, expected_sha: str, label: str,
                               phase: str) -> None:
    if supplied_rel != expected_rel:
        try:
            supplied_id = _file_identity(repo, supplied_rel, f"{label} supplied")
            expected_id = _file_identity(repo, expected_rel, f"{label} expected")
        except RenewalHighError:
            raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                        f"{label} alias path refused before writes "
                        f"(spelling {supplied_rel!r} != expected {expected_rel!r})")
        if supplied_id == expected_id or supplied_sha == expected_sha:
            raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                        f"{label} alias input refused before writes "
                        f"(spelling differs but same bytes/inode: {supplied_rel!r} vs {expected_rel!r}; "
                        "NOT ALREADY_ACTIVE by same SHA)")
        raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                    f"{label} path mismatch before writes: {supplied_rel!r} vs {expected_rel!r}")


def observe_renewal_authority(root: str | Path, state_path: str | Path,
                              basis_path: str | Path) -> dict[str, Any]:
    """HIGH basis-bound observation after basis capture, before finalize and
    immediately before activation. Reopens ALL inputs and demands: LIVE State
    bytes equal the fresh before_state_ref (live-live), retained COPY equals the
    basis binding, selected predecessor equals the State-selected seal
    (prior-relative + lineage-reachable), and basis.current_tool_epoch equals a
    CURRENT disk closure/contract recompute member-wise (current-current). No
    expected_contract caller argument; no old-State-vs-new-contract compare; no
    verify_state_basis transitively. Detached readback never calls this function.
    """
    from scripts import survey_production_v2 as core
    from scripts import survey_versioned_renewal_history_v2 as hist
    repo = Path(root).resolve()
    entry = _observe_renewal_entry(repo, state_path)
    basis_rel = _lexical_rel(repo, str(basis_path), "renewal basis")
    basis_bytes = _read_bytes_bounded(repo, basis_rel, "renewal basis")
    basis = _strict_json_from_bytes(basis_bytes, "renewal basis")
    if not isinstance(basis, dict):
        raise _fail("BASIS_DIGEST_MISMATCH", "OBSERVE", "REFUSED_PRE_WRITE",
                    "renewal basis must be an object")
    if basis.get("schema_version") != "2.0-rc1" or basis.get("kind") != "VERSIONED_RENEWAL_BASIS_V1":
        raise _fail("BASIS_DIGEST_MISMATCH", "OBSERVE", "REFUSED_PRE_WRITE",
                    "renewal basis kind/version mismatch")
    if core.sha256_object({k: v for k, v in basis.items() if k != "basis_sha256"}) != basis.get("basis_sha256"):
        raise _fail("BASIS_DIGEST_MISMATCH", "OBSERVE", "REFUSED_PRE_WRITE",
                    "renewal basis self-digest mismatch")
    before_ref = basis.get("before_state_ref")
    if not isinstance(before_ref, dict) or before_ref.get("path") != entry["state_rel"] \
            or before_ref.get("sha256") != entry["state_sha"]:
        raise _fail("BASIS_DIGEST_MISMATCH", "OBSERVE", "REFUSED_PRE_WRITE",
                    "LIVE State must equal the fresh before_state_ref (live-live)")
    retained_ref = basis.get("retained_copy_ref")
    if not isinstance(retained_ref, dict):
        raise _fail("BASIS_DIGEST_MISMATCH", "OBSERVE", "REFUSED_PRE_WRITE",
                    "retained_copy_ref invalid")
    retained_data = _read_bytes_bounded(repo, _lexical_rel(repo, str(retained_ref["path"]),
                                                           "retained COPY"), "retained COPY")
    if _sha_bytes(retained_data) != retained_ref.get("sha256") \
            or len(retained_data) != retained_ref.get("byte_count"):
        raise _fail("RETAINED_COPY_MISSING", "OBSERVE", "REFUSED_PRE_WRITE",
                    "retained COPY bytes changed")
    if _sha_bytes(retained_data) != before_ref.get("sha256"):
        raise _fail("RETAINED_COPY_MISSING", "OBSERVE", "REFUSED_PRE_WRITE",
                    "retained COPY SHA must equal before_state_ref")
    for key in ("prior_record_ref", "prior_selected_ref", "prior_candidate_ref"):
        ref = basis.get(key)
        want = {"prior_record_ref": entry["prior_record_ref"],
                "prior_selected_ref": entry["prior_set_ref"],
                "prior_candidate_ref": entry["prior_candidate_ref"]}[key]
        if not isinstance(ref, dict) or ref.get("path") != want["path"] \
                or ref.get("sha256") != want["sha256"]:
            raise _fail("REVIEW_TARGET_MISMATCH", "OBSERVE", "REFUSED_PRE_WRITE",
                        f"basis.{key} must equal the State-selected predecessor (prior-relative)")
    epoch = basis.get("current_tool_epoch", {})
    if epoch.get("repository_commit_sha") != entry["current_commit"]:
        raise _fail("BASIS_CURRENT_TOOL_DRIFT", "OBSERVE", "REFUSED_PRE_WRITE",
                    "basis current epoch moved (fresh basis required)")
    if epoch.get("contract") != entry["current_contract"]:
        raise _fail("BASIS_CURRENT_TOOL_DRIFT", "OBSERVE", "REFUSED_PRE_WRITE",
                    "basis current contract moved (fresh basis required)")
    try:
        expected_names = hist._expected_receipt_closure(entry["generator_route"], "NEW")
    except Exception as exc:
        code = getattr(exc, "code", None) or "UNSUPPORTED_MIGRATION"
        raise _fail(str(code), "OBSERVE", "REFUSED_PRE_WRITE",
                    f"closure expectation unavailable: {exc}") from exc
    live_closure: dict[str, str] = {}
    for name in expected_names:
        data = _read_bytes_bounded(repo, _lexical_rel(repo, name, f"current closure {name}"),
                                   f"current closure {name}")
        live_closure[name] = _sha_bytes(data)
    pinned = {str(r.get("name")): str(r.get("sha256"))
              for r in epoch.get("closure", []) if isinstance(r, dict)}
    if set(pinned) != set(expected_names):
        raise _fail("BASIS_CURRENT_TOOL_DRIFT", "OBSERVE", "REFUSED_PRE_WRITE",
                    "basis closure membership moved")
    drifted = sorted(n for n in expected_names if pinned.get(n) != live_closure.get(n))
    if drifted:
        raise _fail("BASIS_CURRENT_TOOL_DRIFT", "OBSERVE", "REFUSED_PRE_WRITE",
                    f"current tools drifted since basis capture: {drifted[:8]}")
    return {"entry": entry, "basis": basis, "basis_rel": basis_rel,
            "live_current_before": {"path": entry["state_rel"], "sha256": entry["state_sha"]},
            "retained_before": {"path": str(retained_ref["path"]),
                                "sha256": str(retained_ref["sha256"])},
            "selected_predecessor": entry["prior_set_ref"],
            "current_tools": {"repository_commit_sha": entry["current_commit"],
                              "contract": entry["current_contract"]}}


def verify_renewal_history(root: str | Path, record_path: str | Path) -> dict[str, Any]:
    """HIGH wrapper delegating to the typed historian loader. Historical
    structural loading of a renewal proof never executes its current-replay
    branch. Returns the descriptive HIST verdict, never a permit."""
    from scripts import survey_versioned_renewal_history_v2 as hist
    repo = Path(root).resolve()
    rel = _lexical_rel(repo, str(record_path), "history record")
    try:
        return hist.verify_versioned_history(repo, rel)
    except Exception as exc:
        code = getattr(exc, "code", None) or "HISTORY_DIGEST_MISMATCH"
        raise _fail(str(code), "HISTORY", "REFUSED_PRE_WRITE",
                    f"history verification failed: {exc}") from exc


def _load_prior_basis(repo: Path, entry: dict[str, Any]) -> dict[str, Any]:
    """Reload the prior basis via the prior record's renewal_basis_ref.

    For renewal predecessors only (repeat/C→U→U): the R receipt does not carry
    authored/reviewed-reader inputs, so the unchanged values come from the
    prior basis (exact path+SHA, live bytes verified, order preserved). Never
    a caller dict; never the new basis being constructed.
    """
    record_rel = entry["prior_record_ref"]["path"]
    record = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, record_rel, "prior record"),
                            "prior record"), "prior record")
    if not isinstance(record, dict):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior record must be an object")
    basis_ref = record.get("renewal_basis_ref", {})
    if not isinstance(basis_ref, dict) or not isinstance(basis_ref.get("path"), str) \
            or not _is_hex64(basis_ref.get("sha256")):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior record lacks exact renewal_basis_ref")
    basis_rel = _lexical_rel(repo, str(basis_ref["path"]), "prior basis")
    basis_bytes = _read_bytes_bounded(repo, basis_rel, "prior basis")
    if _sha_bytes(basis_bytes) != basis_ref["sha256"]:
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior basis bytes changed")
    basis = _strict_json_from_bytes(basis_bytes, "prior basis")
    if not isinstance(basis, dict):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior basis must be an object")
    return basis


def _load_prior_graph(repo: Path, entry: dict[str, Any]) -> dict[str, Any]:
    """Reload prior seal + prior receipt as typed historical data (prior-relative).

    Prior receipt is located via the prior seal's source-receipt role (never a
    hardcoded P/ literal). Returns seal/receipt docs plus derived P namespace
    (parent directory of the original proposal ref). Never the new seal being
    constructed.
    """
    seal_rel = entry["prior_set_ref"]["path"]
    seal_bytes = _read_bytes_bounded(repo, _lexical_rel(repo, seal_rel, "prior seal"),
                                     "prior seal")
    if _sha_bytes(seal_bytes) != entry["prior_set_ref"]["sha256"]:
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior seal bytes changed")
    seal = _strict_json_from_bytes(seal_bytes, "prior seal")
    if not isinstance(seal, dict):
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior seal must be an object")
    roles = seal.get("roles")
    if not isinstance(roles, dict):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior seal roles missing")
    receipt_role = roles.get("source-receipt")
    if not isinstance(receipt_role, dict) or not isinstance(receipt_role.get("path"), str) \
            or not _is_hex64(receipt_role.get("sha256")):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior seal lacks exact source-receipt role")
    receipt_rel = _lexical_rel(repo, str(receipt_role["path"]), "prior receipt")
    receipt_bytes = _read_bytes_bounded(repo, receipt_rel, "prior receipt")
    if _sha_bytes(receipt_bytes) != receipt_role["sha256"]:
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior receipt bytes changed")
    receipt = _strict_json_from_bytes(receipt_bytes, "prior receipt")
    if not isinstance(receipt, dict):
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior receipt must be an object")
    proposal_ref = receipt.get("proposal_ref")
    if not isinstance(proposal_ref, dict) or not isinstance(proposal_ref.get("path"), str) \
            or not _is_hex64(proposal_ref.get("sha256")):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior receipt lacks exact proposal_ref")
    proposal_rel = _lexical_rel(repo, str(proposal_ref["path"]), "original proposal")
    proposal_bytes = _read_bytes_bounded(repo, proposal_rel, "original proposal")
    if _sha_bytes(proposal_bytes) != proposal_ref["sha256"]:
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "original proposal bytes changed")
    namespace = str(Path(proposal_rel).parent.as_posix())
    if not namespace:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "REFUSED_PRE_WRITE",
                    "original proposal namespace underivable")
    return {"seal": seal, "seal_rel": seal_rel, "receipt": receipt,
            "receipt_rel": receipt_rel, "proposal_namespace": namespace,
            "proposal_rel": proposal_rel}


def prepare_renewal(root: str | Path, state_path: str | Path, renewal_id: str,
                    intent: str, manuscript_spec_path: str | Path | None,
                    toolchain_spec_path: str | Path | None, executor: str,
                    recorded_at: datetime | str | None = None) -> dict[str, Any]:
    """Exclusive capture: entry -> COPY claim + inventory -> basis LAST + recheck.

    U (REUSE_TARGETS): toolchain_spec_path MUST be None (CLI omits the option);
    no build is spawned. C (RENDER_TARGETS): explicit toolchain spec REQUIRED
    (rechecked, never synthesized). Intent has no power to waive derived checks.
    Incomplete R remains inert; retry uses a new id (no same-byte takeover, no
    cleanup of foreign/unknown residue). U sequence continues in finalize with
    current in-memory reader/trio comparison and exact old targets/build-unit
    validation; C continues with derived trio at new R paths.
    """
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_versioned_renewal_history_v2 as hist
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    repo = Path(root).resolve()
    if not isinstance(renewal_id, str) or RENEWAL_ID_RE.fullmatch(renewal_id) is None:
        raise _fail("ARGS", "PREPARE", "REFUSED_PRE_WRITE",
                    "renewal_id must match [a-z0-9][a-z0-9-]{0,63}")
    if intent not in INTENTS:
        raise _fail("INTENT_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    f"intent must be one of {INTENTS}")
    requested = "REUSE_TARGETS" if intent == "REUSE_TARGETS" else "RENDER_TARGETS"
    if requested == "REUSE_TARGETS" and toolchain_spec_path is not None:
        raise _fail("INTENT_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "U renewal forbids a toolchain spec (no build runs)")
    if requested == "RENDER_TARGETS" and toolchain_spec_path is None:
        raise _fail("INTENT_MISMATCH", "PREPARE", "REFUSED_PRE_WRITE",
                    "C renewal requires an explicit toolchain spec")
    if manuscript_spec_path is None:
        raise _fail("ARGS", "PREPARE", "REFUSED_PRE_WRITE", "manuscript_spec_path required")
    if not isinstance(executor, str) or not executor.strip():
        raise _fail("ARGS", "PREPARE", "REFUSED_PRE_WRITE", "executor required")
    ts = _now_utc(recorded_at)
    entry = _observe_renewal_entry(repo, state_path)
    state = entry["state"]
    graph = _load_prior_graph(repo, entry)
    receipt = graph["receipt"]
    seal = graph["seal"]
    namespace = graph["proposal_namespace"]
    if receipt.get("issue_id") != state.get("issue_id"):
        raise _fail("BASIS_ISSUE_PROFILE_DIVERGENCE", "PREPARE", "REFUSED_PRE_WRITE",
                    "prior receipt issue differs from LIVE State issue")
    renewal_rel = f"{namespace}/renewals/{renewal_id}"
    _lexical_rel(repo, renewal_rel, "renewal directory")
    _walk_existing_ancestors(repo, _lexical_parts(renewal_rel, "renewal directory"), "renewal directory")
    try:
        if os.lstat(repo.resolve().joinpath(*renewal_rel.split("/"))):
            raise _fail("RECORD_COLLISION", "PREPARE", "PRESERVED_INCOMPLETE",
                        f"renewal directory already claimed (fresh id required): {renewal_rel}")
    except FileNotFoundError:
        pass
    except RenewalHighError:
        raise
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "PREPARE", "PRESERVED_INCOMPLETE",
                    f"renewal directory unreadable: {renewal_rel}: {exc}") from exc
    try:
        (repo / renewal_rel).mkdir(parents=True, exist_ok=False)
    except FileExistsError as exc:
        raise _fail("RECORD_COLLISION", "PREPARE", "PRESERVED_INCOMPLETE",
                    f"renewal directory race-claimed: {renewal_rel}") from exc
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "PREPARE", "PRESERVED_INCOMPLETE",
                    f"renewal directory unavailable: {renewal_rel}: {exc}") from exc
    _walk_existing_ancestors(repo, _lexical_parts(renewal_rel, "renewal directory"), "renewal directory")
    _recheck_entry_pins(repo, entry, "PREPARE")
    retained_rel = f"{renewal_rel}/retained/before/{entry['state_rel']}"
    _lexical_rel(repo, retained_rel, "retained COPY")
    copy_info = _atomic_write_new(repo, retained_rel, entry["state_bytes"], "retained COPY")
    if copy_info["sha256"] != entry["state_sha"]:
        raise _fail("RETAINED_COPY_MISSING", "PREPARE", "PRESERVED_INCOMPLETE",
                    "retained COPY SHA must equal before_state_ref")
    try:
        history = hist.verify_versioned_history(repo, entry["prior_record_ref"]["path"])
    except Exception as exc:
        code = getattr(exc, "code", None) or "HISTORY_DIGEST_MISMATCH"
        raise _fail(str(code), "PREPARE", "PRESERVED_INCOMPLETE",
                    f"prior history revalidation failed: {exc}") from exc
    observed = history.get("observed_source_bindings", [])
    if not isinstance(observed, list) or not observed:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "historian observed bindings empty for active chain (must be NONEMPTY)")
    prior_accepted = receipt.get("accepted_refs")
    if not isinstance(prior_accepted, list) or not prior_accepted:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior receipt lacks accepted_refs")
    prior_authored = receipt.get("authored_refs")
    reviewed = receipt.get("reviewed_reader_input")
    if receipt.get("kind") == "VERSIONED_RENEWAL_SOURCE_V1":
        # Renewal predecessor (repeat/C→U→U): authoring/reader are unchanged
        # across renewals and live on the prior BASIS (the R receipt carries
        # accepted refs but no authored/reviewed-reader inputs). Load the
        # prior basis via the prior record's renewal_basis_ref (exact path+SHA,
        # live bytes verified) and copy verbatim (order preserved).
        prior_basis = _load_prior_basis(repo, entry)
        if not isinstance(prior_basis.get("authoring_refs"), list) \
                or len(prior_basis["authoring_refs"]) != 2:
            raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                        "prior basis lacks len2 authored_refs")
        prior_authored = prior_basis["authoring_refs"]
        if not isinstance(prior_basis.get("reviewed_reader_ref"), dict):
            raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                        "prior basis lacks reviewed_reader_ref")
        reviewed = {"path": str(prior_basis["reviewed_reader_ref"]["path"]),
                    "sha256": str(prior_basis["reviewed_reader_ref"]["sha256"])}
        live_rr = _read_bytes_bounded(repo, _lexical_rel(repo, reviewed["path"],
                                                         "prior reviewed reader"),
                                      "prior reviewed reader")
        if _sha_bytes(live_rr) != reviewed["sha256"]:
            raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "PRESERVED_INCOMPLETE",
                        "prior reviewed reader bytes changed")
    if not isinstance(prior_authored, list) or len(prior_authored) != 2:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior receipt lacks len2 authored_refs")
    if not isinstance(reviewed, dict) or not isinstance(reviewed.get("path"), str) \
            or not _is_hex64(reviewed.get("sha256")):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior receipt lacks exact reviewed_reader_input")
    try:
        expected_names = hist._expected_receipt_closure(entry["generator_route"], "NEW")
    except Exception as exc:
        code = getattr(exc, "code", None) or "UNSUPPORTED_MIGRATION"
        raise _fail(str(code), "PREPARE", "PRESERVED_INCOMPLETE",
                    f"closure expectation unavailable: {exc}") from exc
    closure_rows = []
    for name in expected_names:
        data = _read_bytes_bounded(repo, _lexical_rel(repo, name, f"current closure {name}"),
                                   f"current closure {name}")
        closure_rows.append({"name": name, "path": name, "sha256": _sha_bytes(data)})
    try:
        basis_schema_bytes = _read_bytes_bounded(repo, RENEWAL_BASIS_SCHEMA, "basis schema")
        basis_schema = _strict_json_from_bytes(basis_schema_bytes, "basis schema")
    except RenewalHighError:
        raise
    except (OSError, ValueError) as exc:
        raise _fail("CONFIG_UNREADABLE", "PREPARE", "PRESERVED_INCOMPLETE",
                    f"basis schema unreadable: {exc}") from exc
    _ = basis_schema
    profile_ref = dict(state.get("profile") or {})
    if set(profile_ref) != {"path", "sha256"}:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "LIVE State lacks exact profile ref")
    validation_ref = (state.get("checkpoint_provenance") or {}).get("validation")
    if not isinstance(validation_ref, dict) or set(validation_ref) != {"path", "sha256"}:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "LIVE State lacks exact validation checkpoint ref")
    mspec_rel = _lexical_rel(repo, str(manuscript_spec_path), "manuscript spec")
    mspec_bytes = _read_bytes_bounded(repo, mspec_rel, "manuscript spec")
    mspec_ref = {"path": mspec_rel, "sha256": _sha_bytes(mspec_bytes)}
    tspec_ref: dict[str, Any] | None = None
    if toolchain_spec_path is not None:
        tspec_rel = _lexical_rel(repo, str(toolchain_spec_path), "toolchain spec")
        tspec_bytes = _read_bytes_bounded(repo, tspec_rel, "toolchain spec")
        tspec_ref = {"path": tspec_rel, "sha256": _sha_bytes(tspec_bytes)}
    retention_rows: list[dict[str, Any]] = [{
        "roles": ["state:authority"], "path": entry["state_rel"],
        "sha256": entry["state_sha"], "byte_count": len(entry["state_bytes"]),
        "policy": "COPY_BEFORE_REPLACEMENT", "retained_dest": retained_rel,
        "retained_sha256": copy_info["sha256"],
        "retained_byte_count": copy_info["byte_count"],
    }]
    prof_rel = _lexical_rel(repo, str(profile_ref["path"]), "live Profile")
    prof_bytes = _read_bytes_bounded(repo, prof_rel, "live Profile")
    if _sha_bytes(prof_bytes) != profile_ref["sha256"]:
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "PRESERVED_INCOMPLETE",
                    "live Profile bytes changed")
    retention_rows.append({
        "roles": ["profile:authority"], "path": prof_rel,
        "sha256": profile_ref["sha256"], "byte_count": len(prof_bytes),
        "policy": "KEEP_IMMUTABLE",
        "retained_ref": {"path": prof_rel, "sha256": profile_ref["sha256"]},
    })
    roles = seal.get("roles", {})
    if not isinstance(roles, dict):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                    "prior seal roles missing")
    for role_name in sorted(roles):
        fr = roles[role_name]
        if not isinstance(fr, dict) or not isinstance(fr.get("path"), str) \
                or not _is_hex64(fr.get("sha256")) \
                or not isinstance(fr.get("byte_count"), int):
            raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PREPARE", "PRESERVED_INCOMPLETE",
                        f"prior seal role invalid: {role_name}")
        rrel = _lexical_rel(repo, str(fr["path"]), f"prior seal role {role_name}")
        rdata = _read_bytes_bounded(repo, rrel, f"prior seal role {role_name}")
        if _sha_bytes(rdata) != fr["sha256"] or len(rdata) != fr["byte_count"]:
            raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "PRESERVED_INCOMPLETE",
                        f"prior seal role bytes changed: {role_name}")
        retention_rows.append({
            "roles": [f"seal:{role_name}"], "path": rrel,
            "sha256": fr["sha256"], "byte_count": fr["byte_count"],
            "policy": "KEEP_IMMUTABLE",
            "retained_ref": {"path": rrel, "sha256": fr["sha256"]},
        })
    basis: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_BASIS_V1",
        "renewal_id": renewal_id, "proposal_namespace": namespace,
        "issue_id": state.get("issue_id"),
        "research_profile": entry["research_profile"],
        "publication_profile": entry["publication_profile"],
        "generator_route": entry["generator_route"],
        "original_proposal_ref": {"path": graph["proposal_rel"],
                                  "sha256": _sha_bytes(_read_bytes_bounded(
                                      repo, graph["proposal_rel"], "original proposal"))},
        "profile_ref": {"path": prof_rel, "sha256": profile_ref["sha256"]},
        "reviewed_reader_ref": {"path": _lexical_rel(repo, str(reviewed["path"]),
                                                     "reviewed reader"),
                                "sha256": reviewed["sha256"]},
        "authoring_refs": [{"name": str(r.get("name")), "path": str(r.get("path")),
                            "sha256": str(r.get("sha256"))} for r in prior_authored],
        "accepted_refs": [{"name": str(r.get("name")), "path": str(r.get("path")),
                           "sha256": str(r.get("sha256"))} for r in prior_accepted],
        "original_validation_ref": {"path": str(validation_ref["path"]),
                                    "sha256": str(validation_ref["sha256"])},
        "prior_selected_ref": dict(entry["prior_set_ref"]),
        "prior_record_ref": dict(entry["prior_record_ref"]),
        "prior_candidate_ref": dict(entry["prior_candidate_ref"]),
        "canonical_anchor": _copy_hist_anchor(history, validation_ref),
        "before_state_ref": {"path": entry["state_rel"], "sha256": entry["state_sha"]},
        "retained_copy_ref": {"path": retained_rel, "sha256": copy_info["sha256"],
                              "byte_count": copy_info["byte_count"]},
        "observed_source_bindings": observed,
        "current_tool_epoch": {"repository_commit_sha": entry["current_commit"],
                               "contract": entry["current_contract"],
                               "closure": closure_rows},
        "retention_rows": retention_rows,
        "requested": requested,
        "manuscript_spec_ref": mspec_ref,
        "executor": executor.strip(), "recorded_at": ts,
    }
    if tspec_ref is not None:
        basis["manuscript_spec_ref"] = mspec_ref
        basis["toolchain_spec_ref"] = tspec_ref
    basis["basis_sha256"] = core.sha256_object({k: v for k, v in basis.items()
                                                if k != "basis_sha256"})
    basis_rel = f"{renewal_rel}/renewal-basis.json"
    _write_json_bound(repo, basis_rel, basis, "basis_sha256", "renewal basis",
                      "PREPARE", "BASIS_DIGEST_MISMATCH")
    try:
        basis_file_sha = _sha_bytes(_read_bytes_bounded(repo, basis_rel, "renewal basis pin"))
        _validate_pinned_instance(repo, basis, basis_rel, basis_file_sha,
                                  RENEWAL_BASIS_SCHEMA, "Renewal Basis", "PREPARE",
                                  fail_code="BASIS_DIGEST_MISMATCH")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("BASIS_DIGEST_MISMATCH", "PREPARE", "PRESERVED_INCOMPLETE",
                    f"renewal basis schema invalid: {exc}") from exc
    try:
        authority = observe_renewal_authority(repo, state_path, basis_rel)
    except RenewalHighError as exc:
        raise _fail(exc.code, "PREPARE", "PRESERVED_INCOMPLETE",
                    f"post-capture pin recheck failed: {exc.detail}") from exc
    try:
        srcmod.validate_renewal_basis(repo, basis_rel)
    except Exception as exc:
        code = getattr(exc, "code", None) or "BASIS_DIGEST_MISMATCH"
        raise _fail(str(code), "PREPARE", "PRESERVED_INCOMPLETE",
                    f"detached basis validation failed: {exc}") from exc
    _ = authority
    return {"renewal_dir": renewal_rel, "basis_path": basis_rel,
            "retained_copy": {"path": retained_rel, "sha256": copy_info["sha256"]},
            "proposal_namespace": namespace, "requested": requested,
            "basis_sha256": basis["basis_sha256"]}


def _build_proof_object(repo: Path, basis: dict[str, Any], basis_rel: str,
                        entry: dict[str, Any], executor: str, ts: str) -> dict[str, Any]:
    """Construct the detached source proof via Layer-A accepted content.

    Calls the SOURCE module's accepted-authority loader by persisted path (fully
    reloaded every use; no caller dict/verified set). Propagates the SOURCE
    module's exact error codes (including the S-owned scope-row coordination
    refusal) without bypass or subset shortcut.
    """
    from scripts import survey_production_v2 as core
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    try:
        accepted = srcmod.load_renewal_accepted_authority(repo, basis_rel)
    except Exception as exc:
        code = getattr(exc, "code", None) or "BASIS_ACCEPTED_SET_DRIFT"
        raise _fail(str(code), "PROOF", "REFUSED_PRE_WRITE",
                    f"accepted-authority assembly failed: {exc}") from exc
    surface = accepted.get("surface")
    if not isinstance(surface, dict):
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PROOF", "REFUSED_PRE_WRITE",
                    "accepted surface missing")
    route = basis.get("generator_route")
    requested = basis.get("requested")
    # Style bytes source (ROOT clarification): U must compare CURRENT style
    # template bytes (current renderer style part, not generated text) to
    # retained trio.style. Current style changes under an allowed Core epoch
    # cause U REUSE_TARGET_MISMATCH (fresh C allowed), not a silent pass where
    # closure contains the new style while U keeps the old style. C renders
    # against the live template style; the new R trio style carries exactly
    # these bytes. Template path is the staged STYLE_PATH constant (pure path
    # constant, no P3S validator call). S Layer-B must compare the same current
    # style; if S needs a change, report the exact interface for root to
    # coordinate (do NOT edit S here).
    from scripts.survey_editorial_staged_source_v2 import STYLE_PATH as _style_path_const
    current_style_rel = _style_path_const.as_posix()
    current_style_data = _read_bytes_bounded(
        repo, _lexical_rel(repo, current_style_rel, "current style template"),
        "current style template")
    if requested == "REUSE_TARGETS":
        retained_style_path = basis_proof_trio_placeholder(repo, basis)["style"]["path"]
        retained_style_data = _read_bytes_bounded(
            repo, _lexical_rel(repo, retained_style_path, "retained trio style"),
            "retained trio style")
        if _sha_bytes(current_style_data) != _sha_bytes(retained_style_data):
            raise _fail("REUSE_TARGET_MISMATCH", "PROOF", "REFUSED_PRE_WRITE",
                        "current style template changed vs retained trio.style "
                        "(U keeps old style refuses; fresh C allowed; not merely "
                        "closure-contains-new-style while U keeps old)")
        style_rel = retained_style_path
        style_data = retained_style_data
    else:
        style_rel = current_style_rel
        style_data = current_style_data
    _ = style_rel
    if route == WEEKLY_ROUTE:
        reader_bytes = core.json_bytes(surface)
        from scripts.survey_weekly_derivation_v2 import (
            render_bibliography as _w_render_bib, render_main as _w_render_main,
            validate_generated_closure as _w_validate_closure)
        main_text = _w_render_main(surface)
        bib_text = _w_render_bib(surface)
        try:
            _w_validate_closure(main_text, style_data.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise _fail("REUSE_TARGET_MISMATCH", "PROOF", "REFUSED_PRE_WRITE",
                        f"current render closure invalid: {exc}") from exc
        reader_digest = _sha_bytes(reader_bytes)
        trio_digest = core.sha256_object({
            "primary": _sha_bytes(main_text.encode("utf-8")),
            "bibliography": _sha_bytes(bib_text.encode("utf-8")),
            "style": _sha_bytes(style_data)})
        rendered = {"primary": main_text.encode("utf-8"), "bibliography": bib_text.encode("utf-8"),
                    "style": style_data}
    elif route == LONGFORM_ROUTE:
        from scripts.survey_longform_derivation_v2 import (
            canonical_reader_bytes as _lf_bytes)
        from scripts.survey_longform_generated_v2 import (
            render_bibliography as _lf_render_bib, render_main as _lf_render_main,
            validate_generated_closure as _lf_validate_closure)
        reader_bytes = _lf_bytes(surface)
        main_text = _lf_render_main(surface)
        bib_text = _lf_render_bib(surface)
        try:
            _lf_validate_closure(main_text, style_data.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise _fail("REUSE_TARGET_MISMATCH", "PROOF", "REFUSED_PRE_WRITE",
                        f"current render closure invalid: {exc}") from exc
        reader_digest = _sha_bytes(reader_bytes)
        trio_digest = core.sha256_object({
            "primary": _sha_bytes(main_text.encode("utf-8")),
            "bibliography": _sha_bytes(bib_text.encode("utf-8")),
            "style": _sha_bytes(style_data)})
        rendered = {"primary": main_text.encode("utf-8"), "bibliography": bib_text.encode("utf-8"),
                    "style": style_data}
    else:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "PROOF", "REFUSED_PRE_WRITE",
                    f"unsupported route: {route}")
    return {"surface": surface, "reader_digest": reader_digest, "trio_digest": trio_digest,
            "rendered": rendered}


def basis_proof_trio_placeholder(repo: Path, basis: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """Resolve the proof trio location by request kind (paths only, no bytes claim).

    U reuses the immediate predecessor trio (prior-relative seal roles); C uses
    new R/ trio paths derived after proof. This helper returns the path triple
    the proof will bind; byte validation happens in Layer-B readback.
    """
    requested = basis.get("requested")
    if requested == "REUSE_TARGETS":
        prior_seal_rel = basis["prior_selected_ref"]["path"]
        seal = _strict_json_from_bytes(
            _read_bytes_bounded(repo, _lexical_rel(repo, prior_seal_rel, "prior seal"),
                                "prior seal"), "prior seal")
        roles = seal.get("roles", {})
        trio = {}
        for proof_key, role_name in (("primary", "validated-source"),
                                     ("bibliography", "bibliography"), ("style", "style")):
            fr = roles.get(role_name)
            if not isinstance(fr, dict):
                raise _fail("REVIEW_TARGET_MISMATCH", "PROOF", "REFUSED_PRE_WRITE",
                            f"prior seal lacks trio role: {role_name}")
            trio[proof_key] = {"path": str(fr["path"]), "sha256": str(fr.get("sha256", "")),
                               "byte_count": int(fr.get("byte_count", 0))}
        return trio
    namespace = basis.get("proposal_namespace", "")
    rid = basis.get("renewal_id", "")
    prefix = f"{namespace}/renewals/{rid}/staged-source"
    return {"primary": {"path": f"{prefix}/main.tex", "sha256": "", "byte_count": 0},
            "bibliography": {"path": f"{prefix}/references.bib", "sha256": "", "byte_count": 0},
            "style": {"path": f"{prefix}/jgaisurvey.sty", "sha256": "", "byte_count": 0}}


def _proof_paths_for_request(basis: dict[str, Any]) -> dict[str, str]:
    renewal_rel = f"{basis['proposal_namespace']}/renewals/{basis['renewal_id']}"
    return {
        "renewal_dir": renewal_rel,
        "proof": f"{renewal_rel}/renewal-source-proof.json",
        "receipt": f"{renewal_rel}/validated-source-manifest.json",
        "build_record": f"{renewal_rel}/build-record.json",
        "bundle": f"{renewal_rel}/quality-regression-bundle-v2.json",
        "gate": f"{renewal_rel}/reader-surface-gate-v2.json",
        "candidate": f"{renewal_rel}/publication-candidate-v2.json",
        "set": f"{renewal_rel}/publication-set.json",
        "manuscript": f"{renewal_rel}/reader-manuscript-v2.json",
    }


def prepare_renewal_targets(root: str | Path, basis_path: str | Path,
                             executor: str,
                             recorded_at: datetime | str | None = None) -> dict[str, Any]:
    """C-only pre-review build half (declared C preparation half, root-accepted):
    authority -> proof -> trio FILES -> C manuscript -> real disposable
    build/transfer -> build record -> receipt.

    Manuscript and build both exist before any external review, so the
    external reviewer (emulated by the fixture harness via the actual review
    builders, clearly labelled synthetic; genuine in production) can target
    the exact new manuscript/source/PDF. finalize_renewal then consumes the
    supplied postrender reviews + fresh QA inputs. U has no targets step
    (prior paths reused; finalize runs directly). Exclusive writes refuse on
    re-run (no takeover); retry uses a new renewal id.

    Root clarification: this entry is the declared C preparation half with
    full same authority checks (observe_renewal_authority + detached proof
    readbacks before/after receipt); no extra writes occur after external
    review; no new permission/bypass is introduced. Documented here without
    new authority.
    """
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    repo = Path(root).resolve()
    if not isinstance(executor, str) or not executor.strip():
        raise _fail("ARGS", "TARGETS", "REFUSED_PRE_WRITE", "executor required")
    ts = _now_utc(recorded_at)
    basis_rel = _lexical_rel(repo, str(basis_path), "renewal basis")
    authority = observe_renewal_authority(repo, _basis_state_path(repo, basis_rel), basis_rel)
    entry = authority["entry"]
    basis = authority["basis"]
    if basis.get("requested") != "RENDER_TARGETS":
        raise _fail("INTENT_MISMATCH", "TARGETS", "REFUSED_PRE_WRITE",
                    "targets step is C-only (U reuses prior targets via finalize)")
    paths = _proof_paths_for_request(basis)
    built = _build_proof_object(repo, basis, basis_rel, entry, executor.strip(), ts)
    proof = _assemble_new_proof(repo, basis, basis_rel, entry, built, executor.strip(), ts)
    proof_rel = paths["proof"]
    _write_json_bound(repo, proof_rel, proof, "proof_sha256", "renewal source proof",
                      "TARGETS", "RENEWAL_PROOF_DIGEST")
    try:
        proof_file_sha = _sha_bytes(_read_bytes_bounded(repo, proof_rel, "renewal proof pin"))
        _validate_pinned_instance(repo, proof, proof_rel, proof_file_sha,
                                  RENEWAL_PROOF_SCHEMA, "Renewal Source Proof", "TARGETS")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "TARGETS", "REFUSED_PRE_WRITE",
                    f"renewal proof schema invalid: {exc}") from exc
    # New trio FILES first: S Layer-B reads trio bytes live during proof
    # verification (FD-bound, no caller bytes). Manuscript/build/receipt follow
    # only after the proof verifies against the actual new targets.
    _write_new_trio_files(repo, proof, built)
    try:
        srcmod.verify_renewal_source_proof(repo, basis_rel, proof_rel)
    except Exception as exc:
        code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
        raise _fail(str(code), "TARGETS", "REFUSED_PRE_WRITE",
                    f"detached proof verification failed: {exc}") from exc
    build_record_rel = _render_and_build_new_targets(repo, basis, basis_rel, entry, proof,
                                                     proof_rel, built, executor.strip(), ts)
    receipt_rel = _write_renewal_receipt(repo, basis, basis_rel, entry, proof, proof_rel,
                                         build_record_rel, executor.strip(), ts)
    try:
        srcmod.verify_renewal_source_proof(repo, basis_rel, proof_rel)
    except Exception as exc:
        code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
        raise _fail(str(code), "TARGETS", "REFUSED_PRE_WRITE",
                    f"post-receipt proof revalidation failed: {exc}") from exc
    _ = core
    return {"proof_path": proof_rel, "receipt_path": receipt_rel,
            "build_record_path": build_record_rel,
            "manuscript_path": paths["manuscript"],
            "trio_paths": {k: v["path"] for k, v in proof["output_trio_refs"].items()},
            "proof_sha256": proof["proof_sha256"],
            "disposition": "NEW_TARGETS"}


def _basis_state_path(repo: Path, basis_rel: str) -> str:
    basis = _strict_json_from_bytes(
        _read_bytes_bounded(repo, basis_rel, "renewal basis"), "renewal basis")
    if not isinstance(basis, dict):
        raise _fail("BASIS_DIGEST_MISMATCH", "TARGETS", "REFUSED_PRE_WRITE",
                    "renewal basis must be an object")
    before = basis.get("before_state_ref", {})
    if not isinstance(before.get("path"), str):
        raise _fail("BASIS_DIGEST_MISMATCH", "TARGETS", "REFUSED_PRE_WRITE",
                    "renewal basis lacks before_state_ref")
    return str(before["path"])


def finalize_renewal(root: str | Path, state_path: str | Path, basis_path: str | Path,
                     checks_path: str | Path, semantic_review_path: str | Path | None,
                     visual_review_path: str | Path | None, executor: str,
                     recorded_at: datetime | str | None = None) -> dict[str, Any]:
    """Finalize: authority -> (U: proof -> build -> receipt | C: prebuilt
    reload) -> QA/Gate/Candidate -> seal.

    U (REUSE_TARGETS, validated only): semantic/visual args are either absent
    (derive exact predecessor record refs) or exact predecessor refs; a
    replacement review at a different path is never silently treated as reused.
    No new manuscript/PDF/build executable runs for U. C (RENDER_TARGETS):
    targets prebuilt by prepare_renewal_targets (proof/trio/manuscript/build/
    receipt reloaded + revalidated here, never rebuilt); then new external
    postrender reviews and actual QA inputs. Manuscript and build both exist
    before external review. Receipt binds the build record, so the receipt
    never precedes that record. finalize/validate-set MUST refuse a renewed
    set whose NEW Candidate/QA/Gate files lack the NEW proof ref with
    full-set SAME-proof equality (absence -> REVIEW_TARGET_MISMATCH, never a
    silent fallback to the embedded PRIOR proof).
    """
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    repo = Path(root).resolve()
    if not isinstance(executor, str) or not executor.strip():
        raise _fail("ARGS", "FINALIZE", "REFUSED_PRE_WRITE", "executor required")
    ts = _now_utc(recorded_at)
    basis_rel = _lexical_rel(repo, str(basis_path), "renewal basis")
    authority = observe_renewal_authority(repo, state_path, basis_rel)
    entry = authority["entry"]
    basis = authority["basis"]
    requested = basis.get("requested")
    paths = _proof_paths_for_request(basis)
    if requested == "REUSE_TARGETS":
        if semantic_review_path is not None or visual_review_path is not None:
            _check_supplied_review_is_predecessor(repo, basis, entry,
                                                  semantic_review_path, visual_review_path)
    else:
        if semantic_review_path is None or visual_review_path is None:
            raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                        "C renewal requires new external postrender semantic+visual reviews")
    if requested == "REUSE_TARGETS":
        built = _build_proof_object(repo, basis, basis_rel, entry, executor.strip(), ts)
        proof = _assemble_reused_proof(repo, basis, basis_rel, entry, built, executor.strip(), ts)
        proof_rel = paths["proof"]
        _write_json_bound(repo, proof_rel, proof, "proof_sha256", "renewal source proof",
                          "FINALIZE", "RENEWAL_PROOF_DIGEST")
        try:
            proof_file_sha = _sha_bytes(_read_bytes_bounded(repo, proof_rel, "renewal proof pin"))
            _validate_pinned_instance(repo, proof, proof_rel, proof_file_sha,
                                      RENEWAL_PROOF_SCHEMA, "Renewal Source Proof", "FINALIZE")
        except RenewalHighError:
            raise
        except (ValueError, OSError) as exc:
            raise _fail("RENEWAL_PROOF_DIGEST", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"renewal proof schema invalid: {exc}") from exc
        try:
            srcmod.verify_renewal_source_proof(repo, basis_rel, proof_rel)
        except Exception as exc:
            code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
            raise _fail(str(code), "FINALIZE", "REFUSED_PRE_WRITE",
                        f"detached proof verification failed: {exc}") from exc
        _verify_renewal_rerender_equality_inner(repo, basis, basis_rel, proof_rel, proof)
        build_record_rel = _write_reused_build_record(repo, basis, basis_rel, entry, proof,
                                                      proof_rel, executor.strip(), ts)
        receipt_rel = _write_renewal_receipt(repo, basis, basis_rel, entry, proof, proof_rel,
                                             build_record_rel, executor.strip(), ts)
        try:
            srcmod.verify_renewal_source_proof(repo, basis_rel, proof_rel)
        except Exception as exc:
            code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
            raise _fail(str(code), "FINALIZE", "REFUSED_PRE_WRITE",
                        f"post-receipt proof revalidation failed: {exc}") from exc
    else:
        # C: prebuilt targets reloaded + revalidated (never rebuilt here, never
        # trusted from memory). Missing targets refuse with an explicit code
        # directing to prepare_renewal_targets first.
        proof_rel = paths["proof"]
        for rel, name in ((proof_rel, "renewal source proof"),
                          (paths["manuscript"], "C manuscript"),
                          (_proof_paths_for_request(basis)["build_record"], "build record"),
                          (paths["receipt"], "renewal source receipt")):
            try:
                _read_bytes_bounded(repo, _lexical_rel(repo, rel, name), name)
            except RenewalHighError:
                raise _fail("BUILD_TARGETS_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                            f"C {name} not built (run prepare_renewal_targets first)") from None
        proof = _strict_json_from_bytes(
            _read_bytes_bounded(repo, proof_rel, "renewal source proof"), "renewal source proof")
        if not isinstance(proof, dict):
            raise _fail("RENEWAL_PROOF_DIGEST", "FINALIZE", "REFUSED_PRE_WRITE",
                        "renewal source proof must be an object")
        if core.sha256_object({k: v for k, v in proof.items() if k != "proof_sha256"}) \
                != proof.get("proof_sha256"):
            raise _fail("RENEWAL_PROOF_DIGEST", "FINALIZE", "REFUSED_PRE_WRITE",
                        "prebuilt proof self-digest mismatch")
        if proof.get("basis_ref") != _file_ref(repo, basis_rel, "prebuilt proof basis pin"):
            raise _fail("RENEWAL_PROOF_DIGEST", "FINALIZE", "REFUSED_PRE_WRITE",
                        "prebuilt proof does not bind this basis (FILE SHA)")
        try:
            srcmod.verify_renewal_source_proof(repo, basis_rel, proof_rel)
        except Exception as exc:
            code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
            raise _fail(str(code), "FINALIZE", "REFUSED_PRE_WRITE",
                        f"prebuilt proof readback failed: {exc}") from exc
        build_record_rel = _proof_paths_for_request(basis)["build_record"]
        receipt_rel = paths["receipt"]
        try:
            receipt_check = validate_renewal_receipt(repo, receipt_rel)
        except RenewalHighError:
            raise
        except Exception as exc:
            code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
            raise _fail(str(code), "FINALIZE", "REFUSED_PRE_WRITE",
                        f"prebuilt receipt invalid: {exc}") from exc
        _ = receipt_check
    bundle_rel, gate_rel, candidate_rel = _write_qa_gate_candidate(
        repo, basis, basis_rel, entry, proof, proof_rel, receipt_rel, paths,
        checks_path, semantic_review_path, visual_review_path, executor.strip(), ts)
    set_rel = _write_renewal_seal(repo, basis, basis_rel, entry, proof, proof_rel, receipt_rel,
                                  build_record_rel, bundle_rel, gate_rel, candidate_rel,
                                  executor.strip(), ts)
    validated = validate_prepared_renewal_set(repo, state_path, set_rel)
    _ = validated
    return {"set_path": set_rel, "proof_path": proof_rel, "receipt_path": receipt_rel,
            "build_record_path": build_record_rel, "bundle_path": bundle_rel,
            "gate_path": gate_rel, "candidate_path": candidate_rel,
            "disposition": proof["comparison"]["disposition"]}


def _check_supplied_review_is_predecessor(repo: Path, basis: dict[str, Any],
                                          entry: dict[str, Any],
                                          semantic_path: str | Path | None,
                                          visual_path: str | Path | None) -> None:
    """U with explicit review args: each must equal the exact predecessor record
    ref (same path+SHA as the prior seal's semantic/visual roles). A replacement
    review at a different path is never silently treated as reused."""
    from scripts import survey_production_v2 as core
    prior_seal_rel = basis["prior_selected_ref"]["path"]
    seal = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, prior_seal_rel, "prior seal"),
                            "prior seal"), "prior seal")
    roles = seal.get("roles", {})
    for arg, role_name in ((semantic_path, "semantic-review"), (visual_path, "visual-review")):
        if arg is None:
            continue
        rel = _lexical_rel(repo, str(arg), f"supplied {role_name}")
        data = _read_bytes_bounded(repo, rel, f"supplied {role_name}")
        role = roles.get(role_name)
        if not isinstance(role, dict) or role.get("path") != rel \
                or role.get("sha256") != _sha_bytes(data):
            raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"supplied U {role_name} is not the exact predecessor record "
                        f"(replacement reviews at different paths refuse)")


def _assemble_reused_proof(repo: Path, basis: dict[str, Any], basis_rel: str,
                           entry: dict[str, Any], built: dict[str, Any],
                           executor: str, ts: str) -> dict[str, Any]:
    """U proof: exact immediate-predecessor targets, older embedded producer
    history carried opaquely (HIST lineage, never current authority)."""
    from scripts import survey_production_v2 as core
    trio_paths = basis_proof_trio_placeholder(repo, basis)
    trio_refs: dict[str, Any] = {}
    for key in ("primary", "bibliography", "style"):
        data = _read_bytes_bounded(repo, _lexical_rel(repo, trio_paths[key]["path"],
                                                      f"prior trio {key}"), f"prior trio {key}")
        trio_refs[key] = {"path": trio_paths[key]["path"], "sha256": _sha_bytes(data),
                          "byte_count": len(data)}
    if trio_refs["primary"]["sha256"] != _sha_bytes(built["rendered"]["primary"]) \
            or trio_refs["bibliography"]["sha256"] != _sha_bytes(built["rendered"]["bibliography"]) \
            or trio_refs["style"]["sha256"] != _sha_bytes(built["rendered"]["style"]):
        raise _fail("REUSE_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "current renderer/style does not yield exactly the old trio "
                    "(no auto-switch to C on a claimed U root)")
    prior_seal = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, basis["prior_selected_ref"]["path"],
                                               "prior seal"), "prior seal"), "prior seal")
    roles = prior_seal.get("roles", {})
    man_role = roles.get("reader-manuscript")
    if not isinstance(man_role, dict):
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "prior seal lacks reader-manuscript role")
    man_rel = _lexical_rel(repo, str(man_role["path"]), "prior manuscript")
    man_data = _read_bytes_bounded(repo, man_rel, "prior manuscript")
    old_manuscript_ref = {"path": man_rel, "sha256": _sha_bytes(man_data),
                          "byte_count": len(man_data)}
    build_unit: dict[str, Any] = {}
    for role_name, build_key in (("publication-pdf", "pdf"),
                                   ("build-log", "log"),
                                   ("pdf-digest", "digest")):
        fr = roles.get(role_name)
        if not isinstance(fr, dict):
            raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"prior seal lacks build role: {role_name}")
        brel = _lexical_rel(repo, str(fr["path"]), f"prior build {build_key}")
        bdata = _read_bytes_bounded(repo, brel, f"prior build {build_key}")
        ref: dict[str, Any] = {"path": brel, "sha256": _sha_bytes(bdata),
                               "byte_count": len(bdata)}
        if build_key == "pdf":
            try:
                import io
                from pypdf import PdfReader
                ref["page_count"] = len(PdfReader(io.BytesIO(bdata)).pages)
            except Exception as exc:
                raise _fail("REUSE_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                            f"prior PDF page count unreadable: {exc}") from exc
            if ref["page_count"] < 1:
                raise _fail("REUSE_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                            "prior PDF page count invalid")
        build_unit[build_key] = ref
    old_record = _locate_prior_build_record(repo, basis, prior_seal)
    build_unit["record"] = old_record
    proof: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_SOURCE_PROOF_V1",
        "basis_ref": _file_ref(repo, basis_rel, "REUSED proof basis pin"),
        "issue_id": basis["issue_id"], "research_profile": basis["research_profile"],
        "publication_profile": basis["publication_profile"],
        "generator_route": basis["generator_route"],
        "reviewed_reader_ref": dict(basis["reviewed_reader_ref"]),
        "authoring_refs": [dict(r) for r in basis["authoring_refs"]],
        "accepted_refs": [dict(r) for r in basis["accepted_refs"]],
        "supported_contract": dict(basis["current_tool_epoch"]["contract"]),
        "supported_source_bindings": [dict(b) for b in basis["observed_source_bindings"]],
        "dependency_closure": [dict(r) for r in basis["current_tool_epoch"]["closure"]],
        "output_trio_refs": trio_refs,
        "reader_digest": built["reader_digest"], "trio_digest": built["trio_digest"],
        "comparison": {"reader_equal": True, "trio_equal": True,
                       "disposition": "REUSED_TARGETS"},
        "old_manuscript_ref": old_manuscript_ref, "old_build_unit_refs": build_unit,
        "executor": executor, "recorded_at": ts,
    }
    proof["proof_sha256"] = core.sha256_object({k: v for k, v in proof.items()
                                                if k != "proof_sha256"})
    return proof


def _resolve_reused_terminal_record(repo: Path, basis: dict[str, Any]) -> dict[str, str]:
    """Terminal activation record for a REUSED_BUILD wrapper (HIST chain anchor).

    The R build record's original_record_ref must be a chain ACTIVATION record
    (not a build-record.json): EDITORIAL terminal for first-U, or the VERSIONED
    record whose build is EXECUTED terminal for repeats (older reachable
    ancestor, skipping intermediate REUSED records, e.g. U3 -> R1). Bounded 32
    hops, same issue, no cycles. This is the writer-side terminal resolution;
    H walks from it to the terminal build at verify time.
    """
    issue = basis.get("issue_id")
    rec_ref = basis.get("prior_record_ref")
    if not isinstance(rec_ref, dict):
        raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                    "prior record ref missing for terminal resolution")
    current = {"path": str(rec_ref.get("path", "")), "sha256": str(rec_ref.get("sha256", ""))}
    seen: set[str] = set()
    for _ in range(CHAIN_LIMIT):
        if current["path"] in seen:
            raise _fail("HISTORY_ANCESTOR", "BUILD", "REFUSED_PRE_WRITE",
                        "terminal resolution cycle (no REUSED loops)")
        seen.add(current["path"])
        data = _read_bytes_bounded(repo, _lexical_rel(repo, current["path"],
                                                      "terminal candidate record"),
                                   "terminal candidate record")
        if _sha_bytes(data) != current["sha256"]:
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        "terminal candidate record bytes changed")
        doc = _strict_json_from_bytes(data, "terminal candidate record")
        if not isinstance(doc, dict):
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        "terminal candidate record must be an object")
        if doc.get("issue_id") != issue:
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        "terminal candidate record issue mismatch (foreign lineage)")
        kind = doc.get("kind")
        if kind == "EDITORIAL_PUBLICATION_ACTIVATION_V1":
            return dict(current)
        if kind != "VERSIONED_RENEWAL_ACTIVATION_V1":
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        f"terminal candidate record kind unsupported: {kind}")
        set_ref = doc.get("set_ref", {})
        seal_data = _read_bytes_bounded(repo, _lexical_rel(repo, str(set_ref.get("path", "")),
                                                           "terminal candidate seal"),
                                        "terminal candidate seal")
        seal = _strict_json_from_bytes(seal_data, "terminal candidate seal")
        build_ref = (seal.get("build_record_ref") or {}) if isinstance(seal, dict) else {}
        build_data = _read_bytes_bounded(repo, _lexical_rel(repo, str(build_ref.get("path", "")),
                                                           "terminal candidate build"),
                                         "terminal candidate build")
        build = _strict_json_from_bytes(build_data, "terminal candidate build")
        if not isinstance(build, dict):
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        "terminal candidate build must be an object")
        variant = build.get("variant")
        if variant == "EXECUTED_BUILD":
            return dict(current)
        if variant != "REUSED_BUILD":
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        f"terminal candidate build variant unsupported: {variant}")
        nxt = build.get("original_record_ref", {})
        if not isinstance(nxt, dict):
            raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                        "intermediate REUSED record lacks onward terminal ref")
        current = {"path": str(nxt.get("path", "")), "sha256": str(nxt.get("sha256", ""))}
    raise _fail("HISTORY_ANCESTOR", "BUILD", "REFUSED_PRE_WRITE",
                "terminal resolution exceeds chain bound 32")


def _locate_prior_build_record(repo: Path, basis: dict[str, Any],
                               prior_seal: dict[str, Any]) -> dict[str, str]:
    """Immediate prior build record (prior-relative, never original-P fallback).

    For an editorial predecessor it is P/publication/build-record.json located
    via the prior receipt's build binding; for a renewal predecessor it is the
    prior R/build-record.json located via the prior proof's build binding. The
    REUSED chain is walked historically to the terminal EXECUTED/EDITORIAL
    build only in Layer-B readback; here the immediate record is pinned.
    """
    prior_selected = basis["prior_selected_ref"]["path"]
    roles = prior_seal.get("roles", {})
    receipt_role = roles.get("source-receipt", {})
    receipt = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, str(receipt_role.get("path", "")),
                                               "prior receipt"), "prior receipt"),
        "prior receipt") if isinstance(receipt_role, dict) else {}
    candidates: list[str] = []
    if isinstance(receipt, dict):
        for key in ("build_record_ref", "build_record"):
            ref = receipt.get(key)
            if isinstance(ref, dict) and isinstance(ref.get("path"), str):
                candidates.append(str(ref["path"]))
    seal_dir = str(Path(prior_selected).parent.as_posix())
    candidates.append(f"{seal_dir}/build-record.json")
    for cand in candidates:
        try:
            rel = _lexical_rel(repo, cand, "prior build record")
            data = _read_bytes_bounded(repo, rel, "prior build record")
        except RenewalHighError:
            continue
        return {"path": rel, "sha256": _sha_bytes(data)}
    raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                "immediate prior build record not found (no original-P fallback)")


def _assemble_new_proof(repo: Path, basis: dict[str, Any], basis_rel: str,
                        entry: dict[str, Any], built: dict[str, Any],
                        executor: str, ts: str) -> dict[str, Any]:
    """C proof: new trio/current proof at new R paths (no forged P3S manifest)."""
    from scripts import survey_production_v2 as core
    namespace = basis["proposal_namespace"]
    rid = basis["renewal_id"]
    prefix = f"{namespace}/renewals/{rid}/staged-source"
    trio_refs: dict[str, Any] = {}
    for key, filename, rendered_key in (("primary", "main.tex", "primary"),
                                        ("bibliography", "references.bib", "bibliography"),
                                        ("style", "jgaisurvey.sty", "style")):
        data = built["rendered"][rendered_key]
        _lexical_rel(repo, f"{prefix}/{filename}", f"new trio {key}")
        trio_refs[key] = {"path": f"{prefix}/{filename}", "sha256": _sha_bytes(data),
                          "byte_count": len(data)}
    proof: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_SOURCE_PROOF_V1",
        "basis_ref": _file_ref(repo, basis_rel, "NEW proof basis pin"),
        "issue_id": basis["issue_id"], "research_profile": basis["research_profile"],
        "publication_profile": basis["publication_profile"],
        "generator_route": basis["generator_route"],
        "reviewed_reader_ref": dict(basis["reviewed_reader_ref"]),
        "authoring_refs": [dict(r) for r in basis["authoring_refs"]],
        "accepted_refs": [dict(r) for r in basis["accepted_refs"]],
        "supported_contract": dict(basis["current_tool_epoch"]["contract"]),
        "supported_source_bindings": [dict(b) for b in basis["observed_source_bindings"]],
        "dependency_closure": [dict(r) for r in basis["current_tool_epoch"]["closure"]],
        "output_trio_refs": trio_refs,
        "reader_digest": built["reader_digest"], "trio_digest": built["trio_digest"],
        "comparison": {"reader_equal": True, "trio_equal": False,
                       "disposition": "NEW_TARGETS"},
        "executor": executor, "recorded_at": ts,
    }
    proof["proof_sha256"] = core.sha256_object({k: v for k, v in proof.items()
                                                if k != "proof_sha256"})
    return proof


def _validate_build_record_container(repo: Path, rel: str, label: str) -> dict[str, Any]:
    """Validate an R/build-record.json against the embedded #/$defs/buildRecord
    container (fixed 4 schemas kept: the container lives in the renewal source
    manifest schema file, never a 5th schema). The host file is loaded through
    the pinned strict schema loader; inner #/$defs refs resolve against the
    inlined host defs (same bytes, no remote fetch, no new file)."""
    from scripts import survey_schema_v2 as schema_gate
    import jsonschema
    try:
        host_schema_bytes = _read_bytes_bounded(repo, RENEWAL_RECEIPT_SCHEMA, "build container host schema")
        host = schema_gate.load_schema(repo / RENEWAL_RECEIPT_SCHEMA)
        if _sha_bytes(_read_bytes_bounded(repo, RENEWAL_RECEIPT_SCHEMA, "build container host recheck")) != _sha_bytes(host_schema_bytes):
            raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                        "build container host schema moved during load")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    f"build container host schema unreadable: {exc}") from exc
    if not isinstance(host.get("$defs"), dict) or "buildRecord" not in host["$defs"]:
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    "build container host lacks #/$defs/buildRecord")
    wrapper = {"$schema": host.get("$schema",
                                  "https://json-schema.org/draft/2020-12/schema"),
               "$defs": host["$defs"], "$ref": "#/$defs/buildRecord"}
    try:
        jsonschema.Draft202012Validator.check_schema(wrapper)
    except jsonschema.exceptions.SchemaError as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    f"build container wrapper invalid: {exc.message}") from exc
    raw = _read_bytes_bounded(repo, _lexical_rel(repo, rel, label), label)
    doc = _strict_json_from_bytes(raw, label)
    if not isinstance(doc, dict):
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    f"{label} must be an object")
    validator = jsonschema.Draft202012Validator(wrapper,
                                                 format_checker=jsonschema.FormatChecker())
    errors = sorted(validator.iter_errors(doc),
                    key=lambda err: (list(err.absolute_path), err.message))
    if errors:
        first = errors[0]
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    f"{label} fails #/$defs/buildRecord: {first.message}") from None
    return doc


def _file_ref(repo: Path, rel: str, label: str) -> dict[str, str]:
    """Live file ref {path, sha256} with FILE bytes SHA.

    Convention (binding, selected contract §11.2): EVERY cross-document
    `{path,sha256}` ref carries the FILE bytes SHA — including
    `proof.basis_ref` (ROOT binding, no SELF exception, no dual field, no
    either-tolerance). Object self-digests (basis_sha256/proof_sha256/...)
    are always recomputed from reparsed bytes, never equated to file SHAs.
    """
    rrel = _lexical_rel(repo, rel, label)
    return {"path": rrel, "sha256": _sha_bytes(_read_bytes_bounded(repo, rrel, label))}


def _write_reused_build_record(repo: Path, basis: dict[str, Any], basis_rel: str,
                               entry: dict[str, Any], proof: dict[str, Any],
                               proof_rel: str, executor: str, ts: str) -> str:
    """U-only REUSED_BUILD wrapper: no rebuild, original unit pinned, no new
    TeX build invented. Receipt binds this record, never precedes it."""
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    old_build = proof["old_build_unit_refs"]
    # Terminal activation record anchor (HIST chain): EDITORIAL terminal for
    # first-U, EXECUTED-terminal VERSIONED record for repeats (older reachable
    # ancestor, skipping intermediate REUSED records). This is the R build
    # record's original_record_ref; the proof's old_build_unit_refs.record
    # remains the immediate prior build-record.json (S checks its bytes).
    terminal_ref = _resolve_reused_terminal_record(repo, basis)
    record_data = _read_bytes_bounded(repo, _lexical_rel(repo, terminal_ref["path"],
                                                         "terminal build record"),
                                      "terminal build record")
    if _sha_bytes(record_data) != terminal_ref["sha256"]:
        raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                    "terminal record bytes changed")
    old_epoch = _derive_old_tool_epoch(repo, basis)
    record: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_BUILD_V1",
        "variant": "REUSED_BUILD", "issue_id": basis["issue_id"],
        "proposal_ref": dict(basis["original_proposal_ref"]),
        "renewal_basis_ref": _file_ref(repo, basis_rel, "REUSED renewal basis"),
        "renewal_proof_ref": _file_ref(repo, proof_rel, "REUSED renewal proof"),
        "recipe_ref": {"path": ".latexmkrc",
                       "sha256": _sha_bytes(_read_bytes_bounded(repo, ".latexmkrc",
                                                                "build recipe"))},
        "recorded_at": ts,
        "original_record_ref": dict(terminal_ref),
        "original_pdf_ref": dict(old_build["pdf"]),
        "original_log_ref": {k: old_build["log"][k] for k in ("path", "sha256", "byte_count")},
        "original_digest_ref": {k: old_build["digest"][k]
                                for k in ("path", "sha256", "byte_count")},
        "renewal_tools": {"old": old_epoch, "new": basis["current_tool_epoch"]["repository_commit_sha"]},
        "no_rebuild": True,
    }
    record["build_sha256"] = core.sha256_object({k: v for k, v in record.items()
                                                 if k != "build_sha256"})
    rel = _proof_paths_for_request(basis)["build_record"]
    _write_json_bound(repo, rel, record, "build_sha256", "renewal build record",
                      "BUILD", "RENEWAL_PROOF_DIGEST")
    _validate_build_record_container(repo, rel, "Renewal Build Record")
    return rel


def _derive_old_tool_epoch(repo: Path, basis: dict[str, Any]) -> str:
    """Old tool epoch for the REUSED wrapper: the staged producer head of the
    immediate predecessor (editorial) or the prior basis CURRENT epoch
    (renewal predecessor). Derived from history-graph fields, never caller."""
    from scripts import survey_versioned_renewal_history_v2 as hist
    try:
        verdict = hist.verify_versioned_history(repo, basis["prior_record_ref"]["path"])
    except Exception as exc:
        code = getattr(exc, "code", None) or "HISTORY_DIGEST_MISMATCH"
        raise _fail(str(code), "BUILD", "REFUSED_PRE_WRITE",
                    f"old epoch history invalid: {exc}") from exc
    lineage = verdict.get("materialization_lineage", [])
    if lineage:
        last = lineage[-1]
        for key in ("staged_producer_head", "receipt_epoch", "basis_current_epoch"):
            value = last.get(key)
            if isinstance(value, str) and len(value) == 40 \
                    and all(c in "0123456789abcdef" for c in value):
                return value
    prior_seal = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, basis["prior_selected_ref"]["path"],
                                               "prior seal"), "prior seal"), "prior seal")
    receipt_role = (prior_seal.get("roles", {}) or {}).get("source-receipt", {})
    receipt = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, str(receipt_role.get("path", "")),
                                               "prior receipt"), "prior receipt"),
        "prior receipt")
    tools = receipt.get("current_tools", {}) if isinstance(receipt, dict) else {}
    epoch = tools.get("repository_commit_sha", "")
    if not _is_gitsha(epoch):
        raise _fail("HISTORY_TOOL_EPOCH_DRIFT", "BUILD", "REFUSED_PRE_WRITE",
                    "old tool epoch underivable from prior receipt")
    return str(epoch)


def _write_new_trio_files(repo: Path, proof: dict[str, Any],
                           built: dict[str, Any]) -> None:
    """Exclusive write of new R trio FILES from rendered bytes (C only)."""
    trio = proof["output_trio_refs"]
    for key, rendered_key in (("primary", "primary"), ("bibliography", "bibliography"),
                              ("style", "style")):
        _atomic_write_new(repo, str(trio[key]["path"]), built["rendered"][rendered_key],
                          f"new trio {key}")


def _render_and_build_new_targets(repo: Path, basis: dict[str, Any], basis_rel: str,
                                  entry: dict[str, Any], proof: dict[str, Any],
                                  proof_rel: str, built: dict[str, Any],
                                  executor: str, ts: str) -> str:
    """C-only: write new trio FILES, C manuscript, real disposable TL build and
    transfer, EXECUTED_BUILD record. Manuscript and build both exist before any
    external review. Uses the source proof, never a forged P3S manifest."""
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_reader_publication_v2 as reader_pub
    trio = proof["output_trio_refs"]
    # Trio FILES already exist (written before proof verification); re-verify
    # bytes against the rendered inputs (no overwrite, no takeover).
    for key, rendered_key in (("primary", "primary"), ("bibliography", "bibliography"),
                              ("style", "style")):
        live = _read_bytes_bounded(repo, _lexical_rel(repo, str(trio[key]["path"]),
                                                      f"new trio {key}"), f"new trio {key}")
        if live != built["rendered"][rendered_key]:
            raise _fail("INPUT_DRIFT", "BUILD", "REFUSED_PRE_WRITE",
                        f"new trio bytes drift before build: {key}")
    proof_ref = _file_ref(repo, proof_rel, "C renewal proof")
    manuscript_rel = _proof_paths_for_request(basis)["manuscript"]
    _build_renewal_manuscript(repo, basis, entry, built, proof_ref, manuscript_rel)
    build_outputs = _execute_disposable_build(repo, basis, trio)
    record: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_BUILD_V1",
        "variant": "EXECUTED_BUILD", "issue_id": basis["issue_id"],
        "proposal_ref": dict(basis["original_proposal_ref"]),
        "renewal_basis_ref": _file_ref(repo, basis_rel, "EXECUTED renewal basis"),
        "renewal_proof_ref": dict(proof_ref),
        "recipe_ref": {"path": ".latexmkrc",
                       "sha256": _sha_bytes(_read_bytes_bounded(repo, ".latexmkrc",
                                                                "build recipe"))},
        "recorded_at": ts,
        "declared_inputs": {
            "primary": {"path": trio["primary"]["path"], "sha256": trio["primary"]["sha256"]},
            "bibliography": {"path": trio["bibliography"]["path"],
                             "sha256": trio["bibliography"]["sha256"]},
            "style": {"path": trio["style"]["path"], "sha256": trio["style"]["sha256"]},
        },
        "recipe": {"fixed_steps": list(build_outputs["fixed_steps"])},
        "toolchain": build_outputs["toolchain"],
        "outputs": build_outputs["outputs"],
        "exit_code": 0,
    }
    record["build_sha256"] = core.sha256_object({k: v for k, v in record.items()
                                                 if k != "build_sha256"})
    rel = _proof_paths_for_request(basis)["build_record"]
    _write_json_bound(repo, rel, record, "build_sha256", "renewal build record",
                      "BUILD", "RENEWAL_PROOF_DIGEST")
    _validate_build_record_container(repo, rel, "Renewal Build Record")
    return rel


def _build_renewal_manuscript(repo: Path, basis: dict[str, Any], entry: dict[str, Any],
                              built: dict[str, Any], proof_ref: dict[str, str],
                              manuscript_rel: str) -> None:
    """C manuscript carrying the mutually exclusive renewal_source ref to the
    source proof (XOR with editorial_source; never edits an old manuscript)."""
    from scripts import survey_reader_publication_v2 as reader_pub
    from datetime import datetime
    prior_seal = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, basis["prior_selected_ref"]["path"],
                                               "prior seal"), "prior seal"), "prior seal")
    prior_man_path = str((prior_seal.get("roles", {}) or {}).get("reader-manuscript", {})
                         .get("path", ""))
    if not prior_man_path:
        raise _fail("REVIEW_TARGET_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                    "prior seal lacks reader-manuscript role")
    prior_man = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, prior_man_path, "prior manuscript"),
                            "prior manuscript"), "prior manuscript")
    # C manuscript binds the NEW R trio (proof output trio), keeping the prior
    # manuscript's authority/coverage/requirement fields (same reader). It must
    # NOT bind old trio paths (that would be U, not C). Trio paths derive from
    # the basis namespace/id (same formula as the C proof assembly).
    _trio_prefix = f"{basis['proposal_namespace']}/renewals/{basis['renewal_id']}/staged-source"
    new_trio = {"primary": f"{_trio_prefix}/main.tex",
                "bibliography": f"{_trio_prefix}/references.bib",
                "style": f"{_trio_prefix}/jgaisurvey.sty"}
    try:
        reader_pub.build_manuscript_manifest(
            repo, str(basis["issue_id"]),
            repo / str((prior_man.get("production_profile") or {}).get("path", "")),
            repo / str((prior_man.get("architecture") or {}).get("path", "")),
            repo / str((prior_man.get("architecture_approval") or {}).get("path", "")),
            repo / str(new_trio["primary"]),
            [{"role": "BIBLIOGRAPHY", "path": str(new_trio["bibliography"])},
             {"role": "STYLE", "path": str(new_trio["style"])}],
            list(prior_man.get("architecture_coverage", [])),
            list(prior_man.get("reader_requirements", [])),
            str(prior_man.get("authored_by", "renewal")),
            datetime.fromisoformat(ts_now()),
            repo / manuscript_rel,
            renewal_source=dict(proof_ref),
        )
    except TypeError as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    "manuscript builder lacks the renewal_source branch "
                    "(consumer integration required): "
                    f"{exc}") from exc
    except ValueError as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "BUILD", "REFUSED_PRE_WRITE",
                    f"C manuscript build refused: {exc}") from exc


def ts_now() -> str:
    return _now_utc(None)


def _resolve_toolchain_executable(exe: Path, label: str) -> tuple[Path, Path, str]:
    try:
        link = exe if not exe.is_symlink() else Path(os.readlink(str(exe)))
        real = exe.resolve()
        if not real.is_file():
            raise RenewalHighError("TOOLCHAIN_EXE", f"{label} not a file: {exe}",
                                   phase="BUILD", disposition="REFUSED_PRE_WRITE")
        digest = _sha_bytes(real.read_bytes())
    except OSError as exc:
        raise _fail("TOOLCHAIN_EXE", "BUILD", "REFUSED_PRE_WRITE",
                    f"{label} unresolvable: {exe}: {exc}") from exc
    return exe, real, digest


def _execute_disposable_build(repo: Path, basis: dict[str, Any],
                              trio: dict[str, Any]) -> dict[str, Any]:
    """Real disposable TL build + exclusive transfer + readback (C only).

    Selected actual executable under the fixed recipe; executable/recipe
    evidence rechecked, never synthesized. Build auxiliaries stay disposable;
    outputs transfer exclusively into R/build/ with readback.
    """
    import tempfile
    from scripts import survey_editorial_publication_v2 as edpub
    tspec_ref = basis.get("toolchain_spec_ref")
    if not isinstance(tspec_ref, dict):
        raise _fail("INTENT_MISMATCH", "BUILD", "REFUSED_PRE_WRITE",
                    "C build requires the explicit toolchain spec")
    tspec = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, str(tspec_ref["path"]), "toolchain spec"),
                            "toolchain spec"), "toolchain spec")
    exe_raw = tspec.get("absolute_executable", "")
    if not isinstance(exe_raw, str) or not exe_raw or "\\" in exe_raw:
        raise _fail("TOOLCHAIN_EXE", "BUILD", "REFUSED_PRE_WRITE",
                    "toolchain executable must be a non-empty absolute string")
    exe = Path(exe_raw)
    if not exe.is_absolute() or ".." in exe.parts or "." in exe.parts:
        raise _fail("TOOLCHAIN_EXE", "BUILD", "REFUSED_PRE_WRITE", "toolchain executable unsafe")
    _link, _real, _real_sha = _resolve_toolchain_executable(exe, "toolchain executable")
    recipe = tspec.get("recipe", "")
    if recipe == "lualatex-biber-lualatex":
        expected_argv = list(edpub.EXPECTED_ARGV_LUALATEX_BIBER)
        cmds = [
            [str(exe), "-synctex=1", "-interaction=nonstopmode", "-file-line-error",
             "-halt-on-error", "main.tex"],
            [str(exe.parent / "biber"), "main"],
            [str(exe), "-synctex=1", "-interaction=nonstopmode", "-file-line-error",
             "-halt-on-error", "main.tex"],
            [str(exe), "-synctex=1", "-interaction=nonstopmode", "-file-line-error",
             "-halt-on-error", "main.tex"],
        ]
    elif recipe == "latexmk-lualatex":
        expected_argv = list(edpub.EXPECTED_ARGV_LATEXMK)
        cmds = [[str(exe.parent / "latexmk"), "-pdf", "-lualatex",
                 "-interaction=nonstopmode", "main.tex"]]
    else:
        raise _fail("TOOLCHAIN_RECIPE", "BUILD", "REFUSED_PRE_WRITE",
                    f"unsupported recipe: {recipe!r}")
    if list(tspec.get("argv", [])) != expected_argv:
        raise _fail("TOOLCHAIN_ARGV", "BUILD", "REFUSED_PRE_WRITE",
                    "toolchain spec argv must EXACTLY equal the fixed recipe tuple")
    env = tspec.get("env", {})
    if not isinstance(env, dict):
        raise _fail("TOOLCHAIN_ENV", "BUILD", "REFUSED_PRE_WRITE", "toolchain env must be object")
    for key, val in env.items():
        if key not in edpub.ALLOWED_ENV_KEYS or key.startswith("GIT_") \
                or key in ("PATH", "PYTHONPATH", "LD_LIBRARY_PATH") \
                or not isinstance(val, str) or "\n" in val or "\x00" in val:
            raise _fail("TOOLCHAIN_ENV", "BUILD", "REFUSED_PRE_WRITE",
                        f"toolchain env refused: {key}")
    recipe_bytes = _read_bytes_bounded(repo, ".latexmkrc", "build recipe")
    recipe_text = recipe_bytes.decode("utf-8")
    for marker in edpub.REQUIRED_RECIPE_MARKERS:
        if marker not in recipe_text:
            raise _fail("RECIPE_INCONSISTENT", "BUILD", "REFUSED_PRE_WRITE",
                        f"recipe missing marker: {marker}")
    controlled = {"PATH": str(exe.parent) + ":" + edpub.CONTROLLED_SYSTEM_PATH_SUFFIX}
    try:
        proc = subprocess.run([str(exe), "--version"], capture_output=True, text=True,
                              timeout=60, env=controlled)
        versions: dict[str, Any] = {
            "stdout": (proc.stdout or "")[:8000], "stderr": (proc.stderr or "")[:8000],
            "returncode": proc.returncode, "link_path": str(_link),
            "real_path": str(_real), "real_sha256": _real_sha}
    except Exception as exc:
        versions = {"stdout": "", "stderr": "", "returncode": 1,
                    "link_path": str(_link), "real_path": str(_real),
                    "real_sha256": _real_sha, "error": str(exc)[:500]}
    # Companion evidence DIRECTLY in toolchain.versions (H schema pins explicit
    # biber_*/latexmk_* fields, present-vs-_error exactly): required companion
    # is biber for the direct recipe and latexmk for the latexmk recipe; a
    # missing/stale required companion or a failed executable probe refuses
    # here (HIGH current probing), never surfacing later as history drift.
    # Non-required companion absence is recorded as _error (schema-tolerated).
    required_companion = "biber" if recipe == "lualatex-biber-lualatex" else "latexmk"
    for companion in ("biber", "latexmk"):
        cand = exe.parent / companion
        try:
            _c_link, _c_real, _c_sha = _resolve_toolchain_executable(cand, companion)
            cp = subprocess.run([str(cand), "--version"], capture_output=True, text=True,
                                timeout=60, env=controlled)
            if cp.returncode != 0:
                raise _fail("TOOLCHAIN_COMPANION", "BUILD", "REFUSED_PRE_WRITE",
                            f"companion probe failed ({cp.returncode}): {companion}") from None
            versions[f"{companion}_stdout"] = (cp.stdout or "")[:4000]
            versions[f"{companion}_returncode"] = cp.returncode
            versions[f"{companion}_link_path"] = str(_c_link)
            versions[f"{companion}_real_path"] = str(_c_real)
            versions[f"{companion}_real_sha256"] = _c_sha
        except RenewalHighError as exc:
            if companion == required_companion:
                raise
            versions[f"{companion}_error"] = f"{exc.code}: {exc.detail}"[:300]
        except Exception as exc:
            if companion == required_companion:
                raise _fail("TOOLCHAIN_COMPANION", "BUILD", "REFUSED_PRE_WRITE",
                            f"required companion missing/stale for {recipe}: "
                            f"{companion}: {exc}") from exc
            versions[f"{companion}_error"] = str(exc)[:300]
    if versions.get("returncode") != 0:
        raise _fail("TOOLCHAIN_EXE", "BUILD", "REFUSED_PRE_WRITE",
                    "toolchain executable probe failed (stale executable refuses)")
    tmp = Path(tempfile.mkdtemp(prefix="renewal-build-"))
    try:
        inputs: dict[str, bytes] = {}
        for label, key, dest in (("main", "primary", "main.tex"),
                                 ("bibliography", "bibliography", "references.bib"),
                                 ("style", "style", "jgaisurvey.sty")):
            data = _read_bytes_bounded(repo, _lexical_rel(repo, str(trio[key]["path"]),
                                                          f"build input {label}"),
                                       f"build input {label}")
            if _sha_bytes(data) != trio[key]["sha256"]:
                raise _fail("INPUT_DRIFT", "BUILD", "REFUSED_PRE_WRITE",
                            f"build input drift before build: {label}")
            inputs[dest] = data
            dest_path = tmp / dest
            fd = os.open(str(dest_path), os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o644)
            try:
                os.write(fd, data)
                os.fsync(fd)
            finally:
                os.close(fd)
        build_env = dict(controlled)
        for key, val in env.items():
            build_env[str(key)] = str(val)
        for cmd in cmds:
            proc = subprocess.run(cmd, cwd=str(tmp), capture_output=True, text=True,
                                  timeout=600, env=build_env)
            if proc.returncode != 0:
                raise _fail("BUILD_FAILED", "BUILD", "PRESERVED_INCOMPLETE",
                            f"build step failed ({proc.returncode}): {cmd[0]} "
                            f"{(proc.stderr or '')[-500:]}")
        pdf_data = (tmp / "main.pdf").read_bytes()
        log_data = (tmp / "main.log").read_bytes()
        try:
            from pypdf import PdfReader
            page_count = len(PdfReader(str(tmp / "main.pdf")).pages)
        except Exception as exc:
            raise _fail("BUILD_FAILED", "BUILD", "PRESERVED_INCOMPLETE",
                        f"built PDF unreadable: {exc}") from exc
        if page_count < 1 or len(pdf_data) < 1 or len(log_data) < 1:
            raise _fail("BUILD_FAILED", "BUILD", "PRESERVED_INCOMPLETE", "built PDF/log empty")
    finally:
        import shutil
        shutil.rmtree(str(tmp), ignore_errors=True)
    digest_text = f"{_sha_bytes(pdf_data)}  main.pdf\n".encode("utf-8")
    outs: dict[str, Any] = {}
    for key, data, extra in (("publication-pdf", pdf_data, {}),
                             ("build-log", log_data, {}),
                             ("pdf-digest", digest_text, {})):
        # EXECUTED outputs are sizedRefs ({path,sha256,byte_count}, no
        # page_count per #/$defs/buildRecord); page_count lives in the proof
        # old-build pdfRef, seal roles stay fileRefs. Never add page_count here.
        rel = f"{basis['proposal_namespace']}/renewals/{basis['renewal_id']}/build/{keyofile(key)}"
        info = _atomic_write_new(repo, rel, data, f"build output {key}")
        outs[key] = {"path": rel, "sha256": info["sha256"],
                     "byte_count": info["byte_count"], **extra}
    # Post-build live reverify: the probed binaries must still resolve to the
    # recorded SHAs (swapped/stale toolchain during the build refuses here).
    for _label, _sha_key in (
            ("executable", "real_sha256"),
            ("biber", "biber_real_sha256"),
            ("latexmk", "latexmk_real_sha256")):
        if _sha_key not in versions:
            continue
        _resolve_path = exe if _label == "executable" else exe.parent / _label
        try:
            _rl, _rr, _rs = _resolve_toolchain_executable(_resolve_path, _label)
        except Exception as exc:
            raise _fail("TOOLCHAIN_COMPANION", "BUILD", "PRESERVED_INCOMPLETE",
                        f"post-build toolchain reverify failed: {_label}: {exc}") from exc
        if _rs != versions[_sha_key]:
            raise _fail("TOOLCHAIN_COMPANION", "BUILD", "PRESERVED_INCOMPLETE",
                        f"toolchain binary changed during build: {_label}")
    return {"fixed_steps": expected_argv,
            "toolchain": {"executable": str(exe), "versions": versions,
                          "argv": expected_argv,
                          "env": {k: env[k] for k in sorted(env)}},
            "outputs": outs}


def keyofile(key: str) -> str:
    return {"publication-pdf": "main.pdf", "build-log": "main.log",
            "pdf-digest": "main.pdf.sha256"}[key]


def _write_renewal_receipt(repo: Path, basis: dict[str, Any], basis_rel: str,
                            entry: dict[str, Any], proof: dict[str, Any],
                            proof_rel: str, build_record_rel: str,
                            executor: str, ts: str) -> str:
    """Renewal receipt AFTER the build record (binds it; never precedes it)."""
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    build_bytes = _read_bytes_bounded(repo, _lexical_rel(repo, build_record_rel,
                                                         "build record"), "build record")
    build_ref = {"path": build_record_rel, "sha256": _sha_bytes(build_bytes)}
    receipt: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_SOURCE_V1",
        "issue_id": basis["issue_id"], "research_profile": basis["research_profile"],
        "publication_profile": basis["publication_profile"],
        "generator_route": basis["generator_route"],
        "proposal_ref": dict(basis["original_proposal_ref"]),
        "renewal_basis_ref": _file_ref(repo, basis_rel, "receipt renewal basis"),
        "renewal_proof_ref": _file_ref(repo, proof_rel, "receipt renewal proof"),
        "reviewed_reader_ref": dict(basis["reviewed_reader_ref"]),
        "authoring_refs": [dict(r) for r in basis["authoring_refs"]],
        "accepted_refs": [dict(r) for r in basis["accepted_refs"]],
        "current_tools": {"repository_commit_sha": basis["current_tool_epoch"]["repository_commit_sha"],
                          "contract": dict(basis["current_tool_epoch"]["contract"]),
                          "closure": [dict(r) for r in basis["current_tool_epoch"]["closure"]]},
        "outputs": {k: {"path": v["path"], "sha256": v["sha256"], "byte_count": v["byte_count"]}
                    for k, v in proof["output_trio_refs"].items()},
        "build_record_ref": build_ref,
    }
    receipt["receipt_sha256"] = core.sha256_object({k: v for k, v in receipt.items()
                                                    if k != "receipt_sha256"})
    rel = _proof_paths_for_request(basis)["receipt"]
    _write_json_bound(repo, rel, receipt, "receipt_sha256", "renewal source receipt",
                      "RECEIPT", "RENEWAL_PROOF_DIGEST")
    try:
        receipt_file_sha = _sha_bytes(_read_bytes_bounded(repo, rel, "renewal receipt pin"))
        _validate_pinned_instance(repo, receipt, rel, receipt_file_sha,
                                  RENEWAL_RECEIPT_SCHEMA, "Renewal Source Receipt", "RECEIPT")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "RECEIPT", "REFUSED_PRE_WRITE",
                    f"renewal receipt schema invalid: {exc}") from exc
    return rel


def validate_renewal_receipt(root: str | Path, receipt_path: str | Path) -> dict[str, Any]:
    """Detached renewal receipt validation: schema/self-digest/refs + bound
    proof Layer-B readback (which rechecks HIST + CURRENT closure/contract)."""
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    repo = Path(root).resolve()
    rel = _lexical_rel(repo, str(receipt_path), "renewal receipt")
    raw = _read_bytes_bounded(repo, rel, "renewal receipt")
    receipt = _strict_json_from_bytes(raw, "renewal receipt")
    if not isinstance(receipt, dict):
        raise _fail("RENEWAL_PROOF_DIGEST", "RECEIPT", "REFUSED_PRE_WRITE",
                    "renewal receipt must be an object")
    try:
        _validate_pinned_instance(repo, receipt, rel, _sha_bytes(raw),
                                  RENEWAL_RECEIPT_SCHEMA, "Renewal Source Receipt", "RECEIPT")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("RENEWAL_PROOF_DIGEST", "RECEIPT", "REFUSED_PRE_WRITE",
                    f"renewal receipt schema invalid: {exc}") from exc
    from scripts import survey_production_v2 as core
    if core.sha256_object({k: v for k, v in receipt.items() if k != "receipt_sha256"}) \
            != receipt.get("receipt_sha256"):
        raise _fail("RENEWAL_PROOF_DIGEST", "RECEIPT", "REFUSED_PRE_WRITE",
                    "renewal receipt self-digest mismatch")
    basis_ref = receipt.get("renewal_basis_ref", {})
    proof_ref = receipt.get("renewal_proof_ref", {})
    build_ref = receipt.get("build_record_ref", {})
    for name, ref in (("basis", basis_ref), ("proof", proof_ref), ("build", build_ref)):
        if not isinstance(ref, dict) or not isinstance(ref.get("path"), str) \
                or not _is_hex64(ref.get("sha256")):
            raise _fail("RENEWAL_PROOF_DIGEST", "RECEIPT", "REFUSED_PRE_WRITE",
                        f"receipt {name} ref invalid")
        live = _read_bytes_bounded(repo, _lexical_rel(repo, str(ref["path"]),
                                                      f"receipt {name}"), f"receipt {name}")
        if _sha_bytes(live) != ref["sha256"]:
            raise _fail("RENEWAL_PROOF_DIGEST", "RECEIPT", "REFUSED_PRE_WRITE",
                        f"receipt {name} bytes changed")
    try:
        proof_verdict = srcmod.verify_renewal_source_proof(repo, str(basis_ref["path"]),
                                                           str(proof_ref["path"]))
    except Exception as exc:
        code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
        raise _fail(str(code), "RECEIPT", "REFUSED_PRE_WRITE",
                    f"bound proof readback failed: {exc}") from exc
    _ = proof_verdict
    return {"RECEIPT_VALID": True, "receipt": receipt, "receipt_path": rel}


def _lineage_scope_path(repo: Path, basis: dict[str, Any]) -> str:
    """Exact lineage scope review path from H materialization lineage.

    Reads the HIST verdict on the prior record (reloaded, never a caller dict)
    and takes the latest EDITORIAL entry's original_scope_ref (exact path+SHA,
    live bytes verified). Same-reader renewal never changes the reader, so
    this early scope authority remains valid for both U and C gates; a
    replacement scope at a different path is never silently substituted.
    """
    from scripts import survey_versioned_renewal_history_v2 as hist
    prior_record = basis.get("prior_record_ref", {})
    try:
        verdict = hist.verify_versioned_history(repo, str(prior_record.get("path", "")))
    except Exception as exc:
        code = getattr(exc, "code", None) or "HISTORY_DIGEST_MISMATCH"
        raise _fail(str(code), "FINALIZE", "REFUSED_PRE_WRITE",
                    f"lineage scope history invalid: {exc}") from exc
    lineage = verdict.get("materialization_lineage", [])
    editorial = [e for e in lineage if isinstance(e, dict) and e.get("kind") == "EDITORIAL"]
    if not editorial:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "no editorial materialization producer in selected chain")
    scope_ref = editorial[-1].get("original_scope_ref", {})
    if not isinstance(scope_ref, dict) or not isinstance(scope_ref.get("path"), str):
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "lineage scope ref invalid")
    rel = _lexical_rel(repo, str(scope_ref["path"]), "lineage scope review")
    data = _read_bytes_bounded(repo, rel, "lineage scope review")
    if _sha_bytes(data) != scope_ref.get("sha256"):
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "lineage scope review bytes changed")
    return rel


def _write_qa_gate_candidate(repo: Path, basis: dict[str, Any], basis_rel: str,
                             entry: dict[str, Any], proof: dict[str, Any],
                             proof_rel: str, receipt_rel: str, paths: dict[str, str],
                             checks_path: str | Path,
                             semantic_review_path: str | Path | None,
                             visual_review_path: str | Path | None,
                             executor: str, ts: str) -> tuple[str, str, str]:
    """Fresh QA inputs -> bundle -> Gate -> Candidate, all bound to SAME proof.

    quality.validate_checks validates the supplied results; it never executes
    those checks. No genuine approval is produced: fixtures carry synthetic
    external records labelled as such; production semantic quality stays NO-GO.
    """
    from scripts import survey_production_v2 as core
    from scripts import survey_quality_v2 as quality
    from scripts import survey_publication_v2 as pubmod
    from scripts import survey_reader_surface_gate_v2 as gatemod
    from scripts import survey_reader_publication_v2 as reader_pub
    proof_ref = _file_ref(repo, proof_rel, "finalize renewal proof")
    receipt_ref = _file_ref(repo, receipt_rel, "finalize renewal receipt")
    requested = basis.get("requested")
    trio = proof["output_trio_refs"]
    # The Gate's semantic input is the lineage scope review (early, exact) for
    # BOTH U and C: the reader is unchanged in same-reader renewal, so the
    # scope authority (reviewed_surface == proof reviewed_reader) remains
    # valid; the gate's fresh surface checks run on the bound trio (old paths
    # for U, new R paths for C) and the derivation binds the NEW proof+receipt.
    # Postrender publication reviews (predecessor refs for U, new postrender
    # for C) go to Candidate/seal, never as gate semantic input (wrong shape:
    # no reviewed_surface). A replacement scope at a different path is never
    # silently substituted.
    gate_sem_path = _lineage_scope_path(repo, basis)
    if requested == "REUSE_TARGETS":
        prior_seal = _strict_json_from_bytes(
            _read_bytes_bounded(repo, _lexical_rel(repo, basis["prior_selected_ref"]["path"],
                                                   "prior seal"), "prior seal"), "prior seal")
        roles = prior_seal.get("roles", {})
        man_path = str((roles.get("reader-manuscript") or {}).get("path", ""))
        pdf_path = str((roles.get("publication-pdf") or {}).get("path", ""))
        # Candidate/seal keep the exact predecessor postrender review records.
        sem_path = str((roles.get("semantic-review") or {}).get("path", ""))
        vis_path = str((roles.get("visual-review") or {}).get("path", ""))
        if semantic_review_path is not None:
            sem_path = _lexical_rel(repo, str(semantic_review_path), "supplied semantic review")
        if visual_review_path is not None:
            vis_path = _lexical_rel(repo, str(visual_review_path), "supplied visual review")
    else:
        man_path = paths["manuscript"]
        build_rec = _strict_json_from_bytes(
            _read_bytes_bounded(repo, _lexical_rel(
                repo, _proof_paths_for_request(basis)["build_record"], "build record"),
                "build record"), "build record")
        pdf_path = str((build_rec.get("outputs", {}) or {}).get("publication-pdf", {})
                       .get("path", ""))
        sem_path = _lexical_rel(repo, str(semantic_review_path), "C semantic review")
        vis_path = _lexical_rel(repo, str(visual_review_path), "C visual review")
        _require_postrender_review_targets(repo, basis, proof, sem_path, vis_path)
    checks_rel = _lexical_rel(repo, str(checks_path), "QA checks")
    checks_data = _read_bytes_bounded(repo, checks_rel, "QA checks")
    checks_doc = _strict_json_from_bytes(checks_data, "QA checks")
    # Actual supplied file shape is {"checks": [...]} (bootstrap evidence);
    # a bare array is also accepted. Anything else refuses (no invented shape).
    if isinstance(checks_doc, dict) and isinstance(checks_doc.get("checks"), list):
        checks = checks_doc["checks"]
    elif isinstance(checks_doc, list):
        checks = checks_doc
    else:
        raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                    "QA checks file must be a non-empty array or {checks:[...]}")
    if not checks:
        raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE", "QA checks must be a non-empty array")
    # Freshness: every check must be recorded at/after basis capture (this
    # renewal's own actual run, never a copied old result). Live result SHAs
    # are re-verified by validate_checks below; full required DETERMINISTIC
    # kinds must be present.
    try:
        basis_instant = _parse_instant_str(str(basis.get("recorded_at", "")))
    except RenewalHighError as exc:
        raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"basis recorded_at invalid for QA freshness: {exc.detail}") from exc
    for row in checks:
        if not isinstance(row, dict):
            raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE", "QA check row invalid")
        try:
            row_instant = _parse_instant_str(str(row.get("recorded_at", "")))
        except RenewalHighError:
            raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"QA check recorded_at invalid: {row.get('check_id')})") from None
        if row_instant < basis_instant:
            raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"stale QA refused (recorded before basis capture): {row.get('check_id')}")
    cfg = _strict_json_from_bytes(
        _read_bytes_bounded(repo, "config/survey-production-v2.json", "production config"),
        "production config")
    try:
        quality.validate_checks(repo, cfg, str(basis["research_profile"]),
                                str(basis["publication_profile"]), checks,
                                required_kinds={"DETERMINISTIC"})
    except ValueError as exc:
        raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"supplied QA results invalid (no fresh QA): {exc}") from exc
    profile_rel = _lexical_rel(repo, str(basis["profile_ref"]["path"]), "Production Profile")
    try:
        quality.build_bundle(repo, str(basis["issue_id"]),
                             repo / str(trio["primary"]["path"]),
                             repo / pdf_path, checks, repo / paths["bundle"],
                             production_profile_path=repo / profile_rel,
                             renewal_source_proof_ref=dict(proof_ref))
    except TypeError as exc:
        raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                    "quality bundle builder lacks the renewal proof branch "
                    "(consumer integration required): "
                    f"{exc}") from exc
    except ValueError as exc:
        raise _fail("QA_MISSING", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"QA bundle build refused: {exc}") from exc
    try:
        gatemod.evaluate_reader_surface_gate(
            repo, repo / man_path,
            semantic_review_path=repo / gate_sem_path,
            evaluated_by=f"versioned-renewal-high {executor}", recorded_at=None,
            output_path=repo / paths["gate"],
            renewal_source_proof_ref=dict(proof_ref),
            renewal_receipt_ref=dict(receipt_ref))
    except TypeError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "gate derivation lacks the VERSIONED_RENEWAL_V1 proof/receipt branch "
                    "(consumer integration required): "
                    f"{exc}") from exc
    except ValueError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"gate derivation refused: {exc}") from exc
    try:
        sem_rec = reader_pub.validate_review_record(repo, repo / sem_path,
                                                    issue_id=str(basis["issue_id"]),
                                                    expected_kind="SEMANTIC_EDITORIAL",
                                                    renewal_source_proof_ref=dict(proof_ref))
        vis_rec = reader_pub.validate_review_record(repo, repo / vis_path,
                                                    issue_id=str(basis["issue_id"]),
                                                    expected_kind="VISUAL",
                                                    renewal_source_proof_ref=dict(proof_ref))
    except TypeError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "review validator lacks the renewal proof context "
                    "(consumer integration required): "
                    f"{exc}") from exc
    except ValueError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"review validation refused: {exc}") from exc
    _ = sem_rec, vis_rec
    try:
        page_count = _pdf_page_count(repo, pdf_path)
        pubmod.build_candidate(repo, str(basis["issue_id"]),
                               str(basis["publication_profile"]), repo / man_path,
                               repo / str(trio["primary"]["path"]), repo / pdf_path,
                               page_count, repo / paths["bundle"], repo / sem_path,
                               repo / vis_path, repo / paths["candidate"],
                               renewal_source_proof_ref=dict(proof_ref))
    except TypeError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "candidate builder lacks the renewal proof branch "
                    "(consumer integration required): "
                    f"{exc}") from exc
    except ValueError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"candidate build refused: {exc}") from exc
    return paths["bundle"], paths["gate"], paths["candidate"]


def _require_postrender_review_targets(repo: Path, basis: dict[str, Any],
                                       proof: dict[str, Any], sem_path: str,
                                       vis_path: str) -> None:
    """C postrender reviews must target the exact new manuscript/source/PDF
    (same SHA at a different target path is still C; source-only/comment-only
    changes do not carry old exact-target reviews)."""
    trio = proof["output_trio_refs"]
    for rel, kind in ((sem_path, "SEMANTIC_EDITORIAL"), (vis_path, "VISUAL")):
        data = _read_bytes_bounded(repo, _lexical_rel(repo, rel, f"C {kind} review"),
                                   f"C {kind} review")
        doc = _strict_json_from_bytes(data, f"C {kind} review")
        if not isinstance(doc, dict):
            raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"C {kind} review must be an object")
        man = doc.get("reader_manuscript", {})
        src = doc.get("source", {})
        pdf = doc.get("pdf", {})
        if not isinstance(man, dict) or not isinstance(src, dict) or not isinstance(pdf, dict):
            raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                        f"C {kind} review lacks manuscript/source/pdf refs")


def _pdf_page_count(repo: Path, pdf_rel: str) -> int:
    rel = _lexical_rel(repo, pdf_rel, "publication PDF")
    data = _read_bytes_bounded(repo, rel, "publication PDF")
    try:
        import io
        from pypdf import PdfReader
        count = len(PdfReader(io.BytesIO(data)).pages)
    except Exception as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    f"PDF page count unreadable: {exc}") from exc
    if count < 1:
        raise _fail("REVIEW_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "PDF page count invalid")
    return count


def _write_renewal_seal(repo: Path, basis: dict[str, Any], basis_rel: str,
                         entry: dict[str, Any], proof: dict[str, Any],
                         proof_rel: str, receipt_rel: str, build_record_rel: str,
                         bundle_rel: str, gate_rel: str, candidate_rel: str,
                         executor: str, ts: str) -> str:
    """Seal LAST: new set kind VERSIONED_RENEWAL_SET_V1 (not a relaxation of
    old fixed publication paths). The low validator cross-binds proof/basis/
    receipt refs in addition to role maps. U keeps original target paths and
    exact old manuscript/source/PDF/build/review records; receipt/QA/Gate/
    Candidate point at NEW R paths. C roles bind new R paths (reader/authoring
    retention/scope-history stay at ORIGINAL P paths via basis)."""
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    requested = basis.get("requested")
    if requested == "REUSE_TARGETS":
        prior_seal = _strict_json_from_bytes(
            _read_bytes_bounded(repo, _lexical_rel(repo, basis["prior_selected_ref"]["path"],
                                                   "prior seal"), "prior seal"), "prior seal")
        roles = prior_seal.get("roles", {})
        man_path = str((roles.get("reader-manuscript") or {}).get("path", ""))
        trio_paths = {k: str((roles.get(rn) or {}).get("path", ""))
                      for k, rn in (("primary", "validated-source"),
                                    ("bibliography", "bibliography"), ("style", "style"))}
        pdf_path = str((roles.get("publication-pdf") or {}).get("path", ""))
        log_path = str((roles.get("build-log") or {}).get("path", ""))
        digest_path = str((roles.get("pdf-digest") or {}).get("path", ""))
        sem_path = str((roles.get("semantic-review") or {}).get("path", ""))
        vis_path = str((roles.get("visual-review") or {}).get("path", ""))
    else:
        man_path = _proof_paths_for_request(basis)["manuscript"]
        trio_paths = {k: str(v["path"]) for k, v in proof["output_trio_refs"].items()}
        build_rec = _strict_json_from_bytes(
            _read_bytes_bounded(repo, _lexical_rel(repo, build_record_rel, "build record"),
                                "build record"), "build record")
        outs = build_rec.get("outputs", {})
        pdf_path = str((outs.get("publication-pdf") or {}).get("path", ""))
        log_path = str((outs.get("build-log") or {}).get("path", ""))
        digest_path = str((outs.get("pdf-digest") or {}).get("path", ""))
        candidate_doc = _strict_json_from_bytes(
            _read_bytes_bounded(repo, _lexical_rel(repo, candidate_rel, "candidate"),
                                "candidate"), "candidate")
        sem_path = str((candidate_doc.get("semantic_review") or {}).get("path", ""))
        vis_path = str((candidate_doc.get("visual_review") or {}).get("path", ""))

    def fr_rel(rel: str, role: str) -> dict[str, Any]:
        rrel = _lexical_rel(repo, rel, f"seal role {role}")
        data = _read_bytes_bounded(repo, rrel, f"seal role {role}")
        if len(data) < 1:
            raise _fail("SEAL_ROLE", "SEAL", "REFUSED_PRE_WRITE", f"seal role empty: {rrel}")
        return {"path": rrel, "sha256": _sha_bytes(data), "byte_count": len(data)}
    roles_new = {
        "reader-input": fr_rel(str(basis["reviewed_reader_ref"]["path"]), "reader-input"),
        "authoring-input": fr_rel(str(basis["authoring_refs"][0]["path"]), "authoring-input"),
        "source-receipt": fr_rel(receipt_rel, "source-receipt"),
        "reader-manuscript": fr_rel(man_path, "reader-manuscript"),
        "validated-source": fr_rel(trio_paths["primary"], "validated-source"),
        "bibliography": fr_rel(trio_paths["bibliography"], "bibliography"),
        "style": fr_rel(trio_paths["style"], "style"),
        "publication-pdf": fr_rel(pdf_path, "publication-pdf"),
        "build-log": fr_rel(log_path, "build-log"),
        "pdf-digest": fr_rel(digest_path, "pdf-digest"),
        "quality-regression-bundle": fr_rel(bundle_rel, "quality-regression-bundle"),
        "semantic-review": fr_rel(sem_path, "semantic-review"),
        "visual-review": fr_rel(vis_path, "visual-review"),
        "reader-surface-gate": fr_rel(gate_rel, "reader-surface-gate"),
        "publication-candidate": fr_rel(candidate_rel, "publication-candidate"),
    }
    if set(roles_new) != {"reader-input", "authoring-input", "source-receipt",
                          "reader-manuscript", "validated-source", "bibliography", "style",
                          "publication-pdf", "build-log", "pdf-digest",
                          "quality-regression-bundle", "semantic-review", "visual-review",
                          "reader-surface-gate", "publication-candidate"}:
        raise _fail("SEAL_ROLES", "SEAL", "REFUSED_PRE_WRITE", "seal roles must be exactly 15")
    seen: set[str] = set()
    for role, ref in roles_new.items():
        if ref["path"] in seen:
            raise _fail("SEAL_DUP", "SEAL", "REFUSED_PRE_WRITE",
                        f"seal duplicated role path: {ref['path']}")
        seen.add(ref["path"])
    seal: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_SET_V1",
        "status": "SEALED_INERT", "issue_id": basis["issue_id"],
        "research_profile": basis["research_profile"],
        "publication_profile": basis["publication_profile"],
        "proposal_ref": dict(basis["original_proposal_ref"]),
        "renewal_basis_ref": _file_ref(repo, basis_rel, "seal renewal basis"),
        "renewal_proof_ref": _file_ref(repo, proof_rel, "seal renewal proof"),
        "source_receipt_ref": {"path": receipt_rel,
                               "sha256": _sha_bytes(_read_bytes_bounded(
                                   repo, receipt_rel, "seal receipt"))},
        "build_record_ref": {"path": build_record_rel,
                             "sha256": _sha_bytes(_read_bytes_bounded(
                                 repo, _lexical_rel(repo, build_record_rel, "build record"),
                                 "seal build record"))},
        "roles": roles_new,
    }
    seal["set_sha256"] = core.sha256_object({k: v for k, v in seal.items()
                                             if k != "set_sha256"})
    rel = _proof_paths_for_request(basis)["set"]
    _write_json_bound(repo, rel, seal, "set_sha256", "renewal publication set",
                      "SEAL", "SEAL_BIND")
    try:
        seal_file_sha = _sha_bytes(_read_bytes_bounded(repo, rel, "renewal seal pin"))
        _validate_pinned_instance(repo, seal, rel, seal_file_sha,
                                  RENEWAL_SET_SCHEMA, "Renewal Publication Set", "SEAL",
                                  fail_code="SEAL_BIND")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("SEAL_BIND", "SEAL", "REFUSED_PRE_WRITE",
                    f"renewal seal schema invalid: {exc}") from exc
    return rel


def validate_prepared_renewal_set(root: str | Path, state_path: str | Path,
                                  set_path: str | Path) -> dict[str, Any]:
    """Full-set validation: Candidate/QA/Gate/receipt/seal must agree on the
    SAME proof (equal-SHA different proof paths are never silently substituted).
    finalize/validate-set MUST refuse a renewed set whose NEW Candidate/QA/Gate
    files lack the NEW proof ref (absence -> REVIEW_TARGET_MISMATCH, never a
    silent fallback to the embedded PRIOR proof)."""
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_publication_set_v2 as setmod
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    repo = Path(root).resolve()
    set_rel = _lexical_rel(repo, str(set_path), "renewal publication set")
    seal_bytes = _read_bytes_bounded(repo, set_rel, "renewal publication set")
    seal = _strict_json_from_bytes(seal_bytes, "renewal publication set")
    if not isinstance(seal, dict):
        raise _fail("SEAL_BIND", "SET", "REFUSED_PRE_WRITE", "seal must be an object")
    try:
        _validate_pinned_instance(repo, seal, set_rel, _sha_bytes(seal_bytes),
                                  RENEWAL_SET_SCHEMA, "Renewal Publication Set", "SET",
                                  fail_code="SEAL_BIND")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("SEAL_BIND", "SET", "REFUSED_PRE_WRITE",
                    f"seal schema invalid: {exc}") from exc
    if core.sha256_object({k: v for k, v in seal.items() if k != "set_sha256"}) \
            != seal.get("set_sha256"):
        raise _fail("SEAL_BIND", "SET", "REFUSED_PRE_WRITE", "seal self-digest mismatch")
    for key in ("renewal_basis_ref", "renewal_proof_ref", "source_receipt_ref",
                "build_record_ref"):
        ref = seal.get(key)
        if not isinstance(ref, dict) or not isinstance(ref.get("path"), str) \
                or not _is_hex64(ref.get("sha256")):
            raise _fail("SEAL_BIND", "SET", "REFUSED_PRE_WRITE", f"seal {key} invalid")
        live = _read_bytes_bounded(repo, _lexical_rel(repo, str(ref["path"]),
                                                      f"seal {key}"), f"seal {key}")
        if _sha_bytes(live) != ref["sha256"]:
            raise _fail("SEAL_BIND", "SET", "REFUSED_PRE_WRITE", f"seal {key} bytes changed")
    proof_ref = seal["renewal_proof_ref"]
    basis_ref = seal["renewal_basis_ref"]
    try:
        validated_seal = setmod.validate_seal(repo, Path(set_rel))
    except Exception as exc:
        code = getattr(exc, "code", None) or "SEAL_BIND"
        raise _fail(str(code), "SET", "REFUSED_PRE_WRITE",
                    f"low seal validation failed: {exc}") from exc
    _ = validated_seal
    try:
        receipt_valid = validate_renewal_receipt(repo, str(seal["source_receipt_ref"]["path"]))
    except RenewalHighError:
        raise
    except Exception as exc:
        code = getattr(exc, "code", None) or "SEAL_BIND"
        raise _fail(str(code), "SET", "REFUSED_PRE_WRITE",
                    f"seal receipt invalid: {exc}") from exc
    _ = receipt_valid
    try:
        proof_verdict = srcmod.verify_renewal_source_proof(repo, str(basis_ref["path"]),
                                                           str(proof_ref["path"]))
    except Exception as exc:
        code = getattr(exc, "code", None) or "RENEWAL_PROOF_DIGEST"
        raise _fail(str(code), "SET", "REFUSED_PRE_WRITE",
                    f"seal proof readback failed: {exc}") from exc
    _ = proof_verdict
    roles = seal.get("roles", {})
    candidate_role = roles.get("publication-candidate", {})
    bundle_role = roles.get("quality-regression-bundle", {})
    gate_role = roles.get("reader-surface-gate", {})
    expected = {"path": str(proof_ref["path"]), "sha256": str(proof_ref["sha256"])}
    receipt_expected = {"path": str(seal["source_receipt_ref"]["path"]),
                        "sha256": str(seal["source_receipt_ref"]["sha256"])}
    try:
        from scripts import survey_publication_v2 as pubmod
        from scripts import survey_quality_v2 as quality
        from scripts import survey_reader_surface_gate_v2 as gatemod
        candidate = pubmod.validate_candidate(repo, repo / str(candidate_role.get("path", "")),
                                              expected_proof_ref=dict(expected))
        bundle = quality.validate_bundle(repo, repo / str(bundle_role.get("path", "")),
                                         expected_proof_ref=dict(expected))
        gate = gatemod.validate_reader_surface_gate(repo, repo / str(gate_role.get("path", "")),
                                                    expected_proof_ref=dict(expected),
                                                    expected_receipt_ref=dict(receipt_expected))
    except TypeError as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "SET", "REFUSED_PRE_WRITE",
                    "consumer validator lacks the renewal proof context "
                    "(consumer integration required): "
                    f"{exc}") from exc
    except (ValueError, OSError) as exc:
        raise _fail("REVIEW_TARGET_MISMATCH", "SET", "REFUSED_PRE_WRITE",
                    f"set member validation refused: {exc}") from exc
    for name, doc in (("candidate", candidate), ("bundle", bundle), ("gate", gate)):
        if name == "gate":
            got = ((doc.get("derivation") or {}).get("renewal_source_proof_ref")
                   if isinstance(doc.get("derivation"), dict) else None)
        else:
            got = doc.get("renewal_source_proof_ref")
        if not isinstance(got, dict) or got.get("path") != expected["path"] \
                or got.get("sha256") != expected["sha256"]:
            raise _fail("REVIEW_TARGET_MISMATCH", "SET", "REFUSED_PRE_WRITE",
                        f"full-set SAME-proof equality failed: {name} does not bind the "
                        f"seal proof (no silent fallback to an embedded prior proof)")
    return {"SET_VALID": True, "set": seal, "set_path": set_rel,
            "proof_ref": expected}


def _refuse_matching_intent_orphan(
    repo: Path,
    parent_dir_rel: str,
    current_set_ref: dict[str, Any],
    current_basis_ref: dict[str, Any],
    current_before_ref: dict[str, Any],
    live_pointer: Any,
    phase: str = "ACTIVATE",
) -> None:
    """Narrow fail-closed matching-intent detection BEFORE record creation.

    ROOT failure/resume disposition (astra-integration-corrections.md appended
    S, 2026-10-25): ordinary ``activate_renewal`` allocating ``r3`` while a
    complete ``r2`` for the SAME sealed set/basis is still inert and State is
    still before is a product defect against the selected explicit-resume
    contract, not a passing max-advance. Ordinary activation must refuse the
    existing matching intent before creating another record; changing
    free-text reason/time or choosing the next global sequence must not bypass
    this refusal. Explicit ``resume_renewal_activation(record_path)`` still
    performs complete current revalidation and full 15-field intent equality.

    Same intent is narrow: same immutable set path+SHA AND same renewal basis
    path+SHA AND same before-State path+SHA for an existing INERT renewal
    record in the reserved revalidation namespace. Different free-text
    reason/executor/recorded_at never bypass same-set identity; full 15-field
    equality still applies to explicit resume matching that record. Do NOT
    adopt the existing record automatically or infer latest. A truly new R set
    after another complete inert set may allocate the next unused sequence per
    contract (no global ban on all unselected records).

    Reserved namespace is scanned with safe FD reads, strict JSON, schema and
    kind. Malformed/unknown reserved records cannot grant permission;
    fail-closed preserve/diagnostic when ownership cannot be determined, with
    no cleanup/deletion/overwrite/force-resume. Partial-record recovery gets
    no broad new framework/schema/intent file; the diagnostic returns the
    exact constraint when a root decision is needed. ALREADY_ACTIVE exact-set
    handling runs before this scan with full readonly validation. Alias
    inputs refuse per B3 with no same-SHA path rebind. Scan plus the
    controlled ``O_EXCL`` claim after the scan still refuses TOCTOU races;
    this is single-writer/held-descriptor bounded, never a global CAS claim.
    """
    for label, ref in (("current set", current_set_ref),
                       ("current basis", current_basis_ref),
                       ("current before", current_before_ref)):
        if not isinstance(ref, dict) or not isinstance(ref.get("path"), str) \
                or not _is_hex64(ref.get("sha256")):
            raise _fail("ARGS", phase, "REFUSED_PRE_WRITE",
                        f"matching-intent {label} ref must be exact {{path,sha256}}")
        _lexical_rel(repo, str(ref["path"]), f"matching-intent {label}")
    _lexical_rel(repo, parent_dir_rel, "activation record directory")
    _walk_existing_ancestors(repo, _lexical_parts(parent_dir_rel, "activation record directory"),
                             "activation record directory")
    try:
        dir_abs = repo.resolve().joinpath(*parent_dir_rel.split("/"))
        names = [p.name for p in dir_abs.iterdir()]
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", phase, "REFUSED_PRE_WRITE",
                    f"reserved record directory unreadable (preserved, no delete): "
                    f"{parent_dir_rel}: {exc}") from exc
    live_path = live_pointer.get("path") if isinstance(live_pointer, dict) else None
    for name in sorted(names):
        match = re.fullmatch(r"publication-surface-revalidation-r(\d+)\.json", name)
        if not match:
            continue
        seq = match.group(1)
        if len(seq) > 1 and seq.startswith("0"):
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record has non-canonical sequence (preserved, no delete/overwrite): "
                        f"{parent_dir_rel}/{name}; requires root decision, no broad recovery")
        rel = f"{parent_dir_rel}/{name}"
        if isinstance(live_path, str) and rel == live_path:
            continue
        try:
            lst = os.lstat(repo.resolve().joinpath(*rel.split("/")))
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record lstat failed (preserved, no delete): "
                        f"{rel}: {exc}") from exc
        if stat.S_ISLNK(lst.st_mode):
            raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                        f"reserved record is symlink/foreign (preserved, no unowned delete, "
                        f"no takeover): {rel}; explicit resume requires exact prior intent, "
                        f"malformed/foreign never grants permission")
        if not stat.S_ISREG(lst.st_mode):
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record is not a regular file (preserved, no delete): "
                        f"{rel}; requires root decision, no broad recovery")
        if lst.st_nlink != 1:
            raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                        f"reserved record hardlink sharing refused (preserved, no delete, "
                        f"NOT ALREADY_ACTIVE by same SHA): {rel} nlink={lst.st_nlink}")
        try:
            data = _read_bytes_bounded(repo, rel, "reserved activation record")
        except RenewalHighError as exc:
            if getattr(exc, "code", None) == "HIGH_MISSING":
                continue
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record unreadable (preserved, no delete/overwrite): "
                        f"{rel}: {exc.code}: {exc.detail}") from exc
        try:
            doc = _strict_json_from_bytes(data, "reserved activation record")
        except RenewalHighError as exc:
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record malformed/partial (preserved, no delete/overwrite/force-resume): "
                        f"{rel}: {exc.detail}; requires root decision, no broad framework") from exc
        if not isinstance(doc, dict):
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record malformed (preserved, no delete): "
                        f"{rel}; requires root decision, no broad recovery")
        is_renewal = (doc.get("kind") == "VERSIONED_RENEWAL_ACTIVATION_V1"
                      and doc.get("reason_class") == "REVIEWED_VERSIONED_CORE_RENEWAL")
        is_editorial = (doc.get("kind") == "EDITORIAL_PUBLICATION_ACTIVATION_V1"
                        and doc.get("reason_class") == "REVIEWED_EDITORIAL_CORRECTION")
        is_legacy = (doc.get("reason_class") == "REVIEWED_CORE_CHANGE" and "kind" not in doc)
        if not is_renewal:
            if is_editorial or is_legacy:
                continue
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved record unknown branch (preserved, no delete/overwrite/force-resume): "
                        f"{rel} kind={doc.get('kind')!r} reason_class={doc.get('reason_class')!r}; "
                        f"cannot determine ownership, requires root decision")
        file_sha = _sha_bytes(data)
        try:
            _validate_pinned_instance(repo, doc, rel, file_sha,
                                      "schemas/publication-surface-revalidation.schema.json",
                                      "Reserved activation record", phase,
                                      fail_code="RECORD_COLLISION")
        except RenewalHighError as exc:
            raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"reserved renewal record schema/partial invalid (preserved, no delete/overwrite): "
                        f"{rel}: {exc.detail}; requires root decision, no broad recovery") from exc
        for key in ("set_ref", "renewal_basis_ref", "before_state_ref"):
            ref = doc.get(key)
            if not isinstance(ref, dict) or not isinstance(ref.get("path"), str) \
                    or not _is_hex64(ref.get("sha256")):
                raise _fail("RECORD_COLLISION", phase, "REFUSED_PRE_WRITE",
                            f"reserved renewal record lacks exact {key} (preserved, no delete): "
                            f"{rel}; cannot determine ownership, requires root decision")
        existing_set = doc.get("set_ref")
        existing_basis = doc.get("renewal_basis_ref")
        existing_before = doc.get("before_state_ref")
        if (existing_set.get("sha256") == current_set_ref.get("sha256")
                and existing_set.get("path") != current_set_ref.get("path")):
            raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                        f"reserved set alias input refused before writes "
                        f"(spelling {current_set_ref.get('path')!r} != "
                        f"existing {existing_set.get('path')!r} but same SHA "
                        f"{existing_set.get('sha256')}; NOT ALREADY_ACTIVE by same SHA; "
                        f"no same-SHA path rebind, preserved, no delete)")
        set_exact = (existing_set.get("path") == current_set_ref.get("path")
                     and existing_set.get("sha256") == current_set_ref.get("sha256"))
        basis_exact = (existing_basis.get("path") == current_basis_ref.get("path")
                       and existing_basis.get("sha256") == current_basis_ref.get("sha256"))
        before_exact = (existing_before.get("path") == current_before_ref.get("path")
                        and existing_before.get("sha256") == current_before_ref.get("sha256"))
        if set_exact and basis_exact and before_exact:
            raise _fail("INTENT_COLLISION", phase, "REFUSED_PRE_WRITE",
                        f"matching inert renewal intent already exists (preserved, no new record/State change): "
                        f"{rel} same set {existing_set.get('path')} sha {existing_set.get('sha256')[:12]} "
                        f"basis {existing_basis.get('path')} before {existing_before.get('path')}; "
                        f"different reason/executor/time does not bypass same-set identity; "
                        f"explicit resume_renewal_activation({rel!r}) with full 15-field equality required, "
                        f"no auto-adopt, no latest inference")


def _next_record_rel(repo: Path, prior_record_rel: str) -> str:
    parent = str(Path(prior_record_rel).parent.as_posix())
    _lexical_rel(repo, parent, "activation record directory")
    _walk_existing_ancestors(repo, _lexical_parts(parent, "activation record directory"),
                             "activation record directory")
    try:
        names = [p.name for p in (repo.resolve().joinpath(*parent.split("/"))).iterdir()]
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE",
                    f"record directory unreadable: {parent}: {exc}") from exc
    best = 0
    for name in names:
        match = re.fullmatch(r"publication-surface-revalidation-r(\d+)\.json", name)
        if match:
            best = max(best, int(match.group(1)))
    return f"{parent}/publication-surface-revalidation-r{best + 1}.json"


def _check_already_active_set(repo: Path, supplied_rel: str, supplied_sha: str,
                              selected_ref: dict[str, Any] | None, label: str) -> bool:
    if not isinstance(selected_ref, dict) or not isinstance(selected_ref.get("path"), str) \
            or not _is_hex64(selected_ref.get("sha256")):
        return False
    expected_rel = _lexical_rel(repo, str(selected_ref["path"]), f"{label} selected")
    expected_sha = str(selected_ref["sha256"])
    if supplied_rel == expected_rel and supplied_sha == expected_sha:
        try:
            if _file_identity(repo, supplied_rel, label) != _file_identity(repo, expected_rel, label):
                raise _fail("RECORD_COLLISION", "ACTIVATE", "PRESERVED_INCOMPLETE",
                            f"{label} identity changed for exact spelling "
                            f"(dev/ino differs): {supplied_rel!r}")
        except RenewalHighError:
            raise
        return True
    if supplied_rel != expected_rel and (supplied_sha == expected_sha or (
            _file_identity(repo, supplied_rel, f"{label} supplied")[0:2] ==
            _file_identity(repo, expected_rel, f"{label} expected")[0:2]
            if _is_hex64(supplied_sha) else False)):
        try:
            s_id = _file_identity(repo, supplied_rel, f"{label} supplied")
            e_id = _file_identity(repo, expected_rel, f"{label} expected")
        except RenewalHighError:
            raise _fail("RECORD_COLLISION", "ACTIVATE", "PRESERVED_INCOMPLETE",
                        f"{label} alias input refused before writes "
                        f"(spelling {supplied_rel!r} != expected {expected_rel!r}; "
                        "NOT ALREADY_ACTIVE by same SHA)")
        if s_id == e_id or supplied_sha == expected_sha:
            raise _fail("RECORD_COLLISION", "ACTIVATE", "PRESERVED_INCOMPLETE",
                        f"{label} alias input refused before writes "
                        f"(spelling differs but same bytes/inode: {supplied_rel!r} vs {expected_rel!r}; "
                        "NOT ALREADY_ACTIVE by same SHA)")
    if supplied_rel != expected_rel:
        try:
            s_id = _file_identity(repo, supplied_rel, f"{label} supplied")
            e_id = _file_identity(repo, expected_rel, f"{label} expected")
            if s_id == e_id:
                raise _fail("RECORD_COLLISION", "ACTIVATE", "PRESERVED_INCOMPLETE",
                            f"{label} alias input refused before writes "
                            f"(hardlink same inode different spelling: {supplied_rel!r} vs {expected_rel!r}; "
                            "NOT ALREADY_ACTIVE by same SHA)")
        except RenewalHighError as exc:
            if exc.code == "RECORD_COLLISION":
                raise
            pass
    return False


def _check_already_active_record(repo: Path, supplied_rel: str, supplied_sha: str,
                                 live_pointer: Any, label: str, phase: str) -> bool:
    if not isinstance(live_pointer, dict) or not isinstance(live_pointer.get("path"), str) \
            or not _is_hex64(live_pointer.get("sha256")):
        return False
    expected_rel = _lexical_rel(repo, str(live_pointer["path"]), f"{label} live pointer")
    expected_sha = str(live_pointer["sha256"])
    if supplied_rel == expected_rel and supplied_sha == expected_sha:
        try:
            if _file_identity(repo, supplied_rel, label) != _file_identity(repo, expected_rel, label):
                raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                            f"{label} identity changed for exact spelling: {supplied_rel!r}")
        except RenewalHighError:
            raise
        return True
    if supplied_rel != expected_rel:
        try:
            s_id = _file_identity(repo, supplied_rel, f"{label} supplied")
            e_id = _file_identity(repo, expected_rel, f"{label} expected")
            if s_id == e_id or supplied_sha == expected_sha:
                raise _fail("RECORD_COLLISION", phase, "PRESERVED_INCOMPLETE",
                            f"{label} alias input refused before writes "
                            f"(spelling differs but same bytes/inode: {supplied_rel!r} vs {expected_rel!r}; "
                            "NOT ALREADY_ACTIVE by same SHA)")
        except RenewalHighError as exc:
            if exc.code == "RECORD_COLLISION":
                raise
            pass
    return False


def activate_renewal(root: str | Path, state_path: str | Path, set_path: str | Path,
                     reason: str, executor: str,
                     recorded_at: datetime | str | None = None) -> dict[str, Any]:
    """Explicit activation with full revalidation. After complete Candidate and
    seal, the sole live mutation remains the existing State
    publication_revalidation_provenance pointer: exclusive new record,
    known-byte State temp/replace, full new active readback. Only the pointer
    changes. A second same-reader renewal requires another genuine eligible
    Core change and a fresh basis; retry of the exact already-active record is
    only readonly ALREADY_ACTIVE. Truthful free-text Core-change reason
    required; reason_class is fixed REVIEWED_VERSIONED_CORE_RENEWAL, never from
    a CLI flag."""
    from scripts import survey_production_v2 as core
    from scripts import survey_schema_v2 as schema_gate
    from scripts import survey_agent_control_v2 as agent
    from scripts import survey_publication_set_v2 as setmod
    repo = Path(root).resolve()
    if not isinstance(reason, str) or not reason.strip():
        raise _fail("ARGS", "ACTIVATE", "REFUSED_PRE_WRITE",
                    "truthful Core-change reason required")
    if not isinstance(executor, str) or not executor.strip():
        raise _fail("ARGS", "ACTIVATE", "REFUSED_PRE_WRITE", "executor required")
    ts = _now_utc(recorded_at)
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    set_rel = _lexical_rel(repo, str(set_path), "renewal publication set")
    expected_old = _read_bytes_bounded(repo, state_rel, "Production State")
    state = _strict_json_from_bytes(expected_old, "Production State")
    if not isinstance(state, dict):
        raise _fail("STATE_UNREADABLE", "ACTIVATE", "REFUSED_PRE_WRITE",
                    "Production State must be an object")
    cfg = _strict_json_from_bytes(
        _read_bytes_bounded(repo, "config/survey-production-v2.json", "production config"),
        "production config")
    sealed = validate_prepared_renewal_set(repo, state_rel, set_rel)
    seal = sealed["set"]
    try:
        selection_before = setmod.resolve_publication_selection(repo, cfg, state)
    except Exception as exc:
        raise _fail("SELECTION_BEFORE", "ACTIVATE", "REFUSED_PRE_WRITE",
                    f"before selection failed: {exc}") from exc
    try:
        if selection_before.get("mode") == "VERSIONED_ACTIVE":
            sel_set = selection_before.get("active_set_ref") or selection_before.get("set_ref")
            # Selection pins carry FILE SHAs (live pins, never self-digests).
            # Exact set/record selected path+FILE SHA and underlying identity;
            # alias inputs REFUSE BEFORE writes, NOT ALREADY_ACTIVE by same SHA.
            # Canonical true already-active keeps full strict CURRENT set
            # validate/readback readonly; same helper activates/resumes before
            # record creation; no source variable fallback aliases.
            input_seal_sha = _sha_bytes(_read_bytes_bounded(repo, set_rel, "ALREADY_ACTIVE seal"))
            if isinstance(sel_set, dict) and _check_already_active_set(
                    repo, set_rel, input_seal_sha, sel_set, "ALREADY_ACTIVE set"):
                errs = agent.validate_agent_state(repo, cfg, state)
                if errs:
                    raise _fail("ALREADY_ACTIVE_STATE", "ACTIVATE", "REFUSED_PRE_WRITE",
                                "ALREADY_ACTIVE State invalid: " + "; ".join(errs))
                validate_prepared_renewal_set(repo, state_rel, set_rel)
                pointer = state.get("publication_revalidation_provenance")
                if not isinstance(pointer, dict) or "path" not in pointer:
                    raise _fail("ALREADY_ACTIVE_STATE", "ACTIVATE", "REFUSED_PRE_WRITE",
                                "ALREADY_ACTIVE State pointer invalid")
                return {"status": "ALREADY_ACTIVE", "record_path": pointer.get("path"),
                        "state_path": state_rel, "observed": "new"}
    except RenewalHighError:
        raise
    except Exception:
        pass
    proof_ref = {"path": str(seal["renewal_proof_ref"]["path"]),
                 "sha256": str(seal["renewal_proof_ref"]["sha256"])}
    basis_ref = {"path": str(seal["renewal_basis_ref"]["path"]),
                 "sha256": str(seal["renewal_basis_ref"]["sha256"])}
    basis = _strict_json_from_bytes(
        _read_bytes_bounded(repo, _lexical_rel(repo, basis_ref["path"], "renewal basis"),
                            "renewal basis"), "renewal basis")
    authority = observe_renewal_authority(repo, state_rel, basis_ref["path"])
    entry = authority["entry"]
    effective7 = selection_before.get("effective7", {})
    try:
        digest = setmod.before_active_digest(effective7, entry["prior_candidate_ref"])
    except Exception as exc:
        raise _fail("SEAL_BIND", "ACTIVATE", "REFUSED_PRE_WRITE",
                    f"before_active_digest recompute failed: {exc}") from exc
    # Narrow fail-closed matching-intent detection BEFORE record creation.
    # ALREADY_ACTIVE exact-set handling above stays first with full readonly
    # validation. This scan refuses an existing INERT renewal record with the
    # same immutable set path+SHA and same basis/before binding, directing to
    # explicit resume only; different reason/executor/time never bypasses.
    # Truly new sets after other inert sets still allocate the next unused
    # sequence. Malformed/unknown/symlink/foreign records fail closed with
    # preserve/no-delete and exact-constraint diagnostics. Scan plus the
    # controlled O_EXCL claim below still refuses TOCTOU races; single-writer
    # bounded only, no global CAS claim.
    _current_set_ref = _file_ref(repo, set_rel, "activation seal")
    _current_basis_ref = {"path": str(basis_ref["path"]), "sha256": str(basis_ref["sha256"])}
    _current_before_ref = {"path": entry["state_rel"], "sha256": entry["state_sha"]}
    _parent_dir = str(Path(entry["prior_record_ref"]["path"]).parent.as_posix())
    _refuse_matching_intent_orphan(repo, _parent_dir, _current_set_ref,
                                   _current_basis_ref, _current_before_ref,
                                   state.get("publication_revalidation_provenance"),
                                   "ACTIVATE")
    record_rel = _next_record_rel(repo, entry["prior_record_ref"]["path"])
    _lexical_rel(repo, record_rel, "activation record")
    _walk_existing_ancestors(repo, _lexical_parts(record_rel, "activation record"),
                             "activation record")
    try:
        os.lstat(repo.resolve().joinpath(*record_rel.split("/")))
        raise _fail("RECORD_COLLISION", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "activation record already claimed (explicit resume required)")
    except FileNotFoundError:
        pass
    except RenewalHighError:
        raise
    except OSError as exc:
        raise _fail("HIGH_UNREADABLE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"activation record unreadable: {record_rel}: {exc}") from exc
    _recheck_entry_pins(repo, entry, "ACTIVATE")
    validation_ref = (state.get("checkpoint_provenance") or {}).get("validation", {})
    record: dict[str, Any] = {
        "schema_version": "2.0-rc1", "kind": "VERSIONED_RENEWAL_ACTIVATION_V1",
        "issue_id": state.get("issue_id"), "reason_class": "REVIEWED_VERSIONED_CORE_RENEWAL",
        "reason": reason.strip(), "lifecycle": "VALIDATED_DRAFT",
        "prior_checkpoint": {"path": str(validation_ref.get("path", "")),
                             "sha256": str(validation_ref.get("sha256", ""))},
        "supersedes": {"path": entry["prior_record_ref"]["path"],
                       "sha256": entry["prior_record_ref"]["sha256"]},
        "canonical_anchor": dict(basis.get("canonical_anchor", {})),
        "before_state_ref": {"path": entry["state_rel"], "sha256": entry["state_sha"]},
        "retained_copy_ref": {"path": str(basis["retained_copy_ref"]["path"]),
                              "sha256": str(basis["retained_copy_ref"]["sha256"]),
                              "byte_count": int(basis["retained_copy_ref"]["byte_count"])},
        "before_active_digest": digest,
        "before_candidate_ref": dict(entry["prior_candidate_ref"]),
        "set_ref": _file_ref(repo, set_rel, "activation seal"),
        "renewal_basis_ref": dict(basis_ref),
        "renewal_proof_ref": dict(proof_ref),
        # versioned_core is FLAT (8 contract fields + implementation_commit_sha,
        # no nested contract object) per the revalidation schema branch.
        "core": {**entry["current_contract"],
                 "implementation_commit_sha": entry["current_commit"]},
        "executor": executor.strip(), "recorded_at": ts,
        "establishment": {"state_sha256": entry["state_sha"],
                          "lifecycle": "VALIDATED_DRAFT",
                          "architecture_review": "approved",
                          "publication_preview": "pending", "freeze": "pending",
                          "release": "pending",
                          "implementation_commit_sha": entry["current_commit"],
                          "recorded_at": ts},
    }
    record_rel_out = record_rel
    record_bytes = core.json_bytes(record)
    _atomic_write_new(repo, record_rel_out, record_bytes, "activation record")
    try:
        record_file_sha = _sha_bytes(_read_bytes_bounded(repo, record_rel_out, "activation record pin"))
        _validate_pinned_instance(repo, record, record_rel_out, record_file_sha,
                                  "schemas/publication-surface-revalidation.schema.json",
                                  "Renewal Activation Record", "ACTIVATE",
                                  fail_code="SEAL_BIND")
    except RenewalHighError:
        raise
    except (ValueError, OSError) as exc:
        raise _fail("SEAL_BIND", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"activation record schema invalid: {exc}") from exc
    try:
        setmod.validate_activation_record(repo, Path(record_rel_out))
    except Exception as exc:
        code = getattr(exc, "code", None) or "SEAL_BIND"
        raise _fail(str(code), "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"low activation-record validation failed: {exc}") from exc
    # Pre-write chain/anchor/seal/basis validation BEFORE any State mutation.
    # New record/seal/basis/chain anchors must all equal the independently
    # derived chain identity (latest legacy before FIRST versioned, no rolling,
    # no originalPath fallback when kind is LEGACY). A known anchor
    # contradiction must refuse BEFORE State write (never write bad State
    # then report INDETERMINATE). Post-check below stays strict.
    try:
        from scripts import survey_versioned_renewal_history_v2 as hist
    except ImportError as exc:
        raise _fail("HISTORY_DIGEST_MISMATCH", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"historian unavailable for pre-write anchor check: {exc}") from exc
    try:
        _hist_pre = hist.verify_versioned_history(repo, record_rel_out)
    except Exception as exc:
        code = getattr(exc, "code", None) or "HISTORY_ANCESTOR"
        raise _fail(str(code), "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"pre-write history anchor invalid (refused before State mutation): {exc}") from exc
    _derived_pre = _hist_pre.get("canonical_anchor")
    if not isinstance(_derived_pre, dict) or set(_derived_pre) != {"kind", "ref"}:
        raise _fail("HISTORY_ANCESTOR", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "pre-write historian canonical_anchor missing")
    _rec_anchor = record.get("canonical_anchor")
    _basis_anchor = basis.get("canonical_anchor") if isinstance(basis, dict) else None
    if not isinstance(_rec_anchor, dict) or _rec_anchor != _derived_pre:
        raise _fail("HISTORY_ANCESTOR", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "pre-write new record anchor must equal chain-derived identity (refused before State mutation)")
    if not isinstance(_basis_anchor, dict) or _basis_anchor != _derived_pre:
        raise _fail("HISTORY_ANCESTOR", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "pre-write basis anchor must equal chain-derived identity (refused before State mutation)")
    # No fallback: LEGACY kind must reference an actual legacy record, never
    # the original validation checkpoint path.
    if isinstance(_derived_pre, dict) and _derived_pre.get("kind") == "LEGACY_REVALIDATION":
        _dr = _derived_pre.get("ref", {})
        _vr = (state.get("checkpoint_provenance") or {}).get("validation", {})
        if isinstance(_dr, dict) and isinstance(_vr, dict) and _dr.get("path") == _vr.get("path") and _dr.get("sha256") == _vr.get("sha256"):
            raise _fail("HISTORY_ANCESTOR", "ACTIVATE", "PRESERVED_INCOMPLETE",
                        "pre-write LEGACY anchor must not fallback to originalPath")
    # Simulate expected-after State readback BEFORE mutation (read-only, no
    # write): strict agent validation + selection on hypothetical post-State.
    # Catches anchor contradiction and Gate/receipt drift pre-write (e.g.
    # reader-surface-gate drift caused by wrong anchor via revalidation None
    # fallback to original). Any failure refuses BEFORE State write.
    _hypo_state = dict(state)
    _hypo_state["publication_revalidation_provenance"] = {"path": record_rel_out, "sha256": _sha_bytes(record_bytes)}
    try:
        _pre_errors = agent.validate_agent_state(repo, cfg, _hypo_state)
    except Exception as exc:
        raise _fail("SEAL_BIND", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"pre-write hypothetical post-State validation raised (refused before mutation): {exc}") from exc
    if _pre_errors:
        raise _fail("SEAL_BIND", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "pre-write hypothetical post-State invalid (refused before State mutation): " + "; ".join(_pre_errors))
    try:
        _sel_pre = setmod.resolve_publication_selection(repo, cfg, _hypo_state)
    except Exception as exc:
        raise _fail("SEAL_BIND", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"pre-write hypothetical post-State selection failed (refused before mutation): {exc}") from exc
    if _sel_pre.get("mode") != "VERSIONED_ACTIVE":
        raise _fail("SEAL_BIND", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "pre-write hypothetical post-State is not VERSIONED_ACTIVE (refused before mutation)")
    new_state = dict(state)
    new_state["publication_revalidation_provenance"] = {"path": record_rel_out,
                                                        "sha256": _sha_bytes(record_bytes)}
    new_bytes = core.json_bytes(new_state)
    _replace_state_bytes(repo, state_rel, expected_old, new_bytes, "activation State")
    post_bytes = _read_bytes_bounded(repo, state_rel, "activated State")
    post_state = _strict_json_from_bytes(post_bytes, "activated State")
    post_errors = agent.validate_agent_state(repo, cfg, post_state)
    if post_errors:
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "post-activation State invalid (preserved, no rollback/overwrite/adoption): "
                    + "; ".join(post_errors))
    try:
        selection_after = setmod.resolve_publication_selection(repo, cfg, post_state)
    except Exception as exc:
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"post-activation selection failed (preserved): {exc}") from exc
    if selection_after.get("mode") != "VERSIONED_ACTIVE":
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    "post-activation selection is not VERSIONED_ACTIVE (preserved)")
    validate_prepared_renewal_set(repo, state_rel, set_rel)
    return {"status": "ACTIVATED", "record_path": record_rel_out, "state_path": state_rel,
            "set_path": set_rel, "observed": "new"}


def _replace_state_bytes(repo: Path, state_rel: str, expected_old: bytes,
                         new_bytes: bytes, label: str) -> dict[str, Any]:
    """Known-byte State temp/replace: exclusive temp, fsync, os.replace,
    post-read verify. Write/close/fsync/replace/postread/foreign-inode seams
    are primary/secondary classified; referenced records are never deleted."""
    tmp_rel = f"{state_rel}.renewal-tmp"
    _lexical_rel(repo, tmp_rel, f"{label} temp")
    _walk_existing_ancestors(repo, _lexical_parts(tmp_rel, f"{label} temp"), label)
    _walk_existing_ancestors(repo, _lexical_parts(state_rel, label), label)
    try:
        os.lstat(repo.resolve().joinpath(*tmp_rel.split("/")))
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"{label} temp already exists (preserved, no overwrite): {tmp_rel}")
    except FileNotFoundError:
        pass
    except RenewalHighError:
        raise
    except OSError as exc:
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"{label} temp check failed (preserved): {exc}") from exc
    primary: Exception | None = None
    try:
        fd = os.open(str(repo.resolve().joinpath(*tmp_rel.split("/"))),
                     os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
    except OSError as exc:
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"{label} temp claim failed (preserved): {exc}") from exc
    try:
        os.write(fd, new_bytes)
        os.fsync(fd)
    except OSError as exc:
        primary = exc
    try:
        os.close(fd)
    except OSError as exc:
        if primary is None:
            primary = exc
        else:
            try:
                os.unlink(str(repo / tmp_rel))
            except OSError:
                pass
            raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                        f"{label} temp write failed: {exc}; close also failed: "
                        f"{primary}") from exc
    if primary is not None:
        try:
            os.unlink(str(repo / tmp_rel))
        except OSError:
            pass
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"{label} temp write failed (preserved): {primary}") from primary
    try:
        if _fd_safe_read(repo, tmp_rel, f"{label} temp post-write") != new_bytes:
            raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                        f"{label} temp post-write mismatch (preserved)")
        before_st = os.stat(repo.resolve().joinpath(*state_rel.split("/")))
        os.replace(str(repo.resolve().joinpath(*tmp_rel.split("/"))),
                   str(repo.resolve().joinpath(*state_rel.split("/"))))
        after_st = os.stat(repo.resolve().joinpath(*state_rel.split("/")))
        observed = _fd_safe_read(repo, state_rel, f"{label} post-replace")
    except RenewalHighError:
        raise
    except OSError as exc:
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"{label} replace failed (preserved): {exc}") from exc
    if observed != new_bytes:
        raise _fail("INDETERMINATE", "ACTIVATE", "PRESERVED_INCOMPLETE",
                    f"{label} post-replace mismatch (preserved)")
    return {"before_dev": before_st.st_dev, "before_ino": before_st.st_ino,
            "after_dev": after_st.st_dev, "after_ino": after_st.st_ino,
            "foreign_inode": (before_st.st_dev, before_st.st_ino)
                             != (after_st.st_dev, after_st.st_ino)}


def resume_renewal_activation(root: str | Path, state_path: str | Path,
                              record_path: str | Path) -> dict[str, Any]:
    """Explicit resume: reloads record+set+basis and compares the COMPLETE
    exact branch/issue/original checkpoint/anchor/supersedes/before-State/
    digest/Candidate/set/basis/new-core/executor/reason/time intent, not only
    set SHA. Recomputes before_active_digest with the existing effective7+
    Candidate algorithm; basis/proof are additionally covered by new set and
    record refs. Complete record + State exactly before -> ordinary activate
    collision resolved by explicit install. State exactly expected after ->
    readonly ALREADY_ACTIVE. Neither/unsafe -> INDETERMINATE preserve."""
    from scripts import survey_agent_control_v2 as agent
    from scripts import survey_publication_set_v2 as setmod
    from scripts import survey_production_v2 as core
    repo = Path(root).resolve()
    state_rel = _lexical_rel(repo, str(state_path), "Production State")
    record_rel = _lexical_rel(repo, str(record_path), "activation record")
    record_bytes = _read_bytes_bounded(repo, record_rel, "activation record")
    record = _strict_json_from_bytes(record_bytes, "activation record")
    if not isinstance(record, dict) or record.get("kind") != "VERSIONED_RENEWAL_ACTIVATION_V1" \
            or record.get("reason_class") != "REVIEWED_VERSIONED_CORE_RENEWAL":
        raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE",
                    "record is not a versioned renewal activation")
    try:
        setmod.validate_activation_record(repo, Path(record_rel))
    except Exception as exc:
        code = getattr(exc, "code", None) or "RECORD_COLLISION"
        raise _fail(str(code), "RESUME", "REFUSED_PRE_WRITE",
                    f"record low validation failed: {exc}") from exc
    set_ref = record.get("set_ref", {})
    basis_ref = record.get("renewal_basis_ref", {})
    proof_ref = record.get("renewal_proof_ref", {})
    set_bytes = _read_bytes_bounded(repo, _lexical_rel(repo, str(set_ref.get("path", "")),
                                                       "resume seal"), "resume seal")
    if _sha_bytes(set_bytes) != set_ref.get("sha256"):
        raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE", "resume seal bytes changed")
    basis_bytes = _read_bytes_bounded(repo, _lexical_rel(repo, str(basis_ref.get("path", "")),
                                                         "resume basis"), "resume basis")
    if _sha_bytes(basis_bytes) != basis_ref.get("sha256"):
        raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE",
                    "resume basis bytes changed")
    basis = _strict_json_from_bytes(basis_bytes, "resume basis")
    state_bytes = _read_bytes_bounded(repo, state_rel, "Production State")
    state = _strict_json_from_bytes(state_bytes, "Production State")
    cfg = _strict_json_from_bytes(
        _read_bytes_bounded(repo, "config/survey-production-v2.json", "production config"),
        "production config")
    before_ref = record.get("before_state_ref", {})
    expected_pointer = {"path": record_rel, "sha256": _sha_bytes(record_bytes)}
    live_pointer = state.get("publication_revalidation_provenance")
    before_rel_expected = _lexical_rel(repo, str(before_ref.get("path", "")), "before State")
    if _sha_bytes(state_bytes) == before_ref.get("sha256") \
            and state_rel == before_rel_expected:
        try:
            if _file_identity(repo, state_rel, "resume before State") != _file_identity(
                    repo, before_rel_expected, "resume before expected"):
                raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE",
                            "before State identity changed for exact spelling "
                            f"(alias?): {state_rel!r} vs {before_rel_expected!r}")
        except RenewalHighError:
            raise
        _refuse_alias_unless_exact(repo, state_rel, before_rel_expected,
                                   _sha_bytes(state_bytes), str(before_ref.get("sha256", "")),
                                   "resume before State", "RESUME")
        for key in ("issue_id", "reason", "executor", "recorded_at"):
            if record.get(key) is None:
                raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE",
                            f"record intent incomplete: {key}")
        try:
            selection = setmod.resolve_publication_selection(repo, cfg, state)
        except Exception as exc:
            raise _fail("SELECTION_BEFORE", "RESUME", "REFUSED_PRE_WRITE",
                        f"resume selection failed: {exc}") from exc
        try:
            recomputed = setmod.before_active_digest(selection.get("effective7", {}),
                                                     record.get("before_candidate_ref", {}))
        except Exception as exc:
            raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE",
                        f"resume digest recompute failed: {exc}") from exc
        if recomputed != record.get("before_active_digest"):
            raise _fail("RECORD_COLLISION", "RESUME", "REFUSED_PRE_WRITE",
                        "resume before_active_digest mismatch")
        validate_prepared_renewal_set(repo, state_rel, str(set_ref.get("path", "")))
        observe_renewal_authority(repo, state_rel, str(basis_ref.get("path", "")))
        new_state = dict(state)
        new_state["publication_revalidation_provenance"] = dict(expected_pointer)
        new_bytes = core.json_bytes(new_state)
        _replace_state_bytes(repo, state_rel, state_bytes, new_bytes, "resume State")
        post_state = _strict_json_from_bytes(
            _read_bytes_bounded(repo, state_rel, "resumed State"), "resumed State")
        post_errors = agent.validate_agent_state(repo, cfg, post_state)
        if post_errors:
            raise _fail("INDETERMINATE", "RESUME", "PRESERVED_INCOMPLETE",
                        "post-resume State invalid (preserved): " + "; ".join(post_errors))
        validate_prepared_renewal_set(repo, state_rel, str(set_ref.get("path", "")))
        return {"status": "ACTIVATED", "record_path": record_rel, "state_path": state_rel,
                "observed": "resumed"}
    if _check_already_active_record(repo, record_rel, _sha_bytes(record_bytes),
                                    live_pointer, "resume record", "RESUME"):
        post_errors = agent.validate_agent_state(repo, cfg, state)
        if post_errors:
            raise _fail("ALREADY_ACTIVE_STATE", "RESUME", "REFUSED_PRE_WRITE",
                        "ALREADY_ACTIVE State invalid: " + "; ".join(post_errors))
        validate_prepared_renewal_set(repo, state_rel, str(set_ref.get("path", "")))
        return {"status": "ALREADY_ACTIVE", "record_path": record_rel,
                "state_path": state_rel, "observed": "new"}
    observed = "unknown"
    try:
        observed = f"sha={_sha_bytes(state_bytes)[:12]}"
    except RenewalHighError:
        pass
    raise _fail("INDETERMINATE", "RESUME", "PRESERVED_INCOMPLETE",
                f"State neither before nor expected after ({observed}); "
                f"preserved, no rollback/overwrite/adoption")


def _verify_renewal_rerender_equality_inner(repo: Path, basis: dict[str, Any],
                                            basis_rel: str, proof_rel: str,
                                            proof: dict[str, Any]) -> dict[str, Any]:
    verdict = verify_renewal_rerender_equality(repo, basis_rel, proof_rel)
    if verdict.get("reader_equal") is not True or verdict.get("trio_equal") is not True:
        raise _fail("REUSE_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "in-memory rederivation does not equal old targets")
    if proof.get("reader_digest") != verdict.get("reader_digest") \
            or proof.get("trio_digest") != verdict.get("trio_digest"):
        raise _fail("REUSE_TARGET_MISMATCH", "FINALIZE", "REFUSED_PRE_WRITE",
                    "proof digests differ from independent rederivation")
    return verdict


def verify_renewal_rerender_equality(root: str | Path, basis_path: str | Path,
                                     proof_path: str | Path) -> dict[str, Any]:
    """U NEW: CURRENT renderer/style to disposable temp trio + complete reader
    vs OLD prior-relative bytes at PRIOR paths (never P/publication vs R
    confusion). Mismatch -> REUSE_TARGET_MISMATCH, no auto-convert to C."""
    from scripts import survey_production_v2 as core
    from scripts import survey_versioned_renewal_source_v2 as srcmod
    repo = Path(root).resolve()
    basis_rel = _lexical_rel(repo, str(basis_path), "renewal basis")
    proof_rel = _lexical_rel(repo, str(proof_path), "renewal proof")
    basis = _strict_json_from_bytes(
        _read_bytes_bounded(repo, basis_rel, "renewal basis"), "renewal basis")
    proof = _strict_json_from_bytes(
        _read_bytes_bounded(repo, proof_rel, "renewal proof"), "renewal proof")
    try:
        current = srcmod.load_renewal_accepted_authority(repo, basis_rel)
    except Exception as exc:
        code = getattr(exc, "code", None) or "BASIS_ACCEPTED_SET_DRIFT"
        raise _fail(str(code), "RERENDER", "REFUSED_PRE_WRITE",
                    f"accepted-authority assembly failed: {exc}") from exc
    surface = current.get("surface")
    route = basis.get("generator_route")
    if route == WEEKLY_ROUTE:
        reader_bytes = core.json_bytes(surface)
        from scripts.survey_weekly_derivation_v2 import (
            render_bibliography as _w_render_bib, render_main as _w_render_main)
        main_bytes = _w_render_main(surface).encode("utf-8")
        bib_bytes = _w_render_bib(surface).encode("utf-8")
    elif route == LONGFORM_ROUTE:
        from scripts.survey_longform_derivation_v2 import (
            canonical_reader_bytes as _lf_bytes)
        from scripts.survey_longform_generated_v2 import (
            render_bibliography as _lf_render_bib, render_main as _lf_render_main)
        reader_bytes = _lf_bytes(surface)
        main_bytes = _lf_render_main(surface).encode("utf-8")
        bib_bytes = _lf_render_bib(surface).encode("utf-8")
    else:
        raise _fail("BASIS_ACCEPTED_SET_DRIFT", "RERENDER", "REFUSED_PRE_WRITE",
                    f"unsupported route: {route}")
    reviewed = basis.get("reviewed_reader_ref", {})
    live_reader = _read_bytes_bounded(repo, _lexical_rel(repo, str(reviewed.get("path", "")),
                                                         "reviewed reader"), "reviewed reader")
    reader_equal = (live_reader == reader_bytes)
    trio = proof.get("output_trio_refs", {})
    trio_equal = True
    for key, rendered in (("primary", main_bytes), ("bibliography", bib_bytes)):
        ref = trio.get(key, {})
        live = _read_bytes_bounded(repo, _lexical_rel(repo, str(ref.get("path", "")),
                                                      f"rerender trio {key}"),
                                   f"rerender trio {key}")
        if live != rendered or _sha_bytes(live) != ref.get("sha256"):
            trio_equal = False
    from scripts.survey_editorial_staged_source_v2 import STYLE_PATH as _rerender_style_const
    current_style_data = _read_bytes_bounded(
        repo, _lexical_rel(repo, _rerender_style_const.as_posix(), "current style template"),
        "current style template")
    style_ref = trio.get("style", {})
    style_live = _read_bytes_bounded(repo, _lexical_rel(repo, str(style_ref.get("path", "")),
                                                       "rerender trio style"),
                                     "rerender trio style")
    if _sha_bytes(style_live) != style_ref.get("sha256"):
        trio_equal = False
    if _sha_bytes(current_style_data) != _sha_bytes(style_live):
        trio_equal = False
    # Descriptive digests recomputed with the EXACT Layer-B formulas (weekly:
    # json_bytes surface; trio object {primary,bibliography,style} via
    # sha256_object) using CURRENT style input for both C writes and U proof
    # old output (ROOT clarification). S must compare the same current style;
    # if S needs a change, report the exact interface for root to coordinate.
    trio_digest = core.sha256_object({
        "primary": _sha_bytes(main_bytes),
        "bibliography": _sha_bytes(bib_bytes),
        "style": _sha_bytes(current_style_data)})
    disposition = "REUSED_TARGETS" if (reader_equal and trio_equal) else "MISMATCH"
    return {"reader_equal": reader_equal, "trio_equal": trio_equal,
            "disposition": disposition, "reader_digest": _sha_bytes(reader_bytes),
            "trio_digest": trio_digest}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="survey_versioned_renewal_v2",
                                     description="Versioned same-reader renewal HIGH operation")
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--root", required=True)
    p.add_argument("--state", required=True)
    p.add_argument("--renewal-id", required=True)
    p.add_argument("--intent", required=True, choices=list(INTENTS))
    p.add_argument("--manuscript-spec", required=True)
    p.add_argument("--toolchain-spec", default=None)
    p.add_argument("--executor", required=True)
    p.add_argument("--recorded-at", default=None)
    f = sub.add_parser("finalize")
    f.add_argument("--root", required=True)
    f.add_argument("--state", required=True)
    f.add_argument("--basis", required=True)
    f.add_argument("--checks", required=True)
    f.add_argument("--semantic-review", default=None)
    f.add_argument("--visual-review", default=None)
    f.add_argument("--executor", required=True)
    f.add_argument("--recorded-at", default=None)
    t = sub.add_parser("prepare-targets")
    t.add_argument("--root", required=True)
    t.add_argument("--basis", required=True)
    t.add_argument("--executor", required=True)
    t.add_argument("--recorded-at", default=None)
    vr = sub.add_parser("validate-receipt")
    vr.add_argument("--root", required=True)
    vr.add_argument("--receipt", required=True)
    vs = sub.add_parser("validate-set")
    vs.add_argument("--root", required=True)
    vs.add_argument("--state", required=True)
    vs.add_argument("--set", required=True)
    a = sub.add_parser("activate")
    a.add_argument("--root", required=True)
    a.add_argument("--state", required=True)
    a.add_argument("--set", required=True)
    a.add_argument("--reason", required=True)
    a.add_argument("--executor", required=True)
    a.add_argument("--recorded-at", default=None)
    r = sub.add_parser("resume")
    r.add_argument("--root", required=True)
    r.add_argument("--state", required=True)
    r.add_argument("--record", required=True)
    h = sub.add_parser("history")
    h.add_argument("--root", required=True)
    h.add_argument("--record", required=True)
    args = parser.parse_args(argv)
    try:
        if args.command == "prepare":
            result = prepare_renewal(args.root, args.state, args.renewal_id, args.intent,
                                     args.manuscript_spec, args.toolchain_spec,
                                     args.executor, args.recorded_at)
        elif args.command == "finalize":
            result = finalize_renewal(args.root, args.state, args.basis, args.checks,
                                      args.semantic_review, args.visual_review,
                                      args.executor, args.recorded_at)
        elif args.command == "prepare-targets":
            result = prepare_renewal_targets(args.root, args.basis,
                                             args.executor, args.recorded_at)
        elif args.command == "validate-receipt":
            result = validate_renewal_receipt(args.root, args.receipt)
        elif args.command == "validate-set":
            result = validate_prepared_renewal_set(args.root, args.state, args.set)
        elif args.command == "activate":
            result = activate_renewal(args.root, args.state, args.set, args.reason,
                                      args.executor, args.recorded_at)
        elif args.command == "resume":
            result = resume_renewal_activation(args.root, args.state, args.record)
        elif args.command == "history":
            result = verify_renewal_history(args.root, args.record)
        else:
            parser.error(f"unknown command: {args.command}")
    except RenewalHighError as exc:
        print(json.dumps({"phase": exc.phase, "code": exc.code,
                          "disposition": exc.disposition, "detail": exc.detail}),
              file=sys.stderr)
        return 2
    except Exception:
        traceback.print_exc(file=sys.stderr)
        return 1
    print(json.dumps({k: v for k, v in result.items()
                      if k not in ("entry", "basis", "proof", "set", "state")}, indent=1,
                     default=str))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())






