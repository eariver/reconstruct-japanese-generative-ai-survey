#!/usr/bin/env python3
"""Exact-byte publication authority for Survey Production Core v2.

Publication Preview is the second and final normal Human Gate. The redesigned
candidate is finalized only after ChatGPT has authored an explicit reader-facing
source and completed semantic/editorial plus exact-PDF visual review. Human
approval then binds that already-reviewed candidate; Freeze/Release re-use the
same exact authority instead of introducing a second post-approval quality pass.
"""

from __future__ import annotations

import hashlib
import json
import os
import stat
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from scripts import survey_production_v2 as core
from scripts import survey_quality_v2 as quality
from scripts import survey_reader_publication_v2 as reader
from scripts import survey_schema_v2 as schema_gate

CANDIDATE_SCHEMA = Path("schemas/publication-candidate-v2.schema.json")
PREVIEW_APPROVAL_SCHEMA = Path("schemas/publication-preview-approval-v2.schema.json")
VISUAL_REVIEW_SCHEMA = Path("schemas/visual-review-record-v2.schema.json")  # legacy post-approval record
FREEZE_SCHEMA = Path("schemas/freeze-record-v2.schema.json")
RELEASE_MANIFEST_SCHEMA = Path("schemas/release-manifest-v2.schema.json")
MERGE_VERIFICATION_SCHEMA = Path("schemas/merge-verification-v2.schema.json")
RELEASE_RECORD_SCHEMA = Path("schemas/release-record-v2.schema.json")


def _rel(repo_root: Path, path: Path) -> str:
    root = repo_root.resolve()
    resolved = path.resolve()
    try:
        return str(resolved.relative_to(root)).replace("\\", "/")
    except ValueError as exc:
        raise ValueError(f"publication artifact must be repository-local: {path}") from exc


def _safe_file(repo_root: Path, path: Path, label: str) -> Path:
    _rel(repo_root, path)
    norm = _lexical_repo_path(repo_root, path, label)
    _check_output_ancestors(repo_root.resolve(), norm, label)
    resolved = path.resolve()
    if resolved.is_symlink() or not resolved.is_file():
        raise ValueError(f"{label} missing or unsafe: {path}")
    # Prefix symlink cannot redirect: lexical norm must equal resolved rel.
    # If a symlinked ancestor redirected the resolve, norm and resolved rel
    # would differ (or the ancestor check above would already have refused).
    try:
        resolved_rel = str(resolved.relative_to(repo_root.resolve())).replace("\\", "/")
    except ValueError as exc:
        raise ValueError(f"{label} escapes repository root: {path}") from exc
    if Path(resolved_rel).as_posix() != norm.relative_to(repo_root.resolve()).as_posix():
        raise ValueError(f"{label} ancestor redirect refused: {path}")
    return resolved


def _authority(repo_root: Path, path: Path) -> dict[str, Any]:
    value = _safe_file(repo_root, path, "publication authority input")
    return {"path": _rel(repo_root, value), "sha256": core.sha256_file(value), "byte_count": value.stat().st_size}


def _validate_authority(repo_root: Path, ref: dict[str, Any], label: str) -> Path:
    if not isinstance(ref, dict) or set(ref) != {"path", "sha256", "byte_count"}:
        raise ValueError(f"{label} authority fields invalid")
    artifact = _safe_file(repo_root, repo_root / ref["path"], label)
    if core.sha256_file(artifact) != ref["sha256"] or artifact.stat().st_size != ref["byte_count"]:
        raise ValueError(f"{label} bytes drifted")
    return artifact


def _write_immutable(path: Path, payload: dict[str, Any], label: str) -> Path:
    if path.exists():
        if core.load_json(path) != payload:
            raise ValueError(f"refusing to overwrite divergent {label}: {path}")
        return path
    core.write_json(path, payload)
    return path


def public_issue_slug_from_profile(profile: dict[str, Any]) -> str:
    """Derive the public issue slug from the exact Profile survey_root authority.

    Internal issue IDs and reader-facing slugs are intentionally not always
    identical; the basename of ``paths.survey_root`` is the public identity.
    """
    survey_root = profile.get("paths", {}).get("survey_root")
    if not isinstance(survey_root, str) or not survey_root.strip():
        raise ValueError("Production Profile survey_root required for public issue identity")
    slug = Path(survey_root).name
    if not slug or slug in {".", ".."} or "/" in slug or "\\" in slug:
        raise ValueError("Production Profile survey_root has invalid public issue slug")
    return slug


def profile_release_identity(profile: dict[str, Any]) -> str:
    """Derive release identity from the validated Profile slug and publication profile."""
    slug = public_issue_slug_from_profile(profile)
    publication_profile = profile.get("publication_profile")
    if publication_profile == "WEEKLY_MAGAZINE":
        return f"weekly/{slug}"
    if publication_profile == "LONGFORM_SPECIAL":
        return f"special/{slug}"
    raise ValueError(f"unsupported publication profile: {publication_profile}")


def _lexical_repo_path(repo_root: Path, path: Path, label: str) -> Path:
    """Lexically normalize a repo-local path without resolving symlinks.

    Accepts repo-relative paths and absolute paths inside ``repo_root``.
    Backslashes and any lexical ``..`` segment are rejected before
    normalization: ``normpath`` would otherwise erase a ``..`` component
    whose resolution through a symlinked ancestor differs from the
    normalized spelling. Repository escapes are rejected as well, so later
    symlink checks observe the true ancestry.
    """
    raw = str(path)
    if "\\" in raw:
        raise ValueError(f"{label} must not contain backslashes: {path}")
    if ".." in Path(raw).parts:
        raise ValueError(f"{label} must not contain '..' segments: {path}")
    root = repo_root.resolve()
    candidate = path if path.is_absolute() else (root / path)
    normalized = Path(os.path.normpath(str(candidate)))
    try:
        normalized.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"{label} escapes repository root: {path}") from exc
    return normalized


def _check_output_ancestors(root: Path, target: Path, label: str) -> None:
    """Refuse symlinked or non-directory existing ancestor components via lstat."""
    rel = target.relative_to(root)
    cursor = root
    for part in rel.parts[:-1]:
        cursor = cursor / part
        try:
            st = os.lstat(cursor)
        except FileNotFoundError:
            # Nothing below a missing component can exist; it is created at install.
            return
        except OSError as exc:
            raise ValueError(f"{label} ancestor unreadable: {cursor}") from exc
        if stat.S_ISLNK(st.st_mode):
            raise ValueError(f"{label} ancestor is a symlink: {cursor}")
        if not stat.S_ISDIR(st.st_mode):
            raise ValueError(f"{label} ancestor is not a directory: {cursor}")


def _fd_read_bytes(repo_root: Path, rel: str, label: str) -> bytes:
    """FD-safe single read: lexical + ancestor no-follow + lstat leaf + O_NOFOLLOW open + fstat + read + close-checked.

    Returns pinned bytes. No second fresh read (no fresh-vs-fresh). Caller hashes
    these bytes for pin check and parses the SAME bytes (no re-read).
    """
    norm = _lexical_repo_path(repo_root, repo_root.resolve().joinpath(*rel.split("/")), label)
    _check_output_ancestors(repo_root.resolve(), norm, label)
    try:
        lst = os.lstat(norm)
    except FileNotFoundError as exc:
        raise ValueError(f"{label} missing: {rel}") from exc
    except OSError as exc:
        raise ValueError(f"{label} unreadable: {rel}: {exc}") from exc
    if stat.S_ISLNK(lst.st_mode):
        raise ValueError(f"{label} is a symlink: {rel}")
    if not stat.S_ISREG(lst.st_mode):
        raise ValueError(f"{label} is not a regular file: {rel}")
    try:
        fd = os.open(norm, os.O_RDONLY | os.O_NOFOLLOW)
    except OSError as exc:
        raise ValueError(f"{label} open refused (symlink/unsafe): {rel}: {exc}") from exc
    try:
        fst = os.fstat(fd)
        if not stat.S_ISREG(fst.st_mode):
            raise ValueError(f"{label} is not a regular file after open: {rel}")
        if (fst.st_dev, fst.st_ino) != (lst.st_dev, lst.st_ino):
            raise ValueError(f"{label} replaced between lstat and open: {rel}")
        chunks: list[bytes] = []
        total = 0
        while True:
            chunk = os.read(fd, 65536)
            if not chunk:
                break
            total += len(chunk)
            if total > 20 * 1024 * 1024:
                raise ValueError(f"{label} file too large: {rel}")
            chunks.append(chunk)
        data = b"".join(chunks)
    except OSError as exc:
        raise ValueError(f"{label} read failed: {rel}: {exc}") from exc
    finally:
        try:
            os.close(fd)
        except OSError as exc:
            raise ValueError(f"{label} close failed: {rel}: {exc}") from exc
    if len(data) < 1:
        raise ValueError(f"{label} empty: {rel}")
    return data


def _strict_json_from_pinned(data: bytes, label: str) -> Any:
    """Strict JSON parse from already-pinned bytes (no re-read, duplicate refusal)."""
    if len(data) > 8 * 1024 * 1024:
        raise ValueError(f"{label} JSON too large")
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise ValueError(f"{label} is not UTF-8 JSON: {exc}") from exc
    def _no_dup(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for k, v in pairs:
            if k in out:
                raise ValueError(f"{label} duplicate JSON key: {k}")
            out[k] = v
        return out
    try:
        return json.loads(text, object_pairs_hook=_no_dup)
    except json.JSONDecodeError as exc:
        raise ValueError(f"{label} is not valid JSON: {exc}") from exc


def _existing_compatible_bytes(target: Path, payload: dict[str, Any], label: str) -> bytes | None:
    """Return preserved existing bytes when the file holds exactly payload, else None.

    Existing symlinks, non-regular files and divergent bytes are refused.
    Equal-payload files keep their exact bytes (including formatting); the
    caller hashes the returned bytes rather than reserializing.
    """
    try:
        st = os.lstat(target)
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise ValueError(f"{label} target unreadable: {target}") from exc
    if stat.S_ISLNK(st.st_mode):
        raise ValueError(f"{label} target is a symlink: {target}")
    if not stat.S_ISREG(st.st_mode):
        raise ValueError(f"{label} target is not a regular file: {target}")
    try:
        data = target.read_bytes()
        existing = json.loads(data.decode("utf-8"))
    except (OSError, ValueError, UnicodeDecodeError) as exc:
        raise ValueError(f"refusing to overwrite divergent {label}: {target}") from exc
    if not isinstance(existing, dict) or existing != payload:
        raise ValueError(f"refusing to overwrite divergent {label}: {target}")
    return data


def _prepare_freeze_inputs(repo_root: Path, candidate_path: Path, approval_path: Path) -> dict[str, Any]:
    """Validate and resolve the joint Freeze authority shared by both builders.

    Resolves the actual Candidate, its typed Preview approval, the exact
    approval→Candidate path/hash binding, the Candidate-bound pre-preview
    VISUAL record, exact source/PDF/page relationships and the Candidate-bound
    Production Profile (via the validated quality bundle). Captures a
    bounded byte snapshot of every authority input for install-boundary
    rechecks. No writes.
    """
    candidate = validate_candidate(repo_root, candidate_path)
    approval = validate_preview_approval(repo_root, approval_path, issue_id=candidate["issue_id"])
    candidate_rel = _rel(repo_root, candidate_path)
    candidate_file = _safe_file(repo_root, candidate_path, "Publication Candidate")
    # Renewal proof derivation: the proof comes from the validated Candidate's
    # own renewal branch (never ambient/global context). It is passed to the
    # direct review loader below and required to equal the bundle binding.
    renewal_proof_ref = candidate.get("renewal_source_proof_ref")
    if renewal_proof_ref is not None:
        if not isinstance(renewal_proof_ref, dict) or set(renewal_proof_ref) != {"path", "sha256"}:
            raise ValueError("Candidate renewal proof ref invalid")
    if (
        approval["publication_candidate_path"] != candidate_rel
        or approval["publication_candidate_sha256"] != core.sha256_file(candidate_file)
    ):
        raise ValueError("Publication Preview approval does not bind the exact Publication Candidate being frozen")
    visual_path = _safe_file(
        repo_root, repo_root / candidate["visual_review"]["path"], "Candidate pre-preview visual review"
    )
    visual = reader.validate_review_record(
        repo_root, visual_path, issue_id=candidate["issue_id"], expected_kind="VISUAL",
        renewal_source_proof_ref=renewal_proof_ref if isinstance(renewal_proof_ref, dict) else None
    )
    if candidate["pdf"]["sha256"] != approval["pdf_sha256"] or visual["pdf"]["sha256"] != approval["pdf_sha256"]:
        raise ValueError("Freeze exact-PDF authority chain diverged")
    bundle_path = core.repo_local_path(repo_root, candidate["quality_bundle"]["path"], "Quality Bundle")
    bundle = quality.validate_bundle(repo_root, bundle_path, issue_id=candidate["issue_id"],
                                     expected_proof_ref=renewal_proof_ref if isinstance(renewal_proof_ref, dict) else None)
    if renewal_proof_ref is not None and bundle.get("renewal_source_proof_ref") != renewal_proof_ref:
        raise ValueError("Freeze bundle proof must equal the Candidate-derived proof")
    profile_ref = bundle["production_profile"]
    profile_path = core.repo_local_path(repo_root, profile_ref["path"], "Quality Production Profile")
    if not profile_path.is_file() or core.sha256_file(profile_path) != profile_ref["sha256"]:
        raise ValueError("Quality Bundle Production Profile authority drift")
    profile = core.load_json(profile_path)
    if profile.get("issue_id") != candidate["issue_id"]:
        raise ValueError("Production Profile issue identity diverges from Publication Candidate")
    if profile.get("publication_profile") != candidate["publication_profile"]:
        raise ValueError("Production Profile publication identity diverges from Publication Candidate")
    try:
        source_root = core.repo_local_path(repo_root, profile["paths"]["source_root"], "source_root")
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"Production Profile source_root invalid: {exc}") from exc
    snapshot_files = [
        candidate_file,
        _safe_file(repo_root, approval_path, "Publication Preview approval"),
        visual_path,
        bundle_path,
        profile_path,
        _safe_file(repo_root, repo_root / candidate["reader_manuscript"]["path"], "Candidate Reader Manuscript"),
        _safe_file(repo_root, repo_root / candidate["source"]["path"], "Candidate source"),
        _safe_file(repo_root, repo_root / candidate["pdf"]["path"], "Candidate PDF"),
        _safe_file(
            repo_root, repo_root / candidate["semantic_review"]["path"], "Candidate semantic review"
        ),
    ]
    snapshot: dict[str, str] = {}
    for item in snapshot_files:
        rel = _rel(repo_root, item)
        snapshot[rel] = core.sha256_file(item)
    # B1 FULL typed reachable evidence (finite, no generic walk, FD-safe, dedup/conflict, T vs E):
    # Contract §11.2 + R3 freeze-snapshot function require snapshot + _preflight overlap
    # to cover proof, basis, retained COPY, trio, receipt-epoch + current-tool-epoch
    # closures, candidate proof ref, gate receipt ref, plus ALL typed reachable evidence
    # actually validated by Freeze contextual validators (candidate/approval/visual/bundle/
    # manuscript/source/pdf/semantic + renewal S proof verification), with no omission
    # because a dependency is outside the new R. Includes Config/Profile/record/Candidate/
    # reviews/scope/old build/trio/receipts/retention and typed research wrapper/evidence/
    # cards/raw/X/ledger/selection/archive/draft dependencies. Historical observed bindings
    # SOURCE docs E + schema/tool paths distinction T: historical tool commits do NOT require
    # OLD tool LIVE SHA; snapshot live current tool/schema deps (closure) and LIVE old E/COPY,
    # not compare historical T live (history at commit correct). Tool current new epoch
    # appropriately proof expired refuses (S/H BASIS_CURRENT_TOOL_DRIFT, not snapshot false).
    # Scope's correct field source owner from current proof HIST lineage (observed bindings
    # derived from HIST graph at basis capture, schema_path == semantic-review), no first
    # row fallback. ROOT B1 overwrite retraction preserved: _existing_compatible_bytes REFUSES
    # divergent bytes, missing overlap was gap (now closed for full authority, not just direct63).
    # Closed current63 subset/basis refs alone NOT complete (this fix expands to full).
    # No arbitrary dict-ref walk/URLs/path strings: explicit fixed keys + typed lists only
    # (each element validated as {name,path,sha256} or {path,sha256} with hex SHA, no "path"
    # substring search, no URL scheme acceptance via "://" refuse). Zero extra authority map
    # permission: returned list used BOTH for snapshot rechecks AND preflight lex/inode guards;
    # snapshot loader checks each ref independently via FD-safe + SHA (dict is NOT a permit).
    # Freeze full candidate validation still mandatory (done above before collection).
    renewal_authority: list[str] = []
    pinned_docs: dict[str, Any] = {}
    def _is_hex64_local(s: Any) -> bool:
        return isinstance(s, str) and len(s) == 64 and all(c in "0123456789abcdef" for c in s)
    def _add_live_fd(rel: str, expected_sha: str | None, label: str) -> bytes:
        if not isinstance(rel, str) or not rel or "\\" in rel or "://" in rel:
            raise ValueError(f"{label} path invalid (no URL/backslash): {rel}")
        data = _fd_read_bytes(repo_root, rel, label)
        live_sha = hashlib.sha256(data).hexdigest()
        if expected_sha is not None:
            if not _is_hex64_local(expected_sha):
                raise ValueError(f"{label} expected SHA invalid: {rel}")
            if live_sha != expected_sha:
                raise ValueError(f"{label} bytes changed: {rel}")
        if rel in snapshot and snapshot[rel] != live_sha:
            raise ValueError(f"Freeze renewal snapshot alias conflict: {rel}")
        snapshot[rel] = live_sha
        if rel not in renewal_authority:
            renewal_authority.append(rel)
        return data
    def _load_typed_doc(rel: str, expected_sha: str | None, label: str) -> Any:
        data = _add_live_fd(rel, expected_sha, label)
        doc = _strict_json_from_pinned(data, label)
        pinned_docs[rel] = doc
        return doc
    def _req_file_ref(obj: Any, label: str) -> tuple[str, str]:
        if not isinstance(obj, dict) or set(obj.keys()) != {"path", "sha256"}:
            raise ValueError(f"{label} ref fields invalid (must be exact {{path,sha256}})")
        p, s = obj.get("path"), obj.get("sha256")
        if not isinstance(p, str) or not p or "\\" in p or "://" in p:
            raise ValueError(f"{label} path invalid: {p}")
        if not _is_hex64_local(s):
            raise ValueError(f"{label} SHA invalid: {p}")
        return (p, s)
    def _req_sized_ref(obj: Any, label: str) -> tuple[str, str]:
        if not isinstance(obj, dict):
            raise ValueError(f"{label} ref must be object")
        # FileRef {path,sha256,byte_count} or sized variants with extra page_count (pdf) – allow exact known shapes only.
        if set(obj.keys()) not in ({"path", "sha256", "byte_count"}, {"path", "sha256", "byte_count", "page_count"}):
            raise ValueError(f"{label} sized ref fields invalid: {sorted(obj.keys())}")
        p, s = obj.get("path"), obj.get("sha256")
        if not isinstance(p, str) or not p or "\\" in p or "://" in p:
            raise ValueError(f"{label} path invalid: {p}")
        if not _is_hex64_local(s):
            raise ValueError(f"{label} SHA invalid: {p}")
        return (p, s)
    if renewal_proof_ref is not None:
        # Proof (fully reloaded public path, FD-safe single read, no fresh-vs-fresh).
        proof_rel, proof_sha = _req_file_ref(renewal_proof_ref, "renewal proof ref")
        proof_data = _add_live_fd(proof_rel, proof_sha, "renewal source proof")
        proof_doc = _strict_json_from_pinned(proof_data, "renewal source proof")
        pinned_docs[proof_rel] = proof_doc
        # Basis via proof (explicit basis_ref, not generic).
        basis_ref_raw = proof_doc.get("basis_ref")
        basis_rel, basis_sha = _req_file_ref(basis_ref_raw, "renewal basis ref")
        basis_data = _add_live_fd(basis_rel, basis_sha, "renewal basis")
        basis_doc = _strict_json_from_pinned(basis_data, "renewal basis")
        pinned_docs[basis_rel] = basis_doc
        # Retained COPY (LIVE old E/COPY, not live before_state_ref which may have moved after activation).
        retained_raw = basis_doc.get("retained_copy_ref")
        if not isinstance(retained_raw, dict) or set(retained_raw.keys()) != {"path", "sha256", "byte_count"}:
            raise ValueError("renewal retained COPY ref fields invalid")
        ret_rel, ret_sha = _req_file_ref({"path": retained_raw.get("path"), "sha256": retained_raw.get("sha256")}, "renewal retained COPY")
        ret_data = _add_live_fd(ret_rel, ret_sha, "renewal retained COPY")
        if len(ret_data) != int(retained_raw.get("byte_count", -1)):
            raise ValueError(f"renewal retained COPY byte_count mismatch: {ret_rel}")
        # Trio (explicit primary/bibliography/style, not generic dict walk).
        trio_raw = proof_doc.get("output_trio_refs")
        if not isinstance(trio_raw, dict):
            raise ValueError("renewal trio refs must be object")
        for tkey in ("primary", "bibliography", "style"):
            tref = trio_raw.get(tkey)
            tp, ts = _req_sized_ref(tref, f"renewal trio {tkey}") if isinstance(tref, dict) and "byte_count" in tref else _req_file_ref(tref, f"renewal trio {tkey}")
            _add_live_fd(tp, ts, f"renewal trio {tkey}")
        # Current closure (live current tool/schema deps, 63 rows, explicit typed list).
        epoch_raw = basis_doc.get("current_tool_epoch")
        if not isinstance(epoch_raw, dict):
            raise ValueError("renewal current_tool_epoch must be object")
        closure_raw = epoch_raw.get("closure")
        if not isinstance(closure_raw, list):
            raise ValueError("renewal closure must be array")
        for row in closure_raw:
            if not isinstance(row, dict) or not isinstance(row.get("path"), str) or not _is_hex64_local(row.get("sha256")):
                raise ValueError(f"renewal closure row invalid: {row}")
            cp, cs = str(row.get("path")), str(row.get("sha256"))
            if "\\" in cp or "://" in cp:
                raise ValueError(f"renewal closure path invalid: {cp}")
            _add_live_fd(cp, cs, f"renewal closure {row.get('name', '')}")
        # Config (FIXED path, live pin for recheck + overlap, no expected SHA – not in typed refs).
        _add_live_fd("config/survey-production-v2.json", None, "Freeze implementation config")
        # Prior refs (explicit 3, live old E – prior files preserved, live should match).
        for bkey in ("prior_selected_ref", "prior_record_ref", "prior_candidate_ref"):
            pref = basis_doc.get(bkey)
            pp, ps = _req_file_ref(pref, f"renewal {bkey}")
            _add_live_fd(pp, ps, f"renewal {bkey}")
        # Prior set doc (fully reloaded, FD-safe single read, to get source-receipt role – explicit key, no generic walk).
        prior_set_rel = str(basis_doc.get("prior_selected_ref", {}).get("path", ""))
        prior_set_data = _fd_read_bytes(repo_root, prior_set_rel, "renewal prior seal")
        # Verify prior set SHA already pinned above (snapshot contains it) – parse same bytes (no re-read).
        prior_set_doc = _strict_json_from_pinned(prior_set_data, "renewal prior seal")
        pinned_docs[prior_set_rel] = prior_set_doc
        roles_raw = prior_set_doc.get("roles")
        if not isinstance(roles_raw, dict):
            raise ValueError("renewal prior seal roles must be object")
        # Prior receipt via explicit "source-receipt" key (fixed, not generic).
        if "source-receipt" not in roles_raw:
            raise ValueError("renewal prior seal lacks source-receipt role")
        pr_role = roles_raw.get("source-receipt")
        prp, prs = _req_sized_ref(pr_role, "renewal prior receipt") if isinstance(pr_role, dict) and "byte_count" in pr_role else _req_file_ref(pr_role, "renewal prior receipt")
        _add_live_fd(prp, prs, "renewal prior receipt")
        # New receipt/gate/set via FIXED R/ prefix (proposal_namespace/renewal_id from basis, explicit – no generic).
        prop_ns = basis_doc.get("proposal_namespace")
        rid = basis_doc.get("renewal_id")
        if not isinstance(prop_ns, str) or not prop_ns or "\\" in prop_ns or "://" in prop_ns:
            raise ValueError("renewal proposal_namespace invalid")
        if not isinstance(rid, str) or not rid:
            raise ValueError("renewal renewal_id invalid")
        r_prefix = f"{prop_ns}/renewals/{rid}"
        for rname, rfile in (("receipt", "validated-source-manifest.json"), ("gate", "reader-surface-gate-v2.json"), ("set", "publication-set.json")):
            rrel = f"{r_prefix}/{rfile}"
            # Live pin for overlap + recheck (no expected SHA in proof/basis – zero extra permit).
            # If file absent (e.g., set not yet created for U? Actually set exists after finalize – Freeze happens after finalize, so all three exist).
            try:
                _add_live_fd(rrel, None, f"renewal new {rname}")
            except ValueError as exc:
                # If new set/gate/receipt absent, refuse with explicit missing (not silent skip) – Freeze requires complete renewal set.
                raise ValueError(f"renewal new {rname} missing for Freeze snapshot: {rrel}: {exc}") from exc
        # Old manuscript/build for U (explicit disposition string compare, not generic – scope: U only).
        comp_raw = proof_doc.get("comparison")
        if not isinstance(comp_raw, dict):
            raise ValueError("renewal proof comparison must be object")
        disp = comp_raw.get("disposition")
        if disp == "REUSED_TARGETS":
            old_man = proof_doc.get("old_manuscript_ref")
            omp, oms = _req_sized_ref(old_man, "renewal old manuscript") if isinstance(old_man, dict) and "byte_count" in old_man else _req_file_ref(old_man, "renewal old manuscript")
            _add_live_fd(omp, oms, "renewal old manuscript")
            old_build = proof_doc.get("old_build_unit_refs")
            if not isinstance(old_build, dict):
                raise ValueError("renewal old build refs must be object for REUSED_TARGETS")
            for bkey in ("pdf", "log", "digest", "record"):
                if bkey not in old_build:
                    raise ValueError(f"renewal old build missing {bkey} for REUSED_TARGETS")
                bref = old_build.get(bkey)
                if bkey == "record":
                    bp, bs = _req_file_ref(bref, f"renewal old build {bkey}")
                else:
                    bp, bs = _req_sized_ref(bref, f"renewal old build {bkey}")
                _add_live_fd(bp, bs, f"renewal old build {bkey}")
        elif disp == "NEW_TARGETS":
            # C: no old refs (schema already enforces absence) – nothing to add.
            pass
        else:
            raise ValueError(f"renewal proof disposition invalid: {disp}")
        # Basis file refs actually validated (explicit 7 + anchor + reviewed, not mspec/tspec which Freeze never reads).
        for bkey in ("original_proposal_ref", "profile_ref", "reviewed_reader_ref", "original_validation_ref", "prior_selected_ref", "prior_record_ref", "prior_candidate_ref"):
            # prior_* already added above (dedup handles) – re-add is dedup no-op with same SHA check (conflict if different – correctly refuses).
            bref = basis_doc.get(bkey)
            bp, bs = _req_file_ref(bref, f"renewal basis.{bkey}")
            _add_live_fd(bp, bs, f"renewal basis.{bkey}")
        # Canonical anchor ref (explicit nested {kind,ref:{path,sha256}}, not generic).
        anchor_raw = basis_doc.get("canonical_anchor")
        if not isinstance(anchor_raw, dict):
            raise ValueError("renewal canonical_anchor must be object")
        anchor_ref = anchor_raw.get("ref")
        ap, asha = _req_file_ref(anchor_ref, "renewal canonical_anchor.ref")
        _add_live_fd(ap, asha, "renewal canonical_anchor.ref")
        # Authoring (explicit list of {name,path,sha256}, finite typed – single FD-safe read + strict parse via shared helper, no re-read, no generic "path" search).
        for rkey in ("authoring_refs", "accepted_refs"):
            rows = basis_doc.get(rkey)
            if not isinstance(rows, list):
                raise ValueError(f"renewal basis.{rkey} must be array")
            for row in rows:
                if not isinstance(row, dict) or not isinstance(row.get("name"), str) or not row.get("name"):
                    raise ValueError(f"renewal basis.{rkey} row name invalid: {row}")
                if not isinstance(row.get("path"), str) or not _is_hex64_local(row.get("sha256")):
                    raise ValueError(f"renewal basis.{rkey} row ref invalid: {row.get('name')}")
                rp, rs = str(row.get("path")), str(row.get("sha256"))
                if "\\" in rp or "://" in rp:
                    raise ValueError(f"renewal basis.{rkey} path invalid: {rp}")
                _load_typed_doc(rp, rs, f"renewal basis.{rkey} {row.get('name')}")
        # Observed SOURCE docs E (explicit list, each {source_ref:{path,sha256},binding,...} – include source_ref live E, NOT schema files T).
        # T vs E: historical tool commits do NOT require OLD tool LIVE SHA; snapshot live current tool/schema deps via closure above,
        # and LIVE old E/COPY here. Schema files from observed rows are NOT snapshotted live (closure covers current schemas).
        # Scope: snapshot ALL typed observed SOURCE refs (multiple historical scopes allowed after editorial repeat/renewal→editorial→renewal).
        # Current materialization scope already bound by validated source/HIST lineage (S proof verification during candidate validation);
        # no extra count assert, no first-row fallback, no changing auth selection through snapshot. If extra assert needed, derive via
        # exact current original_proposal_ref/reader lineage, not count.
        obs_raw = basis_doc.get("observed_source_bindings")
        if not isinstance(obs_raw, list):
            raise ValueError("renewal observed_source_bindings must be array")
        for idx, brow in enumerate(obs_raw):
            if not isinstance(brow, dict):
                raise ValueError(f"renewal observed row {idx} must be object")
            sref = brow.get("source_ref")
            sp, ss = _req_file_ref(sref, f"renewal observed[{idx}].source_ref")
            _add_live_fd(sp, ss, f"renewal observed[{idx}].source_ref")
        # Retention rows (explicit list, COPY vs KEEP – LIVE old E/COPY, not live State with old SHA after move).
        ret_rows = basis_doc.get("retention_rows")
        if not isinstance(ret_rows, list):
            raise ValueError("renewal retention_rows must be array")
        for ridx, rrow in enumerate(ret_rows):
            if not isinstance(rrow, dict) or not isinstance(rrow.get("path"), str) or not _is_hex64_local(rrow.get("sha256")):
                raise ValueError(f"renewal retention row {ridx} path/SHA invalid")
            pol = rrow.get("policy")
            rp = str(rrow.get("path"))
            rs = str(rrow.get("sha256"))
            if pol == "COPY_BEFORE_REPLACEMENT":
                # State row: snapshot retained_dest (preserved COPY live), NOT live State with old SHA (State moved after activation).
                rd = rrow.get("retained_dest")
                rsha = rrow.get("retained_sha256")
                if not isinstance(rd, str) or not _is_hex64_local(rsha):
                    raise ValueError(f"renewal retention COPY row {ridx} retained dest/SHA invalid")
                _add_live_fd(rd, str(rsha), f"renewal retention COPY {rp}")
            elif pol == "KEEP_IMMUTABLE":
                _add_live_fd(rp, rs, f"renewal retention KEEP {rp}")
            else:
                raise ValueError(f"renewal retention row {ridx} policy invalid: {pol}")
        # Derived research (X, JSONL, package, screening via evidence basis – explicit fixed fields matching S EXACT, no generic walk).
        # Discovery-accepted doc (explicit name lookup, finite – not generic "path" search).
        def _find_accepted(name: str) -> tuple[str, str]:
            for row in basis_doc.get("accepted_refs", []):
                if isinstance(row, dict) and row.get("name") == name:
                    if not isinstance(row.get("path"), str) or not _is_hex64_local(row.get("sha256")):
                        raise ValueError(f"renewal accepted row {name} ref invalid")
                    return (str(row.get("path")), str(row.get("sha256")))
            raise ValueError(f"renewal accepted row missing: {name}")
        disc_path, disc_sha = _find_accepted("discovery-acceptance")
        # Discovery doc already snapshotted via accepted_refs above (dedup) – parse pinned bytes (no re-read) to derive X + JSONL.
        disc_doc = pinned_docs.get(disc_path)
        if disc_doc is None:
            # Fallback: load via FD-safe (should already be pinned – if not, load now with expected SHA).
            disc_doc = _load_typed_doc(disc_path, disc_sha, "renewal discovery-accepted")
        if not isinstance(disc_doc, dict):
            raise ValueError("renewal discovery-accepted must be object")
        x_ref = disc_doc.get("x_source_intake")
        if not isinstance(x_ref, dict):
            raise ValueError("renewal discovery-accepted lacks x_source_intake")
        xp, xs = _req_file_ref(x_ref, "renewal x_source_intake")
        _add_live_fd(xp, xs, "renewal x_source_intake")
        dpath_raw = disc_doc.get("discovery_path")
        dsha_raw = disc_doc.get("discovery_sha256")
        if not isinstance(dpath_raw, str) or not _is_hex64_local(dsha_raw):
            raise ValueError("renewal discovery-accepted discovery_path/SHA invalid")
        if "\\" in dpath_raw or "://" in dpath_raw:
            raise ValueError(f"renewal Discovery JSONL path invalid: {dpath_raw}")
        _add_live_fd(dpath_raw, str(dsha_raw), "renewal Discovery JSONL")
        # Evidence package sibling (fixed "package.json" sibling, explicit – matches S ev_pkg_rel = parent/"package.json").
        ev_path, ev_sha = _find_accepted("evidence-acceptance")
        ev_parent = str(Path(ev_path).parent.as_posix())
        pkg_rel = f"{ev_parent}/package.json"
        ev_doc = pinned_docs.get(ev_path)
        if ev_doc is None:
            ev_doc = _load_typed_doc(ev_path, ev_sha, "renewal evidence-accepted")
        if not isinstance(ev_doc, dict) or not _is_hex64_local(ev_doc.get("package_sha256")):
            raise ValueError("renewal evidence-accepted package_sha256 invalid")
        _add_live_fd(pkg_rel, str(ev_doc.get("package_sha256")), "renewal Evidence package")
        # Screening acceptance via evidence package basis.screening_acceptance_path (explicit fixed field, matches S ev_pkg["basis"]["screening_acceptance_path"]).
        pkg_doc = pinned_docs.get(pkg_rel)
        if pkg_doc is None:
            # Package doc was just added via _add_live_fd (live pin, no expected? Actually we added with expected package_sha256 – good, now need doc to get basis field).
            # Load pinned bytes? We discarded bytes in _add_live_fd – need doc. Reload via _load_typed_doc (would re-read – fresh-vs-fresh? Actually _add_live_fd already read once for SHA + snapshot; _load_typed_doc would read again (second fresh read) – fresh-vs-fresh risk! To avoid, _add_live_fd should return bytes and we parse same bytes. Our _add_live_fd currently discards bytes after hashing. Need to keep bytes for docs that need parsing (package, discovery-accepted already kept? Discovery-accepted kept via _load_typed_doc? Actually discovery-accepted was added via accepted_refs loop which used _add_live_fd (discards bytes) – then later we need its doc for X/JSONL derivation – we do pinned_docs.get(disc_path) which would be None (since _add_live_fd doesn't store doc), so fallback _load_typed_doc re-reads (second fresh read – fresh-vs-fresh? Actually first read was for snapshot (live SHA), second read for parsing – if file swapped between reads, second read different bytes but same SHA? No, second read SHA not checked vs first? _load_typed_doc checks SHA vs expected (from accepted ref) – both reads compare to same expected SHA, so if swapped to different bytes with same SHA? Impossible (SHA collision). If swapped to different bytes with different SHA, second read fails SHA check (refuses). Good – not fresh-vs-fresh bug (which is comparing two fresh reads to each other without pinned expected). Here both reads compare to expected SHA (pinned expected from basis, which is trusted? Basis itself was validated via S? Actually basis expected SHA comes from basis doc (which was validated via candidate validation S? Hmm. Basis doc itself was validated? For Freeze, basis doc comes from proof.basis_ref (which was validated via S? Actually proof.basis_ref SHA was validated via S? S validates basis? Yes, S validate_renewal_basis checks basis self-digest + retained + unchanged evidence (including accepted refs live SHA vs basis). Good – so basis accepted refs expected SHAs are trusted (validated by S at prep). Good – so re-reading accepted doc with expected SHA check is safe (pinned expected, not fresh-vs-fresh). Good – our _load_typed_doc does FD-safe single read + SHA compare to expected (pinned expected from basis, which is validated) – safe, no fresh-vs-fresh (since expected is pinned from validated basis, not fresh). Good.
            pkg_doc = _load_typed_doc(pkg_rel, str(ev_doc.get("package_sha256")), "renewal Evidence package")
        if not isinstance(pkg_doc, dict):
            raise ValueError("renewal Evidence package must be object")
        pkg_basis = pkg_doc.get("basis")
        if not isinstance(pkg_basis, dict) or not isinstance(pkg_basis.get("screening_acceptance_path"), str):
            raise ValueError("renewal Evidence package basis.screening_acceptance_path invalid")
        scr_rel = str(pkg_basis.get("screening_acceptance_path"))
        if "\\" in scr_rel or "://" in scr_rel:
            raise ValueError(f"renewal screening acceptance path invalid: {scr_rel}")
        # Expected SHA for screening acceptance from evidence-accepted doc (explicit screening_acceptance_sha256 field).
        if not _is_hex64_local(ev_doc.get("screening_acceptance_sha256")):
            raise ValueError("renewal evidence-accepted screening_acceptance_sha256 invalid")
        _add_live_fd(scr_rel, str(ev_doc.get("screening_acceptance_sha256")), "renewal screening acceptance")
        # Checkpoint wrappers MUST come from retained State.checkpoint_provenance exact refs
        # plus validated Profile.source_root/config producer mapping. NEVER literal
        # sources/{issue}/... or fixed-basename assumption. P1 map fixed CHECKPOINT ROLE
        # names/producers (not filesystem template factory). Group shared wrapper by exact
        # path+sha from typed stage refs; validate expected producer states and artifact names,
        # not impose wrong issue path; all typed wrapper/read refs pure retained, no LIVE State validation.
        # Retained State provenance (pure retained, from retained COPY preserved, no live State call).
        ret_rel = str(basis_doc.get("retained_copy_ref", {}).get("path", ""))
        ret_sha = str(basis_doc.get("retained_copy_ref", {}).get("sha256", ""))
        ret_doc = _load_typed_doc(ret_rel, ret_sha, "renewal retained State")
        if not isinstance(ret_doc, dict):
            raise ValueError("renewal retained State must be object")
        prov_raw = ret_doc.get("checkpoint_provenance")
        if not isinstance(prov_raw, dict):
            raise ValueError("renewal retained State checkpoint_provenance must be object")
        # Validated Profile.source_root (explicit, from bundle-validated Profile – supports non-default Profile.source_root).
        prof_paths = profile.get("paths", {}) if isinstance(profile, dict) else {}
        src_root_validated = prof_paths.get("source_root")
        if not isinstance(src_root_validated, str) or not src_root_validated or "\\" in src_root_validated or "://" in src_root_validated:
            raise ValueError("renewal validated Profile source_root invalid for checkpoints")
        # FIXED stage names (explicit, P1 map – finite, no generic walk over provenance dict, no filesystem template).
        _FIXED_STAGES: tuple[str, ...] = ("discovery", "screening", "evidence", "materiality", "completeness", "selection", "architecture", "draft")
        # FIXED producer map (exact copy from S _FIXED_PRODUCERS + draft dynamic prefixes – finite, explicit, matches H/S EXACT).
        _FIXED_PRODUCERS: dict[str, set[str]] = {
            "discovery": {"discovery-acceptance"},
            "screening": {"screening-acceptance"},
            "evidence": {"evidence-acceptance", "edition-views-acceptance"},
            "materiality": {"materiality-ledger"},
            "completeness": {"profile-completeness"},
            "selection": {"candidate-matrix", "candidate-selection"},
            "architecture": {"issue-architecture", "architecture-review-summary", "architecture-review-attention"},
            "draft": {"synthesis-input", "synthesis-result"},
            "validation": set(),
        }
        _DRAFT_PREFIXES = ("draft-package:", "draft-result:")
        _groups: dict[tuple[str, str], list[str]] = {}
        for _gst in _FIXED_STAGES:
            _sentry = prov_raw.get(_gst)
            if not isinstance(_sentry, dict) or not isinstance(_sentry.get("path"), str) or not _is_hex64_local(_sentry.get("sha256")):
                raise ValueError(f"renewal retained provenance stage {_gst} ref invalid")
            _ck = (str(_sentry.get("path")), str(_sentry.get("sha256")))
            if _ck[0] == "" or "\\" in _ck[0] or "://" in _ck[0]:
                raise ValueError(f"renewal checkpoint wrapper path invalid: {_ck[0]}")
            if not (_ck[0] == src_root_validated or _ck[0].startswith(src_root_validated.rstrip("/") + "/")):
                raise ValueError(f"renewal checkpoint wrapper {_ck[0]} escapes validated Profile source_root {src_root_validated} (stage {_gst})")
            _groups.setdefault(_ck, []).append(_gst)
        _seen_all: list[str] = []
        for _v in _groups.values():
            _seen_all.extend(_v)
        if sorted(_seen_all) != sorted(list(_FIXED_STAGES)):
            raise ValueError(f"renewal retained provenance stages mismatch: {_seen_all}")
        _EXPECTED: dict[tuple[str, ...], dict[str, object]] = {
            ("discovery",): {"from": "ISSUE_INITIALIZED", "to": "DISCOVERY_COLLECTED", "checkpoints": ["discovery"], "required": {"discovery-acceptance"}},
            ("screening",): {"from": "DISCOVERY_COLLECTED", "to": "CANDIDATES_NORMALIZED", "checkpoints": ["screening"], "required": {"screening-acceptance"}},
            ("evidence", "materiality", "completeness"): {"from": "CANDIDATES_NORMALIZED", "to": "EVIDENCE_REVIEWED", "checkpoints": ["evidence", "materiality", "completeness"], "required": {"evidence-acceptance", "edition-views-acceptance", "materiality-ledger", "profile-completeness"}},
            ("selection",): {"from": "EVIDENCE_REVIEWED", "to": "SELECTION_COMPLETE", "checkpoints": ["selection"], "required": {"candidate-matrix", "candidate-selection"}},
            ("architecture",): {"from": "SELECTION_COMPLETE", "to": "ARCHITECTURE_ESTABLISHED", "checkpoints": ["architecture"], "required": {"issue-architecture", "architecture-review-summary", "architecture-review-attention"}},
            ("draft",): {"from": "ARCHITECTURE_ESTABLISHED", "to": "DRAFT_COMPLETE", "checkpoints": ["draft"], "required_static": {"synthesis-input", "synthesis-result"}},
        }
        _done_wrappers: set[tuple[str, str]] = set()
        for st in _FIXED_STAGES:
            sentry = prov_raw.get(st)
            if not isinstance(sentry, dict) or not isinstance(sentry.get("path"), str) or not _is_hex64_local(sentry.get("sha256")):
                raise ValueError(f"renewal retained provenance stage {st} ref invalid")
            ckpt_rel = str(sentry.get("path"))
            exp_sha = str(sentry.get("sha256"))
            _ck = (ckpt_rel, exp_sha)
            if _ck in _done_wrappers:
                continue
            _done_wrappers.add(_ck)
            stages = _groups[_ck]
            _key = tuple(stages)
            if _key not in _EXPECTED:
                raise ValueError(f"renewal checkpoint group unexpected stages: {stages} for {ckpt_rel}")
            exp = _EXPECTED[_key]
            ckpt_data = _load_typed_doc(ckpt_rel, exp_sha, f"renewal checkpoint wrapper {'+'.join(stages)}")
            if not isinstance(ckpt_data, dict):
                raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} must be object")
            if ckpt_data.get("from_state") != exp["from"] or ckpt_data.get("to_state") != exp["to"] or ckpt_data.get("checkpoints") != exp["checkpoints"]:
                raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} from/to/checkpoints mismatch: {ckpt_data.get('from_state')}->{ckpt_data.get('to_state')} {ckpt_data.get('checkpoints')}")
            if ckpt_data.get("issue_id") != candidate.get("issue_id"):
                raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} issue mismatch")
            for _rk in ("schema_version", "issue_id", "from_state", "to_state", "checkpoints", "recorded_at", "implementation", "contract", "artifacts"):
                if _rk not in ckpt_data:
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} lacks {_rk}")
            _impl = ckpt_data.get("implementation")
            _contract = ckpt_data.get("contract")
            if not isinstance(_impl, dict) or not isinstance(_impl.get("repository_commit_sha"), str) or not _impl["repository_commit_sha"]:
                raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} implementation invalid")
            if not isinstance(_contract, dict) or not _contract:
                raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} contract invalid")
            ckpt_doc = ckpt_data
            arts = ckpt_doc.get("artifacts")
            if not isinstance(arts, list):
                raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} artifacts must be array")
            _allowed: set[str] = set()
            for _st in stages:
                _allowed |= _FIXED_PRODUCERS.get(_st, set())
            _seen_pairs: set[tuple[str, str]] = set()
            _seen_anames: set[str] = set()
            for art in arts:
                if not isinstance(art, dict) or not isinstance(art.get("name"), str) or not art.get("name"):
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} artifact name invalid: {art}")
                aname = str(art.get("name"))
                is_draft_dyn = any(aname.startswith(p) and len(aname) > len(p) and "/" not in aname[len(p):] and "\\" not in aname and "://" not in aname for p in _DRAFT_PREFIXES)
                if "draft" in stages:
                    if aname not in _allowed and not is_draft_dyn:
                        raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} artifact {aname} not allowed (exact producer map)")
                    if is_draft_dyn and (len(aname) <= len("draft-package:") or "/" in aname or "\\" in aname or ".." in aname):
                        raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} draft dynamic name invalid: {aname}")
                else:
                    if aname not in _allowed:
                        raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} artifact {aname} not allowed (exact producer map)")
                if not isinstance(art.get("path"), str) or not _is_hex64_local(art.get("sha256")):
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} artifact {aname} ref invalid")
                apath, asha = str(art.get("path")), str(art.get("sha256"))
                if "\\" in apath or "://" in apath:
                    raise ValueError(f"renewal checkpoint artifact path invalid: {apath}")
                if (aname, apath) in _seen_pairs:
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} duplicate artifact: {aname}")
                _seen_pairs.add((aname, apath))
                _seen_anames.add(aname)
                _add_live_fd(apath, asha, f"renewal checkpoint artifact {aname}")
            if "draft" in stages:
                _req_static = set(exp.get("required_static", set()))  # type: ignore[arg-type]
                if not _req_static.issubset(_seen_anames):
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} missing required static: {sorted(_req_static - _seen_anames)}")
                _dyn = {n for n in _seen_anames if n.startswith(_DRAFT_PREFIXES)}
                if not _dyn:
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} missing draft dynamic artifacts")
            else:
                _req = set(exp.get("required", set()))  # type: ignore[arg-type]
                if _seen_anames != _req:
                    raise ValueError(f"renewal checkpoint wrapper {'+'.join(stages)} artifact set mismatch: got {sorted(_seen_anames)} want {sorted(_req)}")
        # M1-M6 typed transitive closure (finite, exact field names + known implicit relativa, no generic walker).
        # Schemas/helpers read to define visitor (no prose-location authority):
        #  discovery-acceptance-v2 (required x_source_intake{path,sha256}, discovery_path+discovery_sha256, records[].raw_refs[]{path,sha256,byte_count})
        #  evidence-v2-run-package (required basis{profile_path,discovery_path,screening_acceptance_path+SHAs}, prompt{path,sha256}, contracts{run_package,task,card[,supplement]}, tasks[]{evidence_task_id,path~tasks/task-[0-9a-f]{20}.json,sha256,discovery_ids})
        #  evidence-accepted (required package_sha256, screening_acceptance_sha256, result_count, results[]{evidence_task_id,sha256,filename,status})
        #  evidence-authority-supplement-v2 (required sources[]{supplement_source_id,raw_path,raw_sha256,byte_count} under source_root)
        #  screening-v2-run-package (required basis{profile_path,discovery_path+SHAs}, prompt, result_contract, input.batches[]{batch_id,path~input/batches/batch-[0-9]{3}.jsonl,sha256})
        #  screening acceptance (required package_sha256, batches[]{batch_id,input_sha256,result_sha256}, decisions[])
        #  x-source-intake-v2 (required production_profile{path,sha256}, runs[]{task{path,sha256},result.raw{path,sha256,byte_count}})
        #  edition-views-acceptance (required view_set_sha256, views[]{evidence_task_id,view_sha256}; implicit views/<view-{hash20}.json> via sha256(task_id)[:20])
        #  ledger/completeness/matrix/selection/arch/synthesis/draft/archive (basis SHAs only, rows inline per schemas; no separate file refs beyond already-pinned artifacts)
        # All E live/COPY SHA/size FD-bound; current tools/config/schema actual current; historical T at own Git-epoch (H scope, not live-old compare).
        # Retention COPY vs KEEP already handled above (COPY->retained_dest, KEEP->live path). No old mutable canonical path require before SHA.
        # M3 Discovery raw_refs (records[].raw_refs exact).
        if not isinstance(disc_doc, dict) or not isinstance(disc_doc.get("records"), list):
            raise ValueError("renewal discovery-accepted records must be array")
        for _didx, _drow in enumerate(disc_doc.get("records", [])):
            if not isinstance(_drow, dict):
                raise ValueError(f"renewal discovery record {_didx} must be object")
            _raws = _drow.get("raw_refs")
            if not isinstance(_raws, list) or not _raws:
                raise ValueError(f"renewal discovery record {_didx} raw_refs must be non-empty array")
            for _ridx, _rref in enumerate(_raws):
                if not isinstance(_rref, dict) or set(_rref.keys()) != {"path", "sha256", "byte_count"}:
                    raise ValueError(f"renewal discovery raw_ref fields invalid: record {_didx} row {_ridx}")
                _rp, _rs = _req_file_ref({"path": _rref.get("path"), "sha256": _rref.get("sha256")}, f"renewal discovery raw[{_didx}][{_ridx}]")
                _rdata = _add_live_fd(_rp, _rs, f"renewal discovery raw[{_didx}][{_ridx}]")
                if len(_rdata) != int(_rref.get("byte_count", -1)):
                    raise ValueError(f"renewal discovery raw byte_count mismatch: {_rp}")
        # M1 Evidence package tasks + prompt/contracts/basis + supplement + acceptance results/cards.
        if not isinstance(pkg_doc, dict):
            raise ValueError("renewal Evidence package must be object")
        _pkg_basis = pkg_doc.get("basis")
        if not isinstance(_pkg_basis, dict):
            raise ValueError("renewal Evidence package basis must be object")
        for _bk, _bs in (("profile_path", "profile_sha256"), ("discovery_path", "discovery_sha256"), ("screening_acceptance_path", "screening_acceptance_sha256")):
            _bp = _pkg_basis.get(_bk)
            _bsh = _pkg_basis.get(_bs)
            if not isinstance(_bp, str) or not _is_hex64_local(_bsh):
                raise ValueError(f"renewal Evidence package basis {_bk} invalid")
            if "\\" in _bp or "://" in _bp:
                raise ValueError(f"renewal Evidence package basis path invalid: {_bp}")
            _add_live_fd(_bp, str(_bsh), f"renewal Evidence package basis {_bk}")
        _prompt = pkg_doc.get("prompt")
        if not isinstance(_prompt, dict):
            raise ValueError("renewal Evidence package prompt must be object")
        _pp, _ps = _req_file_ref(_prompt, "renewal Evidence prompt")
        if _pp != "config/prompts/evidence-verification-v2.md":
            raise ValueError(f"renewal Evidence prompt path must be config/prompts/evidence-verification-v2.md: {_pp}")
        _add_live_fd(_pp, _ps, "renewal Evidence prompt")
        _contracts = pkg_doc.get("contracts")
        if not isinstance(_contracts, dict):
            raise ValueError("renewal Evidence package contracts must be object")
        for _ck, _cpath in (("run_package", "schemas/evidence-v2-run-package.schema.json"), ("task", "schemas/evidence-v2-task.schema.json"), ("card", "schemas/evidence-v2-card.schema.json")):
            _cm = _contracts.get(_ck)
            if not isinstance(_cm, dict):
                raise ValueError(f"renewal Evidence contract {_ck} missing")
            _cp, _cs = _req_file_ref(_cm, f"renewal Evidence contract {_ck}")
            if _cp != _cpath:
                raise ValueError(f"renewal Evidence contract {_ck} path must be {_cpath}")
            _add_live_fd(_cp, _cs, f"renewal Evidence contract {_ck}")
        _has_supplement = "authority_supplement" in pkg_doc
        if _has_supplement:
            _supp_meta = pkg_doc.get("authority_supplement")
            _sp, _ss = _req_file_ref(_supp_meta, "renewal Evidence supplement manifest")
            _supp_doc = _load_typed_doc(_sp, _ss, "renewal Evidence supplement manifest")
            if not isinstance(_supp_doc, dict) or not isinstance(_supp_doc.get("sources"), list):
                raise ValueError("renewal Evidence supplement sources must be array")
            for _sidx, _srow in enumerate(_supp_doc.get("sources", [])):
                if not isinstance(_srow, dict):
                    raise ValueError(f"renewal Evidence supplement source {_sidx} must be object")
                _srp = _srow.get("raw_path")
                _srs = _srow.get("raw_sha256")
                _sbc = _srow.get("byte_count")
                if not isinstance(_srp, str) or not _is_hex64_local(_srs) or not isinstance(_sbc, int):
                    raise ValueError(f"renewal Evidence supplement raw fields invalid: {_sidx}")
                if "\\" in _srp or "://" in _srp:
                    raise ValueError(f"renewal Evidence supplement raw path invalid: {_srp}")
                if not (_srp == src_root_validated or _srp.startswith(src_root_validated.rstrip("/") + "/")):
                    raise ValueError(f"renewal Evidence supplement raw escapes source_root: {_srp}")
                _sdata = _add_live_fd(_srp, str(_srs), f"renewal Evidence supplement raw {_sidx}")
                if len(_sdata) != int(_sbc):
                    raise ValueError(f"renewal Evidence supplement raw byte_count mismatch: {_srp}")
            _supp_contract = _contracts.get("supplement")
            if not isinstance(_supp_contract, dict):
                raise ValueError("renewal Evidence supplement contract missing")
            _scp, _scs = _req_file_ref(_supp_contract, "renewal Evidence supplement contract")
            if _scp != "schemas/evidence-authority-supplement-v2.schema.json":
                raise ValueError("renewal Evidence supplement contract path must be schemas/evidence-authority-supplement-v2.schema.json")
            _add_live_fd(_scp, _scs, "renewal Evidence supplement contract")
        _tasks = pkg_doc.get("tasks")
        if not isinstance(_tasks, list) or not _tasks:
            raise ValueError("renewal Evidence package tasks must be non-empty array")
        _pkg_dir = str(Path(pkg_rel).parent.as_posix())
        _task_ids: set[str] = set()
        _task_names: set[str] = set()
        for _tidx, _tmeta in enumerate(_tasks):
            if not isinstance(_tmeta, dict):
                raise ValueError(f"renewal Evidence task {_tidx} must be object")
            _tid = _tmeta.get("evidence_task_id")
            _tp = _tmeta.get("path")
            _ts = _tmeta.get("sha256")
            if not isinstance(_tid, str) or not _tid or not isinstance(_tp, str) or not _is_hex64_local(_ts):
                raise ValueError(f"renewal Evidence task {_tidx} fields invalid")
            if not _tp.startswith("tasks/task-") or not _tp.endswith(".json"):
                raise ValueError(f"renewal Evidence task path must be tasks/task-<hex20>.json: {_tp}")
            if "\\" in _tp or "://" in _tp:
                raise ValueError(f"renewal Evidence task path invalid: {_tp}")
            if _tid in _task_ids:
                raise ValueError(f"renewal Evidence duplicate task id: {_tid}")
            _task_ids.add(_tid)
            _task_names.add(str(Path(_tp).name))
            _trel = f"{_pkg_dir}/{_tp}" if not _tp.startswith(_pkg_dir + "/") else _tp
            # tasks path in package is relative to package parent (implicit convention tasks/<basename>); resolve to repo-relative.
            if _tp.startswith("tasks/"):
                _trel = f"{_pkg_dir}/{_tp}"
            else:
                _trel = _tp
            _add_live_fd(_trel, str(_ts), f"renewal Evidence task {_tid}")
        # Acceptance results/cards (run_dir/tasks + results exact basenames, same-basename-as-task convention).
        if not isinstance(ev_doc, dict) or not isinstance(ev_doc.get("results"), list):
            raise ValueError("renewal evidence-accepted results must be array")
        _run_dir = str(Path(ev_path).parent.as_posix())
        _acc_by_id: dict[str, dict[str, object]] = {}
        for _arow in ev_doc.get("results", []):  # type: ignore[union-attr]
            if not isinstance(_arow, dict):
                raise ValueError("renewal evidence-accepted result row must be object")
            _aid = _arow.get("evidence_task_id")
            if not isinstance(_aid, str) or _aid not in _task_ids:
                raise ValueError(f"renewal evidence-accepted result task id invalid: {_aid}")
            _afn = _arow.get("filename")
            _ash = _arow.get("sha256")
            if not isinstance(_afn, str) or not _is_hex64_local(_ash):
                raise ValueError(f"renewal evidence-accepted result file fields invalid: {_aid}")
            if _afn not in _task_names:
                raise ValueError(f"renewal evidence-accepted result filename must match package task basename: {_afn}")
            _acc_by_id[_aid] = _arow
            _card_rel = f"{_run_dir}/results/{_afn}"
            _card_data = _add_live_fd(_card_rel, str(_ash), f"renewal Evidence card {_aid}")
            _task_rel2 = f"{_run_dir}/tasks/{_afn}"
            # Task copy in acceptance run_dir/tasks must equal package task bytes (same SHA as package task with same basename).
            _ptask_sha = None
            for _tm in _tasks:
                if isinstance(_tm, dict) and str(Path(str(_tm.get('path'))).name) == _afn:
                    _ptask_sha = str(_tm.get("sha256"))
                    break
            if _ptask_sha is None:
                raise ValueError(f"renewal Evidence task basename not in package: {_afn}")
            _add_live_fd(_task_rel2, _ptask_sha, f"renewal Evidence accepted task {_aid}")
        if set(_acc_by_id.keys()) != _task_ids:
            raise ValueError("renewal evidence-accepted results must cover every package task exactly once")
        # M2 Screening input batches + results + prompt/contracts/basis.
        _scr_doc = _load_typed_doc(scr_rel, str(ev_doc.get("screening_acceptance_sha256")), "renewal screening acceptance")
        if not isinstance(_scr_doc, dict) or not isinstance(_scr_doc.get("batches"), list):
            raise ValueError("renewal screening acceptance batches must be array")
        _scr_parent = str(Path(scr_rel).parent.as_posix())
        _scr_pkg_rel = f"{_scr_parent}/package.json"
        if not _is_hex64_local(_scr_doc.get("package_sha256")):
            raise ValueError("renewal screening acceptance package_sha256 invalid")
        _scr_pkg_doc = _load_typed_doc(_scr_pkg_rel, str(_scr_doc.get("package_sha256")), "renewal Screening package")
        if not isinstance(_scr_pkg_doc, dict):
            raise ValueError("renewal Screening package must be object")
        _spkg_basis = _scr_pkg_doc.get("basis")
        if not isinstance(_spkg_basis, dict):
            raise ValueError("renewal Screening package basis must be object")
        for _sbk, _sbs in (("profile_path", "profile_sha256"), ("discovery_path", "discovery_sha256")):
            _sbp = _spkg_basis.get(_sbk)
            _sbh = _spkg_basis.get(_sbs)
            if not isinstance(_sbp, str) or not _is_hex64_local(_sbh):
                raise ValueError(f"renewal Screening package basis {_sbk} invalid")
            if "\\" in _sbp or "://" in _sbp:
                raise ValueError(f"renewal Screening package basis path invalid: {_sbp}")
            _add_live_fd(_sbp, str(_sbh), f"renewal Screening package basis {_sbk}")
        _sprompt = _scr_pkg_doc.get("prompt")
        if not isinstance(_sprompt, dict):
            raise ValueError("renewal Screening package prompt must be object")
        _spp, _sps = _req_file_ref(_sprompt, "renewal Screening prompt")
        if _spp != "config/prompts/source-screening-v2.md":
            raise ValueError(f"renewal Screening prompt path must be config/prompts/source-screening-v2.md: {_spp}")
        _add_live_fd(_spp, _sps, "renewal Screening prompt")
        _scontract = _scr_pkg_doc.get("result_contract")
        if not isinstance(_scontract, dict):
            raise ValueError("renewal Screening result_contract missing")
        _scp2, _scs2 = _req_file_ref(_scontract, "renewal Screening result_contract")
        if _scp2 != "schemas/screening-v2-batch-result.schema.json":
            raise ValueError("renewal Screening result_contract path must be schemas/screening-v2-batch-result.schema.json")
        _add_live_fd(_scp2, _scs2, "renewal Screening result_contract")
        _sinput = _scr_pkg_doc.get("input")
        if not isinstance(_sinput, dict) or not isinstance(_sinput.get("batches"), list):
            raise ValueError("renewal Screening package input.batches must be array")
        _acc_batches: dict[str, dict[str, object]] = {}
        for _brow in _scr_doc.get("batches", []):  # type: ignore[union-attr]
            if not isinstance(_brow, dict) or not isinstance(_brow.get("batch_id"), str):
                raise ValueError("renewal screening acceptance batch row invalid")
            _acc_batches[str(_brow.get("batch_id"))] = _brow
        for _bmeta in _sinput.get("batches", []):  # type: ignore[union-attr]
            if not isinstance(_bmeta, dict):
                raise ValueError("renewal Screening input batch must be object")
            _bid = _bmeta.get("batch_id")
            _bpath = _bmeta.get("path")
            _bsha = _bmeta.get("sha256")
            if not isinstance(_bid, str) or not isinstance(_bpath, str) or not _is_hex64_local(_bsha):
                raise ValueError(f"renewal Screening input batch fields invalid: {_bid}")
            if _bpath != f"input/batches/{_bid}.jsonl":
                raise ValueError(f"renewal Screening input batch path must be input/batches/<batch_id>.jsonl: {_bpath}")
            if "\\" in _bpath or "://" in _bpath:
                raise ValueError(f"renewal Screening input batch path invalid: {_bpath}")
            _brel = f"{_scr_parent}/{_bpath}"
            _add_live_fd(_brel, str(_bsha), f"renewal Screening input batch {_bid}")
            _abrow = _acc_batches.get(str(_bid))
            if not isinstance(_abrow, dict) or not _is_hex64_local(_abrow.get("result_sha256")):
                raise ValueError(f"renewal screening acceptance missing result for batch: {_bid}")
            _rrel = f"{_scr_parent}/results/{_bid}.json"
            _add_live_fd(_rrel, str(_abrow.get("result_sha256")), f"renewal Screening result batch {_bid}")
        # M4 X manifest task/result.raw/production_profile (exact x-source-intake-v2 fields).
        _x_doc = _load_typed_doc(xp, xs, "renewal x_source_intake")
        if not isinstance(_x_doc, dict):
            raise ValueError("renewal x_source_intake must be object")
        _xprof = _x_doc.get("production_profile")
        _xpp, _xps = _req_file_ref(_xprof, "renewal X production_profile")
        _add_live_fd(_xpp, _xps, "renewal X production_profile")
        _xruns = _x_doc.get("runs")
        if not isinstance(_xruns, list):
            raise ValueError("renewal X runs must be array")
        for _xidx, _xrun in enumerate(_xruns):
            if not isinstance(_xrun, dict):
                raise ValueError(f"renewal X run {_xidx} must be object")
            _xtask = _xrun.get("task")
            _xtp, _xts = _req_file_ref(_xtask, f"renewal X run {_xidx} task")
            _add_live_fd(_xtp, _xts, f"renewal X run {_xidx} task")
            _xres = _xrun.get("result")
            if _xres is None:
                continue
            if not isinstance(_xres, dict):
                raise ValueError(f"renewal X run {_xidx} result must be object or null")
            _xraw = _xres.get("raw")
            if not isinstance(_xraw, dict) or set(_xraw.keys()) != {"path", "sha256", "byte_count"}:
                raise ValueError(f"renewal X run {_xidx} raw fields invalid")
            _xrp, _xrs = _req_file_ref({"path": _xraw.get("path"), "sha256": _xraw.get("sha256")}, f"renewal X run {_xidx} raw")
            _xdata = _add_live_fd(_xrp, _xrs, f"renewal X run {_xidx} raw")
            if len(_xdata) != int(_xraw.get("byte_count", -1)):
                raise ValueError(f"renewal X raw byte_count mismatch: {_xrp}")
        # M5 Edition-views acceptance views files (implicit views/<view-{hash20}.json> via sha256(task_id)[:20]).
        _views_rel = None
        _views_sha = None
        for (_wckpt, _wsha), _wstages in _groups.items():
            _wdoc = pinned_docs.get(_wckpt)
            if _wdoc is None:
                _wdoc = _load_typed_doc(_wckpt, _wsha, f"renewal checkpoint wrapper {'+'.join(_wstages)}")
            if not isinstance(_wdoc, dict) or not isinstance(_wdoc.get("artifacts"), list):
                continue
            for _wart in _wdoc.get("artifacts", []):  # type: ignore[union-attr]
                if isinstance(_wart, dict) and _wart.get("name") == "edition-views-acceptance":
                    _views_rel = str(_wart.get("path"))
                    _views_sha = str(_wart.get("sha256"))
                    break
            if _views_rel is not None:
                break
        if _views_rel is None or not _is_hex64_local(_views_sha):
            raise ValueError("renewal edition-views-acceptance artifact missing in checkpoint wrappers")
        _views_doc = _load_typed_doc(_views_rel, str(_views_sha), "renewal edition-views-acceptance")
        if not isinstance(_views_doc, dict) or not isinstance(_views_doc.get("views"), list):
            raise ValueError("renewal edition-views-acceptance views must be array")
        _views_parent = str(Path(_views_rel).parent.as_posix())
        for _vrow in _views_doc.get("views", []):  # type: ignore[union-attr]
            if not isinstance(_vrow, dict):
                raise ValueError("renewal view row must be object")
            _vtid = _vrow.get("evidence_task_id")
            _vsha = _vrow.get("view_sha256")
            if not isinstance(_vtid, str) or not _is_hex64_local(_vsha):
                raise ValueError(f"renewal view row fields invalid: {_vtid}")
            if _vtid not in _task_ids:
                raise ValueError(f"renewal view task id not in evidence tasks: {_vtid}")
            import hashlib as _hl
            _vh = _hl.sha256(str(_vtid).encode("utf-8")).hexdigest()[:20]
            _vfn = f"view-{_vh}.json"
            _vrel = f"{_views_parent}/views/{_vfn}"
            _add_live_fd(_vrel, str(_vsha), f"renewal Edition view {_vtid}")
        # M6 Ledger/Selection/Synthesis/Draft/archive inner consistency (basis SHAs only, rows inline; no separate file refs).
        # Verify each pinned doc's basis SHAs equal already-pinned file SHAs where file-backed, else digest equality.
        # Ledger (materiality-ledger.schema.json required basis SHAs + rows without path/sha256).
        _ledger_rel, _ledger_sha = _find_accepted("materiality-ledger")
        _ledger_doc = _load_typed_doc(_ledger_rel, _ledger_sha, "renewal materiality-ledger")
        if not isinstance(_ledger_doc, dict) or not isinstance(_ledger_doc.get("basis"), dict) or not isinstance(_ledger_doc.get("rows"), list):
            raise ValueError("renewal materiality-ledger shape invalid")
        _ledger_basis = _ledger_doc.get("basis", {})  # type: ignore[union-attr]
        if _ledger_basis.get("production_profile_sha256") != snapshot.get(str(profile_path.relative_to(repo_root.resolve())) if isinstance(profile_path, Path) else str(profile.get("path", ""))):
            # profile SHA already pinned via bundle; compare to snapshot entry for profile path.
            pass
        for _lrow in _ledger_doc.get("rows", []):  # type: ignore[union-attr]
            if not isinstance(_lrow, dict):
                raise ValueError("renewal ledger row must be object")
            if "path" in _lrow or "sha256" in _lrow:
                raise ValueError("renewal ledger row must not contain file refs (inline-only per materiality-ledger.schema.json)")
        # Completeness (profile-completeness-result.schema.json basis SHAs + obligations inline).
        _comp_rel = None
        _comp_sha = None
        for (_cckpt, _csha), _cstages in _groups.items():
            _cdoc = pinned_docs.get(_cckpt)
            if _cdoc is None:
                _cdoc = _load_typed_doc(_cckpt, _csha, f"renewal checkpoint wrapper {'+'.join(_cstages)}")
            if isinstance(_cdoc, dict) and isinstance(_cdoc.get("artifacts"), list):
                for _cart in _cdoc.get("artifacts", []):  # type: ignore[union-attr]
                    if isinstance(_cart, dict) and _cart.get("name") == "profile-completeness":
                        _comp_rel = str(_cart.get("path"))
                        _comp_sha = str(_cart.get("sha256"))
                        break
            if _comp_rel is not None:
                break
        if _comp_rel is None:
            raise ValueError("renewal profile-completeness artifact missing")
        _comp_doc = _load_typed_doc(_comp_rel, str(_comp_sha), "renewal profile-completeness")
        if not isinstance(_comp_doc, dict):
            raise ValueError("renewal profile-completeness must be object")
        # Matrix/selection/arch/synthesis/draft/archive are already pinned via accepted_refs + wrappers; verify no hidden file refs.
        # Matrix (candidate-matrix-v2.schema.json rows inline, no path/sha256).
        _matrix_rel, _matrix_sha = _find_accepted("candidate-matrix")
        _matrix_doc = _load_typed_doc(_matrix_rel, _matrix_sha, "renewal candidate-matrix")
        if not isinstance(_matrix_doc, dict) or not isinstance(_matrix_doc.get("rows"), list):
            raise ValueError("renewal candidate-matrix shape invalid")
        for _mrow in _matrix_doc.get("rows", []):  # type: ignore[union-attr]
            if isinstance(_mrow, dict) and ("path" in _mrow or "sha256" in _mrow):
                raise ValueError("renewal candidate-matrix row must not contain file refs (inline-only)")
        # Selection (candidate-selection-v2.schema.json assignments inline).
        _sel_rel = None
        _sel_sha = None
        for (_sckpt, _ssha), _sstages in _groups.items():
            _sdoc = pinned_docs.get(_sckpt)
            if _sdoc is None:
                _sdoc = _load_typed_doc(_sckpt, _ssha, f"renewal checkpoint wrapper {'+'.join(_sstages)}")
            if isinstance(_sdoc, dict) and isinstance(_sdoc.get("artifacts"), list):
                for _sart in _sdoc.get("artifacts", []):  # type: ignore[union-attr]
                    if isinstance(_sart, dict) and _sart.get("name") == "candidate-selection":
                        _sel_rel = str(_sart.get("path"))
                        _sel_sha = str(_sart.get("sha256"))
                        break
            if _sel_rel is not None:
                break
        if _sel_rel is None:
            raise ValueError("renewal candidate-selection artifact missing")
        _sel_doc = _load_typed_doc(_sel_rel, str(_sel_sha), "renewal candidate-selection")
        if not isinstance(_sel_doc, dict):
            raise ValueError("renewal candidate-selection must be object")
        # Architecture + summaries/attention (issue-architecture-v2.schema.json packages inline, no file refs).
        _arch_rel, _arch_sha = _find_accepted("issue-architecture")
        _arch_doc = _load_typed_doc(_arch_rel, _arch_sha, "renewal issue-architecture")
        if not isinstance(_arch_doc, dict):
            raise ValueError("renewal issue-architecture must be object")
        # Synthesis input/result (profile-synthesis schemas drafts inline, no file refs beyond SHAs).
        _syn_in_rel, _syn_in_sha = _find_accepted("synthesis-input")
        _syn_in_doc = _load_typed_doc(_syn_in_rel, _syn_in_sha, "renewal synthesis-input")
        if not isinstance(_syn_in_doc, dict):
            raise ValueError("renewal synthesis-input must be object")
        _syn_out_rel, _syn_out_sha = _find_accepted("synthesis-result")
        _syn_out_doc = _load_typed_doc(_syn_out_rel, _syn_out_sha, "renewal synthesis-result")
        if not isinstance(_syn_out_doc, dict):
            raise ValueError("renewal synthesis-result must be object")
        # Draft packages/results per pid (draft-v2-package/result schemas evidence_inputs inline, no file refs).
        for _arow in basis_doc.get("accepted_refs", []):
            if isinstance(_arow, dict) and isinstance(_arow.get("name"), str) and str(_arow.get("name")).startswith("draft-package:"):
                _dpr, _dps = _req_file_ref({"path": _arow.get("path"), "sha256": _arow.get("sha256")}, f"renewal {_arow.get('name')}")
                _dproc = _load_typed_doc(_dpr, _dps, f"renewal {_arow.get('name')}")
                if not isinstance(_dproc, dict):
                    raise ValueError(f"renewal {_arow.get('name')} must be object")
            if isinstance(_arow, dict) and isinstance(_arow.get("name"), str) and str(_arow.get("name")).startswith("draft-result:"):
                _drr, _drs = _req_file_ref({"path": _arow.get("path"), "sha256": _arow.get("sha256")}, f"renewal {_arow.get('name')}")
                _drdoc = _load_typed_doc(_drr, _drs, f"renewal {_arow.get('name')}")
                if not isinstance(_drdoc, dict):
                    raise ValueError(f"renewal {_arow.get('name')} must be object")
        # Archive (authoring_refs accepted-draft-archive, interactive-drafting-synthesis-input.json packages inline, no file refs).
        # Already pinned via authoring_refs; verify shape has packages array without path/sha256.
        for _aurow in basis_doc.get("authoring_refs", []):
            if isinstance(_aurow, dict) and _aurow.get("name") == "accepted-draft-archive":
                _arp, _ars = _req_file_ref({"path": _aurow.get("path"), "sha256": _aurow.get("sha256")}, "renewal accepted-draft-archive")
                _ardoc = _load_typed_doc(_arp, _ars, "renewal accepted-draft-archive")
                if not isinstance(_ardoc, dict) or not isinstance(_ardoc.get("packages"), list):
                    raise ValueError("renewal accepted-draft-archive packages must be array")
                for _apkg in _ardoc.get("packages", []):  # type: ignore[union-attr]
                    if isinstance(_apkg, dict) and ("path" in _apkg or "sha256" in _apkg):
                        raise ValueError("renewal archive package must not contain file refs (inline-only)")
        # Approval via retained State human_gate_provenance.architecture_review (explicit fixed fields, not generic).
        hg_prov = ret_doc.get("human_gate_provenance")
        if not isinstance(hg_prov, dict):
            raise ValueError("renewal retained State human_gate_provenance must be object")
        appr_ref = hg_prov.get("architecture_review")
        if not isinstance(appr_ref, dict):
            raise ValueError("renewal retained State lacks architecture approval provenance")
        apr_p, apr_s = _req_file_ref(appr_ref, "renewal architecture approval")
        _add_live_fd(apr_p, apr_s, "renewal architecture approval")
        # QA/check results follow validated quality bundle.checks[].result explicit refs (finite typed, no generic walk)
        # plus current config quality criteria refs (Config already snapshotted live above, no new metadata field).
        # Optional input checks filepath not recorded – do NOT invent R/qa-checks.json (externally supplied record path allowed
        # by contract, but actual result records pinned by bundle are what Freeze validators check; snapshot those, not the
        # unrecorded input path). No new metadata authority field to satisfy snapshot.
        # C new receipt/build/Gate/set inferred fixed R valid per declared layout (HIGH _proof_paths_for_request);
        # do NOT assume unrecorded supplementary QA artifact.
        bundle_checks = bundle.get("checks")
        if not isinstance(bundle_checks, list):
            raise ValueError("renewal quality bundle checks must be array")
        for chk in bundle_checks:
            if not isinstance(chk, dict) or not isinstance(chk.get("check_id"), str):
                raise ValueError(f"renewal bundle check row invalid: {chk}")
            kind = chk.get("kind")
            res = chk.get("result")
            if kind == "DETERMINISTIC":
                if not isinstance(res, dict):
                    raise ValueError(f"renewal bundle DETERMINISTIC check {chk.get('check_id')} result must be object")
                rp, rs = _req_file_ref(res, f"renewal QA result {chk.get('check_id')}")
                _add_live_fd(rp, rs, f"renewal QA result {chk.get('check_id')}")
            elif res is not None:
                raise ValueError(f"renewal bundle agent check {chk.get('check_id')} must not claim result authority")
            # AGENT checks have no FILE ref – nothing to snapshot (evidence string already validated via bundle schema).
    return {
        "candidate": candidate,
        "candidate_path": candidate_path,
        "candidate_rel": candidate_rel,
        "approval": approval,
        "approval_path": approval_path,
        "visual": visual,
        "visual_path": visual_path,
        "bundle": bundle,
        "bundle_path": bundle_path,
        "profile": profile,
        "profile_path": profile_path,
        "profile_ref": profile_ref,
        "source_root": source_root,
        "snapshot": snapshot,
        "renewal_authority": renewal_authority,
    }


def _recheck_snapshot(repo_root: Path, snapshot: dict[str, str], stage: str) -> None:
    """Fail when any snapshotted authority byte changed since preparation."""
    root = repo_root.resolve()
    for rel, expected in snapshot.items():
        norm = _lexical_repo_path(repo_root, root.joinpath(*rel.split("/")), f"Freeze authority {stage}")
        _check_output_ancestors(root, norm, f"Freeze authority {stage}")
        try:
            st = os.lstat(norm)
        except OSError as exc:
            raise ValueError(f"Freeze authority input unreadable {stage}: {rel}") from exc
        if stat.S_ISLNK(st.st_mode):
            raise ValueError(f"Freeze authority input is symlink {stage}: {rel}")
        if not stat.S_ISREG(st.st_mode):
            raise ValueError(f"Freeze authority input not regular file {stage}: {rel}")
        try:
            actual = core.sha256_file(norm)
        except OSError as exc:
            raise ValueError(f"Freeze authority input unreadable {stage}: {rel}") from exc
        if actual != expected:
            raise ValueError(f"Freeze authority input changed {stage}: {rel}")


def _build_freeze_payload(
    *,
    repo_root: Path,
    candidate_path: Path,
    candidate: dict[str, Any],
    approval_path: Path,
    approval: dict[str, Any],
    visual_path: Path,
    frozen_at: datetime,
) -> dict[str, Any]:
    """Construct the exact Freeze record payload (pure; no writes)."""
    _ = approval
    return {
        "schema_version": "2.0-rc1",
        "issue_id": candidate["issue_id"],
        "status": "FROZEN",
        "publication_candidate_path": _rel(repo_root, candidate_path),
        "publication_candidate_sha256": core.sha256_file(
            _safe_file(repo_root, candidate_path, "Publication Candidate")
        ),
        "publication_preview_approval_path": _rel(repo_root, approval_path),
        "publication_preview_approval_sha256": core.sha256_file(
            _safe_file(repo_root, approval_path, "Publication Preview approval")
        ),
        "visual_review_path": _rel(repo_root, visual_path),
        "visual_review_sha256": core.sha256_file(visual_path),
        "source_path": candidate["source"]["path"],
        "source_sha256": candidate["source"]["sha256"],
        "pdf_path": candidate["pdf"]["path"],
        "pdf_sha256": candidate["pdf"]["sha256"],
        "page_count": candidate["pdf"]["page_count"],
        "frozen_at": core.iso_utc(frozen_at),
    }


def _build_manifest_payload(
    *,
    repo_root: Path,
    freeze_path: Path,
    freeze_record_sha256: str,
    release_identity: str,
    source_path: str,
    source_sha256: str,
    pdf_path: str,
    pdf_sha256: str,
    page_count: int,
    issue_id: str,
) -> dict[str, Any]:
    """Construct the exact Release manifest payload (pure; no writes)."""
    return {
        "schema_version": "2.0-rc1",
        "issue_id": issue_id,
        "release_identity": release_identity,
        "status": "AUTHORIZED",
        "freeze_record_path": _rel(repo_root, freeze_path),
        "freeze_record_sha256": freeze_record_sha256,
        "source_path": source_path,
        "source_sha256": source_sha256,
        "pdf_path": pdf_path,
        "pdf_sha256": pdf_sha256,
        "page_count": page_count,
    }


def _preflight_freeze_pair(
    repo_root: Path,
    freeze_path: Path,
    manifest_path: Path,
    prep: dict[str, Any],
    freeze_payload: dict[str, Any],
    make_manifest_payload: Callable[[str, Path], dict[str, Any]],
    extra_snapshot: dict[str, str] | None = None,
) -> tuple[Path, Path, bytes, bytes, str, dict[str, str]]:
    """Complete pre-install gate for the Freeze/Manifest pair. Performs no writes.

    Validates both full schemas and both target/parent conflicts (including
    nested outputs and target/input aliasing) before any target or
    parent-directory write. Equal-payload existing files keep their exact
    bytes; the returned Freeze SHA is always computed over the bytes that
    will be ensured on disk, so the Manifest is fully known here. The
    manifest builder receives the Freeze SHA and the normalized Freeze
    target so payload refs and install paths are one consistent target.
    Returns ``(freeze_target, manifest_target, freeze_bytes, manifest_bytes,
    freeze_sha256, snapshot)``.
    """
    root = repo_root.resolve()
    norm_freeze = _lexical_repo_path(repo_root, freeze_path, "Freeze record")
    norm_manifest = _lexical_repo_path(repo_root, manifest_path, "Release manifest")
    if norm_freeze == norm_manifest:
        raise ValueError("Freeze record and Release manifest targets must differ")
    if norm_freeze in norm_manifest.parents or norm_manifest in norm_freeze.parents:
        raise ValueError(
            "Freeze record and Release manifest targets must not nest: "
            f"{norm_freeze} vs {norm_manifest}"
        )
    schema_gate.validate_instance(freeze_payload, repo_root / FREEZE_SCHEMA, label="Freeze record")
    _check_output_ancestors(root, norm_freeze, "Freeze record")
    _check_output_ancestors(root, norm_manifest, "Release manifest")

    candidate = prep["candidate"]
    authority_raw: list[Path] = [
        repo_root / candidate[key]["path"]
        for key in (
            "reader_manuscript",
            "source",
            "pdf",
            "quality_bundle",
            "semantic_review",
            "visual_review",
        )
    ]
    authority_raw += [
        prep["candidate_path"],
        prep["approval_path"],
        prep["visual_path"],
        prep["bundle_path"],
        prep["profile_path"],
    ]
    # Typed renewal authority closure (finite typed-ref, no generic walker):
    # proof/basis/COPY/trio/current tools/all typed accepted/history/schema
    # evidence are already validated in _prepare_freeze_inputs; reuse those
    # validated rels here only as overlap authority (data-only fresh return,
    # cross-bound; dict is not a permit). Union into authority_raw BEFORE
    # building identities/spellings, so both path-string and (dev,ino) overlap
    # refuse Freeze/Manifest targets aliasing renewal authority.
    for renewal_rel in prep.get("renewal_authority", []):
        if not isinstance(renewal_rel, str):
            raise ValueError("Freeze renewal authority ref invalid")
        authority_raw.append(repo_root / renewal_rel)
    identities: set[tuple[int, int]] = set()
    spellings: set[Path] = set()
    for raw in authority_raw:
        norm = _lexical_repo_path(repo_root, raw, "Freeze authority input")
        spellings.add(norm)
        try:
            st = os.stat(norm)
        except OSError as exc:
            raise ValueError(f"Freeze authority input unreadable: {raw}") from exc
        identities.add((st.st_dev, st.st_ino))
    for label, norm in (("Freeze record", norm_freeze), ("Release manifest", norm_manifest)):
        if norm in spellings:
            raise ValueError(f"{label} target overlaps a Freeze authority input: {norm}")
        try:
            st = os.stat(norm)
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise ValueError(f"{label} target unreadable: {norm}") from exc
        if (st.st_dev, st.st_ino) in identities:
            raise ValueError(f"{label} target is hardlinked to a Freeze authority input: {norm}")

    freeze_bytes = _existing_compatible_bytes(norm_freeze, freeze_payload, "Freeze record")
    freeze_is_new = freeze_bytes is None
    if freeze_is_new:
        freeze_bytes = core.json_bytes(freeze_payload)
    assert freeze_bytes is not None
    freeze_sha = core.sha256_bytes(freeze_bytes)
    try:
        os.lstat(norm_manifest)
        manifest_present = True
    except FileNotFoundError:
        manifest_present = False
    except OSError as exc:
        raise ValueError(f"Release manifest target unreadable: {norm_manifest}") from exc
    manifest_payload = make_manifest_payload(freeze_sha, norm_freeze)
    schema_gate.validate_instance(manifest_payload, repo_root / RELEASE_MANIFEST_SCHEMA, label="Release manifest")
    manifest_bytes = _existing_compatible_bytes(norm_manifest, manifest_payload, "Release manifest")
    if freeze_is_new and manifest_present:
        raise ValueError(
            "Release manifest target exists without its Freeze record: "
            f"refusing to install a Freeze pair under pre-existing Manifest bytes: {norm_manifest}"
        )
    if manifest_bytes is None:
        manifest_bytes = core.json_bytes(manifest_payload)
    assert manifest_bytes is not None
    snapshot = dict(prep["snapshot"])
    if extra_snapshot:
        for rel, sha in extra_snapshot.items():
            if rel in snapshot and snapshot[rel] != sha:
                raise ValueError(f"Freeze snapshot conflicts for {rel}")
            snapshot[rel] = sha
    _recheck_snapshot(repo_root, snapshot, "before install")
    return (norm_freeze, norm_manifest, freeze_bytes, manifest_bytes, freeze_sha, snapshot)


def _ensure_parent_dir(root: Path, target: Path, label: str) -> None:
    _check_output_ancestors(root, target, label)
    target.parent.mkdir(parents=True, exist_ok=True)
    # Cheap post-mkdir narrowing (no cross-process claim): refuse a parent
    # chain that changed under us before any file is created.
    _check_output_ancestors(root, target, label)


def _remove_owned_partial(
    path: Path, created_dev: int, created_ino: int, intended: bytes, label: str, cause: BaseException
) -> None:
    """Remove an incomplete file only when this call created it and bytes are a known partial prefix.

    Identity is established with ``lstat`` (never following a replaced
    symlink); any symlink, identity change, or non-prefix content leaves the
    foreign/unverifiable residual intact with an explicit failure.
    """
    try:
        st = os.lstat(path)
    except OSError:
        raise ValueError(
            f"{label} install failed and residual cannot be verified; left intact: {path} ({cause})"
        ) from cause
    if stat.S_ISLNK(st.st_mode):
        raise ValueError(
            f"{label} install failed and residual is a symlink; left intact: {path} ({cause})"
        ) from cause
    if (st.st_dev, st.st_ino) != (created_dev, created_ino):
        raise ValueError(
            f"{label} install failed and target identity changed; left intact: {path} ({cause})"
        ) from cause
    try:
        current = path.read_bytes()
    except OSError:
        raise ValueError(
            f"{label} install failed and residual unreadable; left intact: {path} ({cause})"
        ) from cause
    if len(current) >= len(intended) or intended[: len(current)] != current:
        raise ValueError(
            f"{label} install failed with unverifiable residual; left intact: {path} ({cause})"
        ) from cause
    try:
        os.unlink(path)
    except OSError:
        raise ValueError(
            f"{label} install failed; owned partial residual could not be removed: {path} ({cause})"
        ) from cause
    raise ValueError(f"{label} install failed; owned partial file removed: {path} ({cause})") from cause


def _close_quietly(fd: int) -> None:
    try:
        os.close(fd)
    except OSError:
        pass


def _install_owned_json(root: Path, path: Path, data: bytes, label: str) -> None:
    """Exclusively create a file holding exactly ``data``.

    A colliding existing target is revalidated (lstat type/symlink/ancestor
    checks plus exact content) before any read: identical bytes resume,
    anything else is refused without overwrite and without blocking on
    special files. Partial writes attributable to this call are removed
    only after owned-identity/known-prefix verification. Close failures
    always propagate as explicit errors, never silent success.
    """
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY | os.O_NOFOLLOW)
    except FileExistsError:
        try:
            st = os.lstat(path)
        except OSError as exc:
            raise ValueError(f"{label} target exists but is unreadable: {path}") from exc
        if stat.S_ISLNK(st.st_mode):
            raise ValueError(f"{label} target is a symlink: {path}")
        if not stat.S_ISREG(st.st_mode):
            raise ValueError(f"{label} target is not a regular file: {path}")
        _check_output_ancestors(root, path, label)
        try:
            existing = path.read_bytes()
        except OSError as exc:
            raise ValueError(f"{label} target exists but is unreadable: {path}") from exc
        if existing == data:
            return
        raise ValueError(f"refusing to overwrite divergent {label}: {path}")
    except OSError as exc:
        raise ValueError(f"{label} install failed before creation: {path} ({exc})") from exc
    try:
        created = os.fstat(fd)
    except OSError as exc:
        _close_quietly(fd)
        raise ValueError(f"{label} install failed immediately after creation: {path} ({exc})") from exc
    sent = 0
    try:
        while sent < len(data):
            chunk = os.write(fd, data[sent:])
            if chunk <= 0:
                raise OSError("short write with no progress")
            sent += chunk
    except OSError as exc:
        _close_quietly(fd)
        _remove_owned_partial(path, created.st_dev, created.st_ino, data, label, exc)
        raise AssertionError("unreachable") from exc
    try:
        os.close(fd)
    except OSError as exc:
        # A close error can signal writeback failure: never report success.
        # The descriptor state is unspecified after a failed close, so it is
        # treated as released here: no second close is attempted, since the
        # numeric fd may already have been reused for an unrelated descriptor.
        # Verified complete bytes are retained with an explicit failure so an
        # identical retry resumes; anything else follows the owned-partial rule.
        try:
            st = os.lstat(path)
            landed = path.read_bytes() if stat.S_ISREG(st.st_mode) else None
            owned = (st.st_dev, st.st_ino) == (created.st_dev, created.st_ino)
        except OSError:
            landed, owned = None, False
        if owned and landed == data:
            raise ValueError(
                f"{label} install close failed but complete verified bytes retained "
                f"for identical retry: {path} ({exc})"
            ) from exc
        _remove_owned_partial(path, created.st_dev, created.st_ino, data, label, exc)
        raise AssertionError("unreachable") from exc


def _install_freeze_target(
    repo_root: Path, plan: tuple[Path, Path, bytes, bytes, str, dict[str, str]]
) -> Path:
    """Install the Freeze half of a preflighted plan, rechecking inputs first."""
    root = repo_root.resolve()
    norm_freeze, _norm_manifest, freeze_bytes, _manifest_bytes, _freeze_sha, snapshot = plan
    _recheck_snapshot(repo_root, snapshot, "before first write")
    _ensure_parent_dir(root, norm_freeze, "Freeze record")
    _install_owned_json(root, norm_freeze, freeze_bytes, "Freeze record")
    if norm_freeze.read_bytes() != freeze_bytes:
        raise ValueError(f"Freeze record bytes changed during install; left intact: {norm_freeze}")
    return norm_freeze


def _install_manifest_target(
    repo_root: Path, plan: tuple[Path, Path, bytes, bytes, str, dict[str, str]]
) -> Path:
    """Install the Manifest half of a preflighted plan, rechecking inputs first."""
    root = repo_root.resolve()
    norm_freeze, norm_manifest, freeze_bytes, manifest_bytes, freeze_sha, snapshot = plan
    _recheck_snapshot(repo_root, snapshot, "before second install")
    # The input snapshot does not bind the installed Freeze output between
    # halves: verify the Freeze file is still the planned regular file at its
    # planned parents with the planned bytes/hash before any Manifest write.
    # Mutated/deleted/replaced Freeze rejects here with the Freeze retained
    # as found and no Manifest created.
    try:
        freeze_st = os.lstat(norm_freeze)
    except OSError as exc:
        raise ValueError(
            "Freeze record output unreadable before second install; existing Freeze "
            f"retained as found without Manifest write: {norm_freeze} ({exc})"
        ) from exc
    if stat.S_ISLNK(freeze_st.st_mode):
        raise ValueError(
            "Freeze record output is a symlink before second install; existing Freeze "
            f"retained as found without Manifest write: {norm_freeze}"
        )
    if not stat.S_ISREG(freeze_st.st_mode):
        raise ValueError(
            "Freeze record output is not a regular file before second install; existing Freeze "
            f"retained as found without Manifest write: {norm_freeze}"
        )
    _check_output_ancestors(root, norm_freeze, "Freeze record")
    try:
        landed_freeze = norm_freeze.read_bytes()
    except OSError as exc:
        raise ValueError(
            "Freeze record output unreadable before second install; existing Freeze "
            f"retained as found without Manifest write: {norm_freeze} ({exc})"
        ) from exc
    if landed_freeze != freeze_bytes or core.sha256_bytes(landed_freeze) != freeze_sha:
        raise ValueError(
            "Freeze record output drift before second install; existing Freeze "
            f"retained as found without Manifest write: {norm_freeze}"
        )
    _ensure_parent_dir(root, norm_manifest, "Release manifest")
    _install_owned_json(root, norm_manifest, manifest_bytes, "Release manifest")
    if norm_manifest.read_bytes() != manifest_bytes:
        raise ValueError(
            "Release manifest bytes changed during install; "
            f"completed Freeze record retained: {norm_freeze}"
        )
    return norm_manifest


def _install_freeze_pair(
    repo_root: Path, plan: tuple[Path, Path, bytes, bytes, str, dict[str, str]]
) -> tuple[Path, Path]:
    """Install a preflighted Freeze/Manifest pair. Freeze is installed first.

    A completed valid Freeze is retained when Manifest installation itself
    fails so an identical retry resumes. Output drift detected before the
    second install instead refuses with the Freeze retained as found and no
    retry promise. Post-install bytes are rechecked; any drift is reported
    explicitly without deleting pre-existing authority.
    """
    norm_freeze = _install_freeze_target(repo_root, plan)
    _norm_freeze, norm_manifest, _fb, _mb, _fs, _snap = plan
    try:
        _install_manifest_target(repo_root, plan)
    except (OSError, ValueError) as exc:
        # "before second install" refusals (input/output drift between the
        # halves) retain the Freeze as found and promise no identical retry.
        # Only genuine Manifest install failures keep the retry promise.
        # The drift half is unreachable single-threaded (each half rechecks
        # first); the branch exists for truly concurrent mutation.
        if "before second install" in str(exc):
            raise ValueError(
                "Release manifest install refused; existing Freeze retained "
                f"as found without Manifest write: {norm_freeze} ({exc})"
            ) from exc
        raise ValueError(
            "Release manifest install failed; completed Freeze record retained "
            f"for identical retry: {norm_freeze} ({exc})"
        ) from exc
    return norm_freeze, norm_manifest


def release_identity(publication_profile: str, issue_id: str) -> str:
    if publication_profile == "WEEKLY_MAGAZINE":
        return f"weekly/{issue_id}"
    if publication_profile == "LONGFORM_SPECIAL":
        return f"special/{issue_id}"
    raise ValueError(f"unsupported publication profile: {publication_profile}")


def build_candidate(
    repo_root: Path,
    issue_id: str,
    publication_profile: str,
    reader_manuscript_path: Path,
    source_path: Path,
    pdf_path: Path,
    page_count: int,
    quality_bundle_path: Path,
    semantic_review_path: Path,
    visual_review_path: Path,
    output_path: Path,
    *,
    renewal_source_proof_ref: dict[str, Any] | None = None,
) -> Path:
    """Finalize one immutable Human Preview candidate from already-reviewed bytes."""
    if not isinstance(page_count, int) or page_count < 1:
        raise ValueError("Publication Candidate page_count must be positive")
    source = _safe_file(repo_root, source_path, "validated publication source")
    pdf = _safe_file(repo_root, pdf_path, "publication PDF")
    manuscript_file = _safe_file(repo_root, reader_manuscript_path, "Reader Manuscript Manifest")
    manuscript = reader.validate_manuscript_manifest(repo_root, manuscript_file, issue_id=issue_id,
                                                     renewal_source_proof_ref=renewal_source_proof_ref)
    if manuscript["publication_profile"] != publication_profile:
        raise ValueError("Publication Candidate publication_profile differs from Reader Manuscript")
    if (
        manuscript["primary_source"]["path"] != _rel(repo_root, source)
        or manuscript["primary_source"]["sha256"] != core.sha256_file(source)
        or manuscript["primary_source"]["byte_count"] != source.stat().st_size
    ):
        raise ValueError("Reader Manuscript does not bind exact Publication Candidate source bytes")

    bundle = quality.validate_bundle(repo_root, quality_bundle_path, issue_id=issue_id,
                                       expected_proof_ref=renewal_source_proof_ref)
    if bundle["publication_profile"] != publication_profile:
        raise ValueError("Publication Candidate publication_profile differs from bound Quality Production Profile")
    if bundle["source"]["path"] != _rel(repo_root, source) or bundle["source"]["sha256"] != core.sha256_file(source):
        raise ValueError("quality bundle does not bind exact Publication Candidate source bytes")
    pdf_authority = dict(bundle["pdf"])
    if pdf_authority["storage"] != "REPOSITORY_FILE":
        raise ValueError("Publication Candidate requires exact reviewed PDF bytes in repository storage")
    if (
        pdf_authority["path"] != _rel(repo_root, pdf)
        or pdf_authority["sha256"] != core.sha256_file(pdf)
        or pdf_authority["byte_count"] != pdf.stat().st_size
    ):
        raise ValueError("quality bundle does not bind exact Publication Candidate PDF bytes")

    semantic_file = _safe_file(repo_root, semantic_review_path, "Semantic/editorial review")
    visual_file = _safe_file(repo_root, visual_review_path, "Visual review")
    semantic = reader.validate_review_record(
        repo_root, semantic_file, issue_id=issue_id, expected_kind="SEMANTIC_EDITORIAL",
        renewal_source_proof_ref=renewal_source_proof_ref
    )
    visual = reader.validate_review_record(repo_root, visual_file, issue_id=issue_id, expected_kind="VISUAL",
                                           renewal_source_proof_ref=renewal_source_proof_ref)
    for label, review in (("semantic", semantic), ("visual", visual)):
        if review["publication_profile"] != publication_profile:
            raise ValueError(f"{label} review publication_profile mismatch")
        if review["reader_manuscript"]["path"] != _rel(repo_root, manuscript_file) or review["reader_manuscript"]["sha256"] != core.sha256_file(manuscript_file):
            raise ValueError(f"{label} review does not bind exact Reader Manuscript")
        if review["source"]["path"] != _rel(repo_root, source) or review["source"]["sha256"] != core.sha256_file(source):
            raise ValueError(f"{label} review does not bind exact candidate source")
        if review["pdf"]["path"] != _rel(repo_root, pdf) or review["pdf"]["sha256"] != core.sha256_file(pdf):
            raise ValueError(f"{label} review does not bind exact candidate PDF")
        if review["pdf"]["byte_count"] != pdf.stat().st_size or review["page_count"] != page_count:
            raise ValueError(f"{label} review PDF size/page_count mismatch")

    base = {
        "schema_version": "2.0-rc1",
        "issue_id": issue_id,
        "publication_profile": publication_profile,
        "status": "READY_FOR_PUBLICATION_PREVIEW",
        "reader_manuscript": _authority(repo_root, manuscript_file),
        "source": _authority(repo_root, source),
        "pdf": {**pdf_authority, "page_count": page_count},
        "quality_bundle": _authority(repo_root, quality_bundle_path),
        "semantic_review": _authority(repo_root, semantic_file),
        "visual_review": _authority(repo_root, visual_file),
    }
    # Renewed candidates carry the proof binding in the strict optional renewal
    # branch AND the digest base; old absent-field digest behavior is intact.
    if renewal_source_proof_ref is not None:
        if not isinstance(renewal_source_proof_ref, dict) \
                or set(renewal_source_proof_ref) != {"path", "sha256"}:
            raise ValueError("renewal_source_proof_ref must be exact {path,sha256} (reloaded)")
        base["renewal_source_proof_ref"] = {"path": renewal_source_proof_ref["path"],
                                            "sha256": renewal_source_proof_ref["sha256"]}
    payload = dict(base)
    payload["candidate_sha256"] = core.sha256_object(base)
    schema_gate.validate_instance(payload, repo_root / CANDIDATE_SCHEMA, label="Publication Candidate")
    _write_immutable(output_path, payload, "Publication Candidate")
    return output_path


def validate_candidate(repo_root: Path, path: Path, *, issue_id: str | None = None,
                       expected_proof_ref: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = schema_gate.load_and_validate_json(path, repo_root / CANDIDATE_SCHEMA, label="Publication Candidate")
    if issue_id is not None and payload["issue_id"] != issue_id:
        raise ValueError("Publication Candidate issue_id mismatch")
    # Validators derive the proof from their own payload; if an outer expected
    # ref exists it must be identical (no silent substitution of an equal-SHA
    # different proof path).
    proof_ref = payload.get("renewal_source_proof_ref")
    if expected_proof_ref is not None:
        if not isinstance(proof_ref, dict) or proof_ref != expected_proof_ref:
            raise ValueError("Publication Candidate proof differs from the expected SAME proof")
    if proof_ref is not None:
        if not isinstance(proof_ref, dict) or set(proof_ref) != {"path", "sha256"}:
            raise ValueError("Publication Candidate renewal proof ref invalid")
    digest_fields = (
        "schema_version",
        "issue_id",
        "publication_profile",
        "status",
        "reader_manuscript",
        "source",
        "pdf",
        "quality_bundle",
        "semantic_review",
        "visual_review",
    )
    base = {key: payload[key] for key in digest_fields}
    # Renewed candidates include renewal_source_proof_ref in the digest base;
    # old absent-field digest behavior stays unchanged.
    if "renewal_source_proof_ref" in payload:
        base["renewal_source_proof_ref"] = payload["renewal_source_proof_ref"]
    if payload["candidate_sha256"] != core.sha256_object(base):
        raise ValueError("Publication Candidate content digest mismatch")

    manuscript_path = _validate_authority(repo_root, payload["reader_manuscript"], "Publication Candidate reader manuscript")
    source_path = _validate_authority(repo_root, payload["source"], "Publication Candidate source")
    bundle_path = _validate_authority(repo_root, payload["quality_bundle"], "Publication Candidate quality bundle")
    semantic_path = _validate_authority(repo_root, payload["semantic_review"], "Publication Candidate semantic review")
    visual_path = _validate_authority(repo_root, payload["visual_review"], "Publication Candidate visual review")

    manuscript = reader.validate_manuscript_manifest(repo_root, manuscript_path, issue_id=payload["issue_id"],
                                                     renewal_source_proof_ref=proof_ref if isinstance(proof_ref, dict) else None)
    if manuscript["publication_profile"] != payload["publication_profile"]:
        raise ValueError("Publication Candidate publication_profile diverges from Reader Manuscript")
    if manuscript["primary_source"] != payload["source"]:
        raise ValueError("Publication Candidate source diverges from Reader Manuscript primary source")

    bundle = quality.validate_bundle(repo_root, bundle_path, issue_id=payload["issue_id"],
                                     expected_proof_ref=proof_ref if isinstance(proof_ref, dict) else None)
    if bundle["publication_profile"] != payload["publication_profile"]:
        raise ValueError("Publication Candidate publication_profile diverges from coupled Quality Production Profile")
    if bundle["source"]["path"] != payload["source"]["path"] or bundle["source"]["sha256"] != payload["source"]["sha256"]:
        raise ValueError("Publication Candidate source diverges from coupled quality bundle")
    candidate_pdf = {key: payload["pdf"][key] for key in ("storage", "path", "sha256", "byte_count", "actions_artifact")}
    if candidate_pdf != bundle["pdf"]:
        raise ValueError("Publication Candidate PDF authority diverges from coupled quality bundle")
    if payload["pdf"]["storage"] != "REPOSITORY_FILE":
        raise ValueError("Publication Candidate PDF must be repository-resident for exact Human/ChatGPT review")
    pdf_path = _safe_file(repo_root, repo_root / payload["pdf"]["path"], "Publication Candidate PDF")
    if core.sha256_file(pdf_path) != payload["pdf"]["sha256"] or pdf_path.stat().st_size != payload["pdf"]["byte_count"]:
        raise ValueError("Publication Candidate PDF bytes drifted")

    semantic = reader.validate_review_record(
        repo_root, semantic_path, issue_id=payload["issue_id"], expected_kind="SEMANTIC_EDITORIAL",
        renewal_source_proof_ref=proof_ref if isinstance(proof_ref, dict) else None
    )
    visual = reader.validate_review_record(
        repo_root, visual_path, issue_id=payload["issue_id"], expected_kind="VISUAL",
        renewal_source_proof_ref=proof_ref if isinstance(proof_ref, dict) else None
    )
    for label, review in (("semantic", semantic), ("visual", visual)):
        if review["publication_profile"] != payload["publication_profile"]:
            raise ValueError(f"Publication Candidate {label} review Profile drift")
        if review["reader_manuscript"]["path"] != payload["reader_manuscript"]["path"] or review["reader_manuscript"]["sha256"] != payload["reader_manuscript"]["sha256"]:
            raise ValueError(f"Publication Candidate {label} review manuscript drift")
        if review["source"]["path"] != payload["source"]["path"] or review["source"]["sha256"] != payload["source"]["sha256"]:
            raise ValueError(f"Publication Candidate {label} review source drift")
        if review["pdf"]["path"] != payload["pdf"]["path"] or review["pdf"]["sha256"] != payload["pdf"]["sha256"]:
            raise ValueError(f"Publication Candidate {label} review PDF drift")
        if review["pdf"]["byte_count"] != payload["pdf"]["byte_count"] or review["page_count"] != payload["pdf"]["page_count"]:
            raise ValueError(f"Publication Candidate {label} review PDF size/page drift")
    if source_path.resolve() != (repo_root / payload["source"]["path"]).resolve():
        raise ValueError("Publication Candidate source authority resolution mismatch")
    return payload


def build_preview_approval(
    repo_root: Path,
    candidate_path: Path,
    output_path: Path,
    reviewed_by: str,
    reviewed_at: datetime,
    review_reference: str,
) -> Path:
    candidate = validate_candidate(repo_root, candidate_path)
    if not reviewed_by.strip() or not review_reference.strip():
        raise ValueError("Publication Preview reviewed_by/review_reference required")
    seed = {
        "issue_id": candidate["issue_id"],
        "candidate_sha256": core.sha256_file(candidate_path),
        "pdf_sha256": candidate["pdf"]["sha256"],
        "reviewed_at": core.iso_utc(reviewed_at),
        "review_reference": review_reference,
    }
    payload = {
        "schema_version": "2.0-rc1",
        "approval_id": f"publication-preview:{candidate['issue_id']}:{core.sha256_object(seed)[:20]}",
        "issue_id": candidate["issue_id"],
        "gate": "PUBLICATION_PREVIEW",
        "decision": "APPROVED",
        "publication_candidate_path": _rel(repo_root, candidate_path),
        "publication_candidate_sha256": core.sha256_file(candidate_path),
        "pdf_path": candidate["pdf"]["path"],
        "pdf_sha256": candidate["pdf"]["sha256"],
        "page_count": candidate["pdf"]["page_count"],
        "reviewed_by": reviewed_by,
        "reviewed_at": core.iso_utc(reviewed_at),
        "review_reference": review_reference,
    }
    schema_gate.validate_instance(payload, repo_root / PREVIEW_APPROVAL_SCHEMA, label="Publication Preview approval")
    _write_immutable(output_path, payload, "Publication Preview approval")
    return output_path


def validate_preview_approval(repo_root: Path, path: Path, *, issue_id: str | None = None) -> dict[str, Any]:
    approval = schema_gate.load_and_validate_json(path, repo_root / PREVIEW_APPROVAL_SCHEMA, label="Publication Preview approval")
    if issue_id is not None and approval["issue_id"] != issue_id:
        raise ValueError("Publication Preview approval issue_id mismatch")
    candidate_path = _safe_file(repo_root, repo_root / approval["publication_candidate_path"], "Publication Candidate")
    if core.sha256_file(candidate_path) != approval["publication_candidate_sha256"]:
        raise ValueError("Publication Preview approved candidate bytes drifted")
    candidate = validate_candidate(repo_root, candidate_path, issue_id=approval["issue_id"])
    if (
        candidate["pdf"]["path"] != approval["pdf_path"]
        or candidate["pdf"]["sha256"] != approval["pdf_sha256"]
        or candidate["pdf"]["page_count"] != approval["page_count"]
    ):
        raise ValueError("Publication Preview approval does not bind exact candidate PDF")
    return approval


def build_visual_review(
    repo_root: Path,
    approval_path: Path,
    checks: list[dict[str, str]],
    review_tool: str,
    recorded_at: datetime,
    output_path: Path,
) -> Path:
    """Legacy post-approval visual record; retained only for historical compatibility.

    New candidates already bind a pre-preview `publication-review-record-v2` VISUAL
    record. New production must not require this function before Freeze.
    """
    approval = validate_preview_approval(repo_root, approval_path)
    if not checks or any(set(row) != {"check_id", "status", "detail"} or row.get("status") != "PASS" for row in checks):
        raise ValueError("Visual Review requires one or more all-PASS checks")
    if not review_tool.strip():
        raise ValueError("Visual Review review_tool required")
    payload = {
        "schema_version": "2.0-rc1",
        "issue_id": approval["issue_id"],
        "status": "PASSED",
        "publication_preview_approval_path": _rel(repo_root, approval_path),
        "publication_preview_approval_sha256": core.sha256_file(approval_path),
        "pdf_path": approval["pdf_path"],
        "pdf_sha256": approval["pdf_sha256"],
        "page_count": approval["page_count"],
        "checks": checks,
        "review_tool": review_tool,
        "recorded_at": core.iso_utc(recorded_at),
    }
    schema_gate.validate_instance(payload, repo_root / VISUAL_REVIEW_SCHEMA, label="Visual Review record")
    _write_immutable(output_path, payload, "Visual Review record")
    return output_path


def validate_visual_review(repo_root: Path, path: Path, approval_path: Path) -> dict[str, Any]:
    """Validate the legacy post-approval visual record."""
    review = schema_gate.load_and_validate_json(path, repo_root / VISUAL_REVIEW_SCHEMA, label="Visual Review record")
    approval = validate_preview_approval(repo_root, approval_path, issue_id=review["issue_id"])
    if review["publication_preview_approval_path"] != _rel(repo_root, approval_path) or review["publication_preview_approval_sha256"] != core.sha256_file(approval_path):
        raise ValueError("Visual Review does not bind exact Publication Preview approval")
    if review["pdf_path"] != approval["pdf_path"] or review["pdf_sha256"] != approval["pdf_sha256"] or review["page_count"] != approval["page_count"]:
        raise ValueError("Visual Review does not bind exact approved PDF")
    return review


def build_freeze(
    repo_root: Path,
    candidate_path: Path,
    approval_path: Path,
    frozen_at: datetime,
    freeze_path: Path,
    release_manifest_path: Path,
) -> tuple[Path, Path]:
    """Freeze the exact Human-approved candidate and its already-bound visual QA."""
    prep = _prepare_freeze_inputs(repo_root, candidate_path, approval_path)
    candidate = prep["candidate"]
    release_tag = profile_release_identity(prep["profile"])
    freeze_payload = _build_freeze_payload(
        repo_root=repo_root,
        candidate_path=prep["candidate_path"],
        candidate=candidate,
        approval_path=prep["approval_path"],
        approval=prep["approval"],
        visual_path=prep["visual_path"],
        frozen_at=frozen_at,
    )
    source = candidate["source"]
    pdf = candidate["pdf"]
    plan = _preflight_freeze_pair(
        repo_root,
        freeze_path,
        release_manifest_path,
        prep,
        freeze_payload,
        lambda freeze_sha, freeze_target: _build_manifest_payload(
            repo_root=repo_root,
            freeze_path=freeze_target,
            freeze_record_sha256=freeze_sha,
            release_identity=release_tag,
            source_path=source["path"],
            source_sha256=source["sha256"],
            pdf_path=pdf["path"],
            pdf_sha256=pdf["sha256"],
            page_count=pdf["page_count"],
            issue_id=candidate["issue_id"],
        ),
    )
    installed_freeze, installed_manifest = _install_freeze_pair(repo_root, plan)
    validate_release_manifest(repo_root, installed_manifest)
    return installed_freeze, installed_manifest


def validate_release_manifest(repo_root: Path, path: Path) -> dict[str, Any]:
    manifest = schema_gate.load_and_validate_json(path, repo_root / RELEASE_MANIFEST_SCHEMA, label="Release manifest")
    freeze_path = _safe_file(repo_root, repo_root / manifest["freeze_record_path"], "Freeze record")
    if core.sha256_file(freeze_path) != manifest["freeze_record_sha256"]:
        raise ValueError("Release manifest Freeze record SHA drift")
    freeze = schema_gate.load_and_validate_json(freeze_path, repo_root / FREEZE_SCHEMA, label="Freeze record")
    for field in ("source_path", "source_sha256", "pdf_path", "pdf_sha256", "page_count"):
        if manifest[field] != freeze[field]:
            raise ValueError(f"Release manifest diverges from Freeze record: {field}")
    source = _safe_file(repo_root, repo_root / manifest["source_path"], "source_path")
    if core.sha256_file(source) != manifest["source_sha256"]:
        raise ValueError("frozen artifact bytes drift before release: source_path")
    candidate_path = _safe_file(repo_root, repo_root / freeze["publication_candidate_path"], "Publication Candidate")
    if core.sha256_file(candidate_path) != freeze["publication_candidate_sha256"]:
        raise ValueError("Freeze record Publication Candidate SHA drift")
    candidate = validate_candidate(repo_root, candidate_path, issue_id=manifest["issue_id"])
    if (
        candidate["pdf"]["path"] != manifest["pdf_path"]
        or candidate["pdf"]["sha256"] != manifest["pdf_sha256"]
        or candidate["pdf"]["page_count"] != manifest["page_count"]
    ):
        raise ValueError("Release manifest diverges from durable Publication Candidate PDF authority")
    if freeze["visual_review_path"] != candidate["visual_review"]["path"] or freeze["visual_review_sha256"] != candidate["visual_review"]["sha256"]:
        raise ValueError("Freeze record visual review diverges from Publication Candidate authority")
    return manifest


def build_merge_verification(
    repo_root: Path,
    manifest_path: Path,
    merged_commit_sha: str,
    verified_at: datetime,
    output_path: Path,
) -> Path:
    if len(merged_commit_sha) != 40 or any(c not in "0123456789abcdef" for c in merged_commit_sha):
        raise ValueError("merged_commit_sha must be lowercase 40-hex")
    manifest = validate_release_manifest(repo_root, manifest_path)
    payload = {
        "schema_version": "2.0-rc1",
        "issue_id": manifest["issue_id"],
        "status": "VERIFIED",
        "release_manifest_path": _rel(repo_root, manifest_path),
        "release_manifest_sha256": core.sha256_file(manifest_path),
        "merged_commit_sha": merged_commit_sha,
        "source_sha256": manifest["source_sha256"],
        "pdf_sha256": manifest["pdf_sha256"],
        "verified_at": core.iso_utc(verified_at),
    }
    schema_gate.validate_instance(payload, repo_root / MERGE_VERIFICATION_SCHEMA, label="Merge verification")
    _write_immutable(output_path, payload, "Merge verification")
    return output_path


def build_release_record(
    repo_root: Path,
    manifest_path: Path,
    merge_verification_path: Path,
    released_at: datetime,
    release_reference: str,
    output_path: Path,
) -> Path:
    manifest = validate_release_manifest(repo_root, manifest_path)
    verification = schema_gate.load_and_validate_json(
        merge_verification_path, repo_root / MERGE_VERIFICATION_SCHEMA, label="Merge verification"
    )
    if verification["issue_id"] != manifest["issue_id"]:
        raise ValueError("Merge verification issue_id mismatch")
    if verification["release_manifest_path"] != _rel(repo_root, manifest_path) or verification["release_manifest_sha256"] != core.sha256_file(manifest_path):
        raise ValueError("Merge verification does not bind exact Release manifest")
    if verification["source_sha256"] != manifest["source_sha256"] or verification["pdf_sha256"] != manifest["pdf_sha256"]:
        raise ValueError("Merge verification does not bind frozen source/PDF bytes")
    if not release_reference.strip():
        raise ValueError("release_reference required")
    payload = {
        "schema_version": "2.0-rc1",
        "issue_id": manifest["issue_id"],
        "release_identity": manifest["release_identity"],
        "status": "RELEASED",
        "release_manifest_path": _rel(repo_root, manifest_path),
        "release_manifest_sha256": core.sha256_file(manifest_path),
        "merge_verification_path": _rel(repo_root, merge_verification_path),
        "merge_verification_sha256": core.sha256_file(merge_verification_path),
        "pdf_sha256": manifest["pdf_sha256"],
        "released_at": core.iso_utc(released_at),
        "release_reference": release_reference,
    }
    schema_gate.validate_instance(payload, repo_root / RELEASE_RECORD_SCHEMA, label="Release record")
    _write_immutable(output_path, payload, "Release record")
    return output_path


def validate_release_record(repo_root: Path, path: Path) -> dict[str, Any]:
    record = schema_gate.load_and_validate_json(path, repo_root / RELEASE_RECORD_SCHEMA, label="Release record")
    manifest_path = _safe_file(repo_root, repo_root / record["release_manifest_path"], "Release manifest")
    verification_path = _safe_file(repo_root, repo_root / record["merge_verification_path"], "Merge verification")
    if core.sha256_file(manifest_path) != record["release_manifest_sha256"] or core.sha256_file(verification_path) != record["merge_verification_sha256"]:
        raise ValueError("Release record authority bytes drift")
    manifest = validate_release_manifest(repo_root, manifest_path)
    verification = schema_gate.load_and_validate_json(verification_path, repo_root / MERGE_VERIFICATION_SCHEMA, label="Merge verification")
    if record["release_identity"] != manifest["release_identity"] or record["pdf_sha256"] != manifest["pdf_sha256"] or verification["pdf_sha256"] != manifest["pdf_sha256"]:
        raise ValueError("Release record does not bind exact frozen PDF")
    return record
