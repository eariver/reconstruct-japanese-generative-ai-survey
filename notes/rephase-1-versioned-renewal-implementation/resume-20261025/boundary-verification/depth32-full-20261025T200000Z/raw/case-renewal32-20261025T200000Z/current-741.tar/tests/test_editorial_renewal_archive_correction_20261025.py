"""Editorial renewal archive correction unit (fail-closed, no fixture authority).

Owner: editorial-high integration fix. Tests ONLY explicit kind-aware
accepted-draft-archive selection for renewal raw authoring_refs vs editorial
authored_refs. No H/S/HIGH/Reader/PUB/schema edits, no fixture DB, no network,
no writes outside tmp, no caller verified dict/token. Canonical old-kind branch
unchanged; renewal branch requires VERSIONED_RENEWAL_SOURCE_V1 + validated
authoring_refs, never .get(a) or .get(b) fallback nor raw kind/digest rewrite.
"""
from __future__ import annotations

import unittest


class RenewalArchiveSelectionTest(unittest.TestCase):
    def _renewal_receipt(self):
        return {
            "kind": "VERSIONED_RENEWAL_SOURCE_V1",
            "generator_route": "LONGFORM_GENERATED_V1",
            "reviewed_reader_ref": {"path": "sources/SP001/publication/v2/editorial-corrections/lf-boot-1/reader-surface-input-v2.json", "sha256": "e" * 64},
            "authoring_refs": [
                {"name": "proposed-publication-authoring", "path": "sources/SP001/publication/v2/editorial-corrections/lf-boot-1/authoring-input.json", "sha256": "a" * 64},
                {"name": "accepted-draft-archive", "path": "sources/SP001/draft/v2/interactive-drafting-synthesis-input.json", "sha256": "b" * 64},
            ],
            "accepted_refs": [
                {"name": "issue-architecture", "path": "sources/SP001/arch.json", "sha256": "c" * 64},
                {"name": "synthesis-input", "path": "sources/SP001/synth.json", "sha256": "d" * 64},
            ],
            "renewal_basis_ref": {"path": "p/basis.json", "sha256": "e" * 64},
            "renewal_proof_ref": {"path": "p/proof.json", "sha256": "f" * 64},
        }

    def test_renewal_draft_selects_accepted_archive(self):
        from scripts import survey_editorial_publication_v2 as edpub
        r = self._renewal_receipt()
        draft = edpub._select_renewal_draft_archive(r, "VALIDATE")
        self.assertEqual(draft["path"], "sources/SP001/draft/v2/interactive-drafting-synthesis-input.json")
        self.assertEqual(draft["sha256"], "b" * 64)

    def test_renewal_draft_refuses_old_kind(self):
        from scripts import survey_editorial_publication_v2 as edpub
        old = {"kind": "EDITORIAL_PUBLICATION_SOURCE_V1", "authoring_refs": self._renewal_receipt()["authoring_refs"]}
        with self.assertRaises(ValueError) as ctx:
            edpub._select_renewal_draft_archive(old, "VALIDATE")
        self.assertIn("BEFORE_RENEWAL_KIND", str(ctx.exception))

    def test_renewal_draft_refuses_authored_fallback(self):
        # Renewal kind but only old authored_refs key present: must refuse,
        # proving no .get(authored) or .get(authoring) fallback.
        from scripts import survey_editorial_publication_v2 as edpub
        r = {
            "kind": "VERSIONED_RENEWAL_SOURCE_V1",
            "generator_route": "WEEKLY_GENERATED_V2",
            "authored_refs": [
                {"name": "proposed-publication-authoring", "path": "p/a.json", "sha256": "a" * 64},
                {"name": "accepted-draft-archive", "path": "p/d.json", "sha256": "b" * 64},
            ],
        }
        with self.assertRaises(ValueError) as ctx:
            edpub._select_renewal_draft_archive(r, "VALIDATE")
        self.assertIn("BEFORE_AUTHORED", str(ctx.exception))

    def test_renewal_draft_refuses_wrong_roles(self):
        from scripts import survey_editorial_publication_v2 as edpub
        r = self._renewal_receipt()
        r["authoring_refs"] = [
            {"name": "publication-semantic-input", "path": "p/x.json", "sha256": "a" * 64},
            {"name": "drafting-authored-archive", "path": "p/y.json", "sha256": "b" * 64},
        ]
        with self.assertRaises(ValueError) as ctx:
            edpub._select_renewal_draft_archive(r, "VALIDATE")
        self.assertIn("BEFORE_AUTHORED", str(ctx.exception))

    def test_renewal_arch_valid_and_refuses_old(self):
        from scripts import survey_editorial_publication_v2 as edpub
        r = self._renewal_receipt()
        arch = edpub._select_renewal_arch(r, "PREPARE")
        self.assertEqual(arch["path"], "sources/SP001/arch.json")
        with self.assertRaises(ValueError) as ctx:
            edpub._select_renewal_arch({"kind": "EDITORIAL_PUBLICATION_SOURCE_V1", "accepted_refs": r["accepted_refs"]}, "PREPARE")
        self.assertIn("BEFORE_RENEWAL_KIND", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
