#!/usr/bin/env python3
"""Group C behavioral checks (no fixtures, no authority generation, fail-closed proof).

Replaces shape-presence tests with actual behavior:
- invalid pointer/selection fail propagation (no canonical fallback)
- resolver path correct via single L stage resolver (strict normalized)
- actual signatures (no optional repoRoot skip, no receipt_kind caller token)
- P3S50 + config registry still exact, but behaviorally verified where possible
"""
from __future__ import annotations

import inspect
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


def _load(modname: str):
    import importlib
    return importlib.import_module(modname)


def test_config_registry_exact():
    cfg = json.loads((ROOT / "config/survey-production-v2.json").read_text())
    pipe = cfg["contract_files"]["pipeline"]
    assert len(pipe) == 71, f"pipeline must be 71, got {len(pipe)}"
    for s in [
        "schemas/editorial-publication-source-manifest-v2.schema.json",
        "schemas/editorial-publication-set-v2.schema.json",
        "schemas/editorial-publication-build-record-v2.schema.json",
        "schemas/editorial-manuscript-spec-v2.schema.json",
        "schemas/editorial-toolchain-spec-v2.schema.json",
        "schemas/versioned-renewal-basis-v2.schema.json",
        "schemas/versioned-renewal-source-manifest-v2.schema.json",
        "schemas/versioned-renewal-source-proof-v2.schema.json",
        "schemas/versioned-renewal-publication-set-v2.schema.json",
    ]:
        assert s in pipe
    assert not any(p.startswith("scripts/") for p in pipe)
    assert "config/survey-production-v2.json" not in pipe


def test_stage_fail_closed_on_pointer():
    mod = _load("scripts.survey_stage_validation_v2")
    fake_state = {"publication_revalidation_provenance": {"path": "sources/x/publication/v2/publication-surface-revalidation-r1.json", "sha256": "0"*64}}
    fake_cfg = {}
    # Must fail closed (NEEDS_L or selection invalid), never return None/canonical.
    try:
        out = mod._require_selection(Path("/tmp"), fake_cfg, fake_state)
    except Exception as exc:
        assert "NEEDS_L" in str(exc) or "selection" in str(exc).lower() or "pointer" in str(exc).lower(), f"unexpected error: {exc}"
        return
    raise AssertionError(f"fail-open: _require_selection returned {out!r} for invalid pointer")


def test_stage_genuine_initial_allowed():
    mod = _load("scripts.survey_stage_validation_v2")
    genuine = {"publication_revalidation_provenance": None}
    # Genuine no-pointer initial returns None (caller uses canonical default), not raise.
    # If L present, it returns CANONICAL selection (dict) — both allowed, but never fail-open for pointer.
    try:
        out = mod._require_selection(Path("/tmp"), {}, genuine)
    except Exception as exc:
        # L missing with no pointer may raise NEEDS_L (also fail-closed, acceptable pre-freeze).
        assert "NEEDS_L" in str(exc), f"genuine initial should allow or NEEDS_L, got {exc}"
        return
    assert out is None or (isinstance(out, dict) and out.get("mode") == "CANONICAL"), f"genuine initial must be None or CANONICAL, got {out!r}"


def test_orchestrator_signature_strict():
    mod = _load("scripts.survey_orchestrator_v2")
    sig = inspect.signature(mod._configured_expected_artifacts)
    params = list(sig.parameters.values())
    # Must require state/repo_root/cfg (no optional fallback that silently skips active).
    names = [p.name for p in params]
    assert "state" in names and "repo_root" in names and "cfg" in names, f"signature must include state/repo_root/cfg: {names}"
    for p in params:
        if p.name in ("state", "repo_root", "cfg"):
            assert p.default is inspect.Parameter.empty, f"{p.name} must be required (no optional fallback): {p}"
    sig2 = inspect.signature(mod._configured_gate_inputs)
    names2 = [p.name for p in sig2.parameters.values()]
    assert "state" in names2, f"gate inputs must require state: {names2}"
    for p in sig2.parameters.values():
        if p.name == "state":
            assert p.default is inspect.Parameter.empty, "gate state must be required"


def test_handoff_gate_signatures_strict():
    h = _load("scripts.survey_handoff_v2")
    g = _load("scripts.survey_human_gate_v2")
    assert "repo_root" not in inspect.signature(h.expected_output_contract).parameters or inspect.signature(h.expected_output_contract).parameters["repo_root"].default is inspect.Parameter.empty, "handoff repo_root must be required"
    assert list(inspect.signature(h.resolve_handoff_artifact_path).parameters) == ["repo_root", "cfg", "state", "profile", "name", "template"], f"handoff resolver signature wrong: {list(inspect.signature(h.resolve_handoff_artifact_path).parameters)}"
    assert list(inspect.signature(g.resolve_gate_path).parameters) == ["repo_root", "cfg", "state", "profile", "name", "template"], f"gate resolver signature wrong: {list(inspect.signature(g.resolve_gate_path).parameters)}"
    # P2V must NOT have receipt_kind caller token.
    import scripts.survey_editorial_current_authority_v2 as p2v
    assert "receipt_kind" not in inspect.signature(p2v.observe_current_authority).parameters, "P2V receipt_kind caller token must be removed"


def test_resolvers_use_single_stage_api():
    for rel in [
        "scripts/survey_orchestrator_v2.py",
        "scripts/survey_handoff_v2.py",
        "scripts/survey_human_gate_v2.py",
        "scripts/survey_production_v2.py",
        "scripts/survey_profiled_freeze_v2.py",
    ]:
        text = (ROOT / rel).read_text()
        assert "resolve_stage_artifact_path" in text, f"{rel} must use single L resolve_stage_artifact_path"
        # No duplicate raw candidate handling outside thin adapter (allowlist: _l_stage_path/_resolve_* thin wrappers only).
        # Broad except-return-base must be gone.
        assert "except Exception:\n            return base" not in text and "except Exception:\n        return base" not in text, f"{rel} still has fail-open except-return-base"


def test_p3s50_and_recipe_binding():
    import ast
    text = (ROOT / "scripts/survey_editorial_staged_source_v2.py").read_text()
    tree = ast.parse(text)
    found = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for tgt in node.targets:
                if getattr(tgt, "id", "") in ("_SHARED_PY", "_SHARED_SCHEMAS"):
                    found[tgt.id] = [e.value for e in node.value.elts if isinstance(e, ast.Constant)]
    assert len(found["_SHARED_PY"]) == 35 and len(found["_SHARED_SCHEMAS"]) == 22
    assert ".latexmkrc" in text and "RECIPE_PATH" in text
    # Runtime binding must treat recipe/style/schemas as file-pin-only (legitimate), not forbid.
    assert "recipe .latexmkrc" in text.lower() or "recipe/style/schemas" in text.lower() or ".latexmkrc) are" in text


def test_export_no_absolute_relative_bug():
    text = (ROOT / ".github/workflows/survey-production-v2-export-publication-preview.yml").read_text()
    assert "def _norm" in text, "export must have strict _norm"
    assert "PurePosixPath(_expected) != candidate_rel" not in text, "old absolute-vs-relative bug must be gone"
    assert "except Exception:\n                      pass" not in text and "except Exception:\n                              continue" not in text, "export must not swallow selection errors"
    assert "ambiguous State paths" in text and "inert" in text.lower()


def test_wrappers_entry_refusal_no_swallow():
    for rel in [
        "scripts/run_semantic_publication_v2_interactive.py",
        "scripts/run_semantic_publication_v2_interactive_base.py",
        "scripts/survey_semantic_quality_v2.py",
        "scripts/survey_weekly_mechanical_refresh_v2.py",
    ]:
        text = (ROOT / rel).read_text()
        # Must use L strict API, no broad swallow to canonical.
        assert "assert_canonical_publication_mode" in text or "require_active_or_canonical" in text, f"{rel} must use L strict guard"
        assert "except Exception:\n        return" not in text and "except Exception:\n            return" not in text, f"{rel} still swallows to canonical"
