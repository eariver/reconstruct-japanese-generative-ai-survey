"""P1 renewal->editorial dispatch unit (fail-closed, no fixture authority).

Owner: P1 integration fix. Tests ONLY the new VERSIONED_RENEWAL_SOURCE_V1
dispatch branch and strict-kind helpers without creating authority or
touching H/S/HIGH/Reader/PUB/schemas. No network, no fixture DB, no writes
outside tmp_path. Global/caller-verified cache forbidden; this test uses
fresh imports per test via subprocess-free direct calls (module already
loaded, no mutable global).
"""
from __future__ import annotations

import json
import unittest
from pathlib import Path


class RenewalDispatchFailClosedTest(unittest.TestCase):
    def test_unknown_kind_still_refused(self):
        from scripts import survey_editorial_correction_proposal_v2 as p1
        import tempfile
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            # Minimal repo root with config stub? Dispatcher reads receipt via
            # core.load_json which needs file only; unknown kind must raise
            # RECEIPT_KIND_UNKNOWN before any validator call.
            receipt = root / "receipt.json"
            receipt.write_text(json.dumps({"kind": "SOME_FUTURE_KIND_V9"}), encoding="utf-8")
            # core.load_json requires repo-local? It just loads JSON; kind check happens first.
            # Pass root as tmp dir; receipt_path as file; state unused for unknown.
            with self.assertRaises(ValueError) as ctx:
                p1._dispatch_generated_receipt(root, receipt, root / "state.json")
            self.assertIn("RECEIPT_KIND_UNKNOWN", str(ctx.exception))

    def test_derive_route_both_generator_routes(self):
        from scripts import survey_editorial_correction_proposal_v2 as p1
        self.assertEqual(p1._derive_route_for_generator("WEEKLY_GENERATED_V2"), p1.WEEKLY_ROUTE)
        self.assertEqual(p1._derive_route_for_generator("LONGFORM_GENERATED_V1"), p1.LONGFORM_ROUTE)
        with self.assertRaises(ValueError) as ctx:
            p1._derive_route_for_generator("BOGUS")
        self.assertIn("RECEIPT_GENERATOR_ROUTE", str(ctx.exception))

    def test_lineage_scope_requires_renewal_kind(self):
        from scripts import survey_editorial_correction_proposal_v2 as p1
        # Minimal collector stub: only pinned() shape check matters before kind check?
        # Actually helper checks kind first, so no collector file access for wrong kind.
        class _DummyCol:
            def pinned(self, ref, label):
                raise AssertionError("must not pin for wrong kind")
        with self.assertRaises(ValueError) as ctx:
            p1._renewal_lineage_scope_rel(_DummyCol(), Path("/tmp"), {"kind": "EDITORIAL_PUBLICATION_SOURCE_V1"})
        self.assertIn("RENEWAL_SCOPE_KIND", str(ctx.exception))
        with self.assertRaises(ValueError) as ctx2:
            p1._renewal_lineage_scope_rel(_DummyCol(), Path("/tmp"), {"kind": "WEEKLY_PUBLICATION_SOURCE_V1"})
        self.assertIn("RENEWAL_SCOPE_KIND", str(ctx2.exception))

    def test_lineage_scope_requires_basis_ref_shape(self):
        from scripts import survey_editorial_correction_proposal_v2 as p1
        class _DummyCol2:
            def pinned(self, ref, label):
                # Simulate exact shape check inside helper: helper checks set=={path,sha256} before pin.
                # Here we just record call; helper will have already validated shape.
                raise AssertionError("must not reach pin with bad shape")
        # Missing basis ref -> RENEWAL_SCOPE_SHAPE before pin.
        with self.assertRaises(ValueError) as ctx:
            p1._renewal_lineage_scope_rel(_DummyCol2(), Path("/tmp"), {"kind": "VERSIONED_RENEWAL_SOURCE_V1"})
        self.assertIn("RENEWAL_SCOPE_SHAPE", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
